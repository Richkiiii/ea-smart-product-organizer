import hashlib
import os
import shutil
import stat
from pathlib import Path

import pytest

from rea_spo.core.pipeline import Pipeline
from rea_spo.core.project import create_project
from rea_spo.devtools.evaluate import evaluate_candidates
from rea_spo.workers.control import JobControl

from ..conftest import classic_settings


def _snapshot(root: Path) -> dict:
    out = {}
    for p in sorted(root.rglob("*")):
        st = p.stat()
        out[str(p.relative_to(root))] = (
            p.is_dir(), st.st_size, st.st_mtime_ns,
            None if p.is_dir() else hashlib.sha256(p.read_bytes()).hexdigest())
    return out


def _copy(src: Path, dst: Path) -> Path:
    shutil.copytree(src, dst)
    return dst


def test_full_run_counts_and_recall(tmp_path, synth_dataset):
    images, labels = synth_dataset
    src = _copy(images, tmp_path / "src")
    proj = create_project("t", tmp_path / "proj")
    proj.add_source(src)
    s = Pipeline(proj, classic_settings()).run()
    n_files = sum(1 for p in src.rglob("*") if p.suffix.lower() in {".jpg", ".png", ".webp"})
    assert s.status == "done"
    assert s.discovered == n_files
    assert s.processed + s.linked_duplicates + s.invalid == n_files
    assert s.linked_duplicates >= 1          # the dataset contains exact duplicates
    assert s.candidates > 0
    ev = evaluate_candidates(proj, labels, "classic-v1")
    assert ev["labels_unmatched"] == 0
    assert ev["candidate_recall"] >= 0.85    # regression floor for the non-neural fallback


def test_rescan_is_incremental_and_rename_is_free(tmp_path, synth_dataset):
    images, _ = synth_dataset
    src = _copy(images, tmp_path / "src")
    proj = create_project("t", tmp_path / "proj")
    proj.add_source(src)
    first = Pipeline(proj, classic_settings()).run()
    second = Pipeline(proj, classic_settings()).run()
    assert second.processed == 0 and second.unchanged == first.discovered
    victim = next(p for p in src.rglob("*.jpg"))
    victim.rename(victim.with_name("renamed_" + victim.name))
    third = Pipeline(proj, classic_settings()).run()
    assert third.processed == 0 and third.linked_duplicates == 1 and third.missing == 1


def test_pause_and_resume(tmp_path, synth_dataset):
    images, _ = synth_dataset
    src = _copy(images, tmp_path / "src")
    proj = create_project("t", tmp_path / "proj")
    proj.add_source(src)
    ctl = JobControl()

    def stop_early(p):
        if p.stage == "Analysing images" and p.done >= 10:
            ctl.cancel()

    s1 = Pipeline(proj, classic_settings(), progress=stop_early, control=ctl)
    s1.report.min_dt = 0
    r1 = s1.run()
    assert r1.status == "paused"
    assert 0 < r1.processed < r1.discovered
    r2 = Pipeline(proj, classic_settings()).run()
    assert r2.status == "done"
    c = proj.connect()
    total = c.execute("SELECT COUNT(*) FROM contents WHERE status='valid' AND analysed_stage>=4").fetchone()[0]
    assert total == r1.processed + r2.processed      # nothing analysed twice, nothing lost
    assert c.execute("SELECT COUNT(*) FROM images WHERE content_id IS NULL").fetchone()[0] == 0


def test_source_is_never_modified(tmp_path, synth_dataset):
    """Safety: run the pipeline against a read-only source; every byte and timestamp must be unchanged."""
    images, _ = synth_dataset
    src = _copy(images, tmp_path / "src")
    (src / "broken.jpg").write_bytes(b"\xff\xd8\xff\xe0garbage")
    before = _snapshot(src)
    for p in [src, *src.rglob("*")]:
        os.chmod(p, (stat.S_IREAD | stat.S_IEXEC) if p.is_dir() else stat.S_IREAD)
    try:
        proj = create_project("t", tmp_path / "proj")
        proj.add_source(src)
        s = Pipeline(proj, classic_settings()).run()
        assert s.status == "done" and s.invalid == 1
    finally:
        for p in [src, *src.rglob("*")]:
            os.chmod(p, stat.S_IRWXU)
    assert _snapshot(src) == before


def test_corrupt_and_unsupported_files_do_not_stop_the_job(tmp_path):
    src = tmp_path / "src"
    src.mkdir()
    (src / "a.jpg").write_bytes(b"\xff\xd8\xff\xe0" + b"\x00" * 100)
    (src / "b.png").write_bytes(b"hello")
    from PIL import Image
    Image.new("RGB", (300, 300), (200, 20, 20)).save(src / "c.png")
    proj = create_project("t", tmp_path / "proj")
    proj.add_source(src)
    s = Pipeline(proj, classic_settings()).run()
    assert s.status == "done" and s.processed == 1 and s.invalid == 2
    c = proj.connect()
    assert c.execute("SELECT COUNT(*) FROM image_errors").fetchone()[0] == 2
