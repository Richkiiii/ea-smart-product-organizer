"""Phase 3 end to end on the synthetic set: analyse -> (fake) OCR -> verify -> groups."""
import csv
import shutil
from pathlib import Path

from rea_spo.core import ocr_stage, verification
from rea_spo.core.pipeline import Pipeline
from rea_spo.core.project import create_project
from rea_spo.devtools.phase3 import evaluate_groups, simulate_ocr
from rea_spo.matching.scoring import MatcherModel
from rea_spo.ocr.engine import OcrLine

from ..conftest import classic_settings

MODEL = MatcherModel.load(Path(__file__).resolve().parents[2] / "models" / "matcher.json")


def _project(tmp_path, synth_dataset):
    images, labels = synth_dataset
    src = tmp_path / "src"
    shutil.copytree(images, src)
    proj = create_project("t", tmp_path / "proj")
    proj.add_source(src)
    Pipeline(proj, classic_settings()).run()
    return proj, labels


def test_verify_and_group_without_wrong_merges(tmp_path, synth_dataset):
    proj, labels = _project(tmp_path, synth_dataset)
    simulate_ocr(proj, labels)
    res = verification.run(proj, model=MODEL)
    assert res["pairs"] > 0 and res["groups"] > 0
    ev = evaluate_groups(proj, labels)
    assert ev["impure_groups"] == 0, ev        # precision first: never mix two products
    assert ev["bcubed_precision"] == 1.0


def test_lazy_ocr_stage_with_fake_engine(tmp_path, synth_dataset):
    proj, labels = _project(tmp_path, synth_dataset)
    rows = {r["rel_path"]: r for r in csv.DictReader(open(labels, encoding="utf-8"))}

    class FakeEngine:
        model_id = "fake"
        calls = 0

        def read(self, rgb):
            FakeEngine.calls += 1
            return [OcrLine("BRAND", 0.9, []), OcrLine("1,5 L", 0.92, [])]

    todo = ocr_stage.pending_contents(proj, "fake")
    c = proj.connect()
    n_contents = c.execute("SELECT COUNT(*) FROM contents WHERE status='valid'").fetchone()[0]
    assert 0 < len(todo) <= n_contents                 # only images with candidates are read
    res = ocr_stage.run(proj, FakeEngine())
    assert res["ocr_images"] == len(todo) and res["ocr_errors"] == 0
    vals = {r[0] for r in c.execute("SELECT value_norm FROM product_attributes WHERE kind='quantity'")}
    assert vals == {"1500 ml"}
    assert ocr_stage.pending_contents(proj, "fake") == []   # cached: a second run reads nothing
    assert rows
