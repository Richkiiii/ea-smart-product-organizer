"""Exercises the production ONNX embedding path (registry, checksum, runtime, embedder)
with a tiny hand-encoded ONNX graph, so it runs without the real SigLIP 2 weights."""
import hashlib
import json

import numpy as np
import pytest

from rea_spo.ai import registry
from rea_spo.ai.embeddings import SiglipOnnxEmbedder, get_embedder
from rea_spo.app.config import EngineSettings


# --- minimal protobuf encoder (enough for an ONNX ModelProto)
def _varint(n):
    out = bytearray()
    while True:
        b = n & 0x7F
        n >>= 7
        out.append(b | (0x80 if n else 0))
        if not n:
            return bytes(out)


def _f(num, wire, payload):
    key = _varint((num << 3) | wire)
    if wire == 0:
        return key + _varint(payload)
    data = payload.encode() if isinstance(payload, str) else payload
    return key + _varint(len(data)) + data


def _value_info(name, dims):
    shape = b"".join(_f(1, 2, _f(2, 2, d) if isinstance(d, str) else _f(1, 0, d)) for d in dims)
    tensor = _f(1, 0, 1) + _f(2, 2, shape)          # elem_type FLOAT, shape
    return _f(1, 2, name) + _f(2, 2, _f(1, 2, tensor))


def tiny_model() -> bytes:
    n1 = _f(1, 2, "pixel_values") + _f(2, 2, "pooled") + _f(4, 2, "GlobalAveragePool")
    n2 = _f(1, 2, "pooled") + _f(2, 2, "image_embeds") + _f(4, 2, "Flatten")
    graph = (_f(1, 2, n1) + _f(1, 2, n2) + _f(2, 2, "tiny")
             + _f(11, 2, _value_info("pixel_values", ["n", 3, 32, 32]))
             + _f(12, 2, _value_info("image_embeds", ["n", 3])))
    opset = _f(1, 2, "") + _f(2, 0, 13)
    return _f(1, 0, 8) + _f(8, 2, opset) + _f(7, 2, graph)


@pytest.fixture
def models_dir(tmp_path, monkeypatch):
    d = tmp_path / "models"
    d.mkdir()
    blob = tiny_model()
    (d / "tiny.onnx").write_bytes(blob)
    manifest = {"models": {"siglip2-base-p16-224-image": {
        "file": "tiny.onnx", "sha256": hashlib.sha256(blob).hexdigest(), "dim": 3, "input_size": 32,
        "mean": [0.5, 0.5, 0.5], "std": [0.5, 0.5, 0.5], "licence": "test"}}}
    (d / "manifest.json").write_text(json.dumps(manifest))
    monkeypatch.setenv("REA_SPO_MODELS", str(d))
    registry._VERIFIED.clear()
    return d


def test_onnx_embedder_runs_and_normalizes(models_dir):
    emb = get_embedder(EngineSettings(embedder="auto", use_gpu=False))
    assert isinstance(emb, SiglipOnnxEmbedder)
    red = np.zeros((40, 20, 3), np.uint8)
    red[..., 0] = 255
    v = emb.embed([red, red])
    assert v.shape == (2, 3)
    assert np.allclose(np.linalg.norm(v, axis=1), 1, atol=1e-5)
    assert v[0, 0] > v[0, 1]     # red channel dominates after pad-to-square on white


def test_checksum_mismatch_refuses_model(models_dir):
    (models_dir / "tiny.onnx").write_bytes(tiny_model() + b"tampered")
    registry._VERIFIED.clear()
    assert registry.find_model("siglip2-base-p16-224-image") is None
    assert get_embedder(EngineSettings(embedder="auto")).model_id == "classic-v1"
    with pytest.raises(RuntimeError):
        get_embedder(EngineSettings(embedder="siglip2"))
