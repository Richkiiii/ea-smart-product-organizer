import pytest

from rea_spo.ocr.attributes import extract, has_quantity, vetoes


def q(text):
    return sorted(a.value for a in extract(text) if a.kind == "quantity")


@pytest.mark.parametrize("text,want", [
    ("Coca-Cola 0,5 L", ["500 ml"]), ("COCA-COLA 500ml", ["500 ml"]), ("1.5L", ["1500 ml"]),
    ("1,5 l", ["1500 ml"]), ("50 cl", ["500 ml"]), ("Nutella 400g", ["400 g"]), ("750 g", ["750 g"]),
    ("0.75kg", ["750 g"]), ("1 kg", ["1000 g"]), ("2 dl", ["200 ml"]), ("6x330 ml", ["330 ml"]),
    ("6 × 0,33 l", ["330 ml"]), ("Kávé 250 G", ["250 g"]), ("12 fl oz", ["354.88 ml"]),
])
def test_quantity_normalization(text, want):
    assert q(text) == want


def test_pack_count_and_percent():
    attrs = extract("Milk 3,5% 6 x 1 L")
    kinds = {(a.kind, a.value) for a in attrs}
    assert ("pack_count", "6") in kinds and ("quantity", "1000 ml") in kinds and ("percent", "3.5") in kinds


@pytest.mark.parametrize("text", ["1500", "A4 paper", "E330 acid", "Model X5", "Vitamin B12"])
def test_no_false_quantities(text):
    assert q(text) == []


def test_implausible_rejected():
    assert q("99999 l") == []


@pytest.mark.parametrize("a,b,conflict", [
    ("Coca-Cola 500 ml", "Coca-Cola 1.5 L", True),           # the blueprint's example
    ("Nutella 400g", "NUTELLA 750 g", True),
    ("Coca-Cola 0,5 L", "Coca-Cola 500ml", False),           # same size, different spelling
    ("Coca-Cola Zero 330ml", "Coca-Cola Cherry 330ml", True),
    ("Coca-Cola Zero sugar 330ml", "Coca-Cola zero 330 ml", False),
    ("Pepsi 330ml", "Pepsi", False),                         # size unreadable -> no veto (review rule instead)
    ("Milk 1,5%", "Milk 2.8%", True),
    ("6 x 330 ml", "4 x 330 ml", True),
    ("Gyümölcslé Narancs 1L", "Gyumolcsle narancs 1 l", False),  # accents normalized
    ("Szénsavas ásványvíz 1,5L", "Szénsavmentes ásványvíz 1,5L", True),
])
def test_vetoes(a, b, conflict):
    assert bool(vetoes(extract(a), extract(b))) is conflict


def test_low_confidence_never_vetoes():
    assert vetoes(extract("500 ml", confidence=0.4), extract("1.5 L", confidence=0.9)) == []


def test_brand_from_list():
    attrs = extract("Pilos tej 2,8%", brands=["Pilos", "Mizo"])
    assert any(a.kind == "brand" and a.value == "pilos" for a in attrs)
    assert vetoes(extract("Pilos 1L", brands=["Pilos", "Mizo"]), extract("Mizo 1L", brands=["Pilos", "Mizo"]))
    assert has_quantity(extract("Mizo 1L"))
