from pathlib import Path

import numpy as np

from rea_spo.matching.grouping import build_groups
from rea_spo.matching.scoring import DEFAULT, MatcherModel, decide
from rea_spo.matching.verify import PairFeatures, geometric
from rea_spo.ocr.attributes import extract
from rea_spo.vision import local_features as lf

MODEL = MatcherModel.load(Path(__file__).resolve().parents[2] / "models" / "matcher.json")


def strong_pair(**kw) -> PairFeatures:
    base = dict(a=1, b=2, embed_sim=0.95, phash_dist=2, geo_inliers=150, geo_ratio=0.5, geo_coverage=0.8,
                color_dist=0.05, shape_diff=0.01, ocr_sim=1.0, both_text=True, qty_a=True, qty_b=True)
    base.update(kw)
    return PairFeatures(**base)


def test_strong_pair_is_same():
    assert decide(strong_pair(), MODEL).decision == "same"


def test_veto_overrides_perfect_visual_match():
    pf = strong_pair(vetoes=["quantity:500 ml!=1500 ml"])
    d = decide(pf, MODEL)
    assert d.decision == "different" and d.confidence <= 2


def test_size_family_rule_blocks_auto_merge():
    pf = strong_pair(qty_b=False)
    assert decide(pf, MODEL, size_family=True).decision == "review"
    assert decide(pf, MODEL, size_family=False).decision == "same"


def test_proportion_rule_without_sizes():
    pf = strong_pair(qty_a=False, qty_b=False, shape_diff=0.2)
    assert decide(pf, MODEL).decision != "same"


def test_no_identity_evidence_never_same():
    pf = strong_pair(geo_inliers=3, geo_coverage=0.02, phash_dist=None, both_text=False, ocr_sim=0.0)
    assert decide(pf, MODEL).decision != "same"
    assert decide(pf, DEFAULT).decision != "same"


def test_grouping_blocks_chains_through_conflicts():
    # 1~2 and 2~3 look the same, but 1 and 3 were judged different (e.g. 500 ml vs 1.5 L)
    groups = build_groups([1, 2, 3], same=[(1, 2, 99), (2, 3, 98)], different=[(1, 3)], review=[])
    sets = [set(g.members) for g in groups]
    assert {1, 2} in sets and {3} in sets
    flagged = [g for g in groups if g.needs_review]
    assert flagged, "a Same edge that could not be applied must flag the groups"


def test_grouping_user_constraints():
    g = build_groups([1, 2, 3], same=[(1, 2, 99)], different=[], review=[], must=[(2, 3)], cannot=[(1, 3)])
    sets = [set(x.members) for x in g]
    assert {2, 3} in sets and {1} in sets


def test_geometric_verification_same_label_vs_different():
    rng = np.random.default_rng(3)
    label = (rng.random((300, 220)) * 255).astype(np.uint8)
    label = np.dstack([label, np.roll(label, 7, 0), np.roll(label, 13, 1)])
    import cv2
    label = cv2.GaussianBlur(label, (0, 0), 1.2)
    M = cv2.getRotationMatrix2D((110, 150), 10, 0.8)
    rotated = cv2.warpAffine(label, M, (220, 300), borderValue=(255, 255, 255))
    other = cv2.GaussianBlur((rng.random((300, 220, 3)) * 255).astype(np.uint8), (0, 0), 1.2)
    ka, da = lf.extract(label)
    kb, db = lf.extract(rotated)
    kc, dc = lf.extract(other)
    same = geometric(ka.astype(np.float32), lf.to_float(da), kb.astype(np.float32), lf.to_float(db))
    diff = geometric(ka.astype(np.float32), lf.to_float(da), kc.astype(np.float32), lf.to_float(dc))
    assert same[0] >= 30 and same[0] > 5 * max(1, diff[0])


def test_ocr_lines_feed_attributes():
    assert {a.value for a in extract("NUTELLA\n750 g", 0.9) if a.kind == "quantity"} == {"750 g"}
