import io
import random

import cv2
import numpy as np
import pytest
from PIL import Image

from rea_spo.vision import hashing
from rea_spo.vision.decode import decode_bytes
from rea_spo.vision.segmentation import product_mask


def _product_image(bg=(255, 255, 255), size=(600, 800), stripes=False):
    img = np.full((size[1], size[0], 3), bg, np.uint8)
    if stripes:
        for y in range(0, size[1], 90):
            cv2.rectangle(img, (0, y), (size[0], y + 14), (90, 90, 90), -1)
    cv2.rectangle(img, (200, 200), (400, 650), (200, 40, 40), -1)
    cv2.putText(img, "BRAND", (215, 300), cv2.FONT_HERSHEY_DUPLEX, 1.4, (255, 255, 255), 3)
    cv2.circle(img, (300, 500), 60, (240, 220, 30), -1)
    return img


def _encode(rgb, fmt="JPEG", **kw):
    buf = io.BytesIO()
    Image.fromarray(rgb).save(buf, fmt, **kw)
    return buf.getvalue()


# ----------------------------------------------------------------- decode / validation

def test_jpeg_quality_estimate():
    rgb = _product_image()
    for q in (40, 75, 92):
        d = decode_bytes(_encode(rgb, "JPEG", quality=q))
        assert d.status == "valid"
        assert abs(d.jpeg_quality - q) <= 3


def test_png_alpha_is_flattened_on_white():
    rgba = np.zeros((200, 200, 4), np.uint8)
    rgba[50:150, 50:150] = (10, 200, 10, 255)
    d = decode_bytes(_encode(rgba, "PNG"))
    assert d.has_alpha and d.rgb.shape == (200, 200, 3)
    assert tuple(d.rgb[5, 5]) == (255, 255, 255)
    assert tuple(d.rgb[100, 100]) == (10, 200, 10)


def test_exif_orientation_applied():
    rgb = np.zeros((100, 300, 3), np.uint8)
    img = Image.fromarray(rgb)
    exif = img.getexif()
    exif[0x0112] = 6  # rotate 90 CW
    buf = io.BytesIO()
    img.save(buf, "JPEG", exif=exif.tobytes())
    d = decode_bytes(buf.getvalue())
    assert (d.width, d.height) == (100, 300)


@pytest.mark.parametrize("data,status", [
    (b"not an image at all", "unsupported"),
    (b"\xff\xd8\xff\xe0" + b"\x00" * 50, "corrupt"),
])
def test_bad_files_are_classified(data, status):
    assert decode_bytes(data).status == status


def test_truncated_jpeg_is_flagged_not_rejected():
    data = _encode(_product_image(), "JPEG", quality=90)
    d = decode_bytes(data[: len(data) // 2])
    assert d.status == "truncated"
    assert d.rgb is not None


def test_too_small():
    assert decode_bytes(_encode(np.zeros((40, 40, 3), np.uint8), "PNG")).status == "too_small"


def test_webp_supported():
    d = decode_bytes(_encode(_product_image(), "WEBP", quality=80))
    assert d.status == "valid" and d.format == "WEBP"


# ----------------------------------------------------------------- hashing

def test_phash_robust_to_recompression_and_resize():
    rgb = _product_image()
    h1 = hashing.phash(rgb)
    small = cv2.resize(rgb, (300, 400), interpolation=cv2.INTER_AREA)
    re = decode_bytes(_encode(small, "JPEG", quality=35)).rgb
    assert hashing.hamming(h1, hashing.phash(re)) <= 6
    other = _product_image(bg=(30, 120, 220))
    cv2.circle(other, (100, 100), 80, (0, 0, 0), -1)
    assert hashing.hamming(h1, hashing.phash(other)) > 6


def test_hash_index_matches_brute_force():
    rng = random.Random(1)
    hashes = []
    for i in range(400):
        base = rng.getrandbits(64) if i % 4 == 0 else hashes[-1][1] ^ (1 << rng.randrange(64))
        hashes.append((i, hashing._to_signed(base & ((1 << 64) - 1))))
    idx = hashing.HashIndex()
    for i, h in hashes:
        idx.add(i, h)
    got = {(a, b) for a, b, _ in idx.pairs_within(5)}
    want = {(a, b) for (a, ha) in hashes for (b, hb) in hashes if a < b and hashing.hamming(ha, hb) <= 5}
    assert got == want


# ----------------------------------------------------------------- segmentation

@pytest.mark.parametrize("bg,stripes", [((255, 255, 255), False), ((180, 200, 230), False), ((215, 215, 215), True)])
def test_product_mask_finds_product(bg, stripes):
    res = product_mask(_product_image(bg=bg, stripes=stripes))
    x, y, w, h = res.box
    assert not res.uncertain
    assert abs(x - 200) < 25 and abs(y - 200) < 25 and abs(w - 200) < 40 and abs(h - 450) < 40
