import numpy as np

from rea_spo.ai.embeddings import ClassicEmbedder, pad_square
from rea_spo.files.scanner import iter_images, sniff_format
from rea_spo.matching.index import knn_all
from rea_spo.storage import db as dbm


def test_migrations_create_schema(tmp_path):
    conn = dbm.connect(tmp_path / "p.db")
    assert dbm.migrate(conn) == dbm.SCHEMA_VERSION
    tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    for t in ("contents", "images", "image_fingerprints", "embeddings", "match_candidates", "match_pairs",
              "product_groups", "group_members", "file_operations", "quarantine_records", "processing_history"):
        assert t in tables
    assert dbm.migrate(conn) == dbm.SCHEMA_VERSION      # idempotent


def test_db_writer_commits_in_order(tmp_path):
    path = tmp_path / "p.db"
    conn = dbm.connect(path)
    dbm.migrate(conn)
    w = dbm.DbWriter(path, batch=7)
    for i in range(50):
        w.submit(lambda c, i=i: c.execute("INSERT INTO contents(sha256, status) VALUES (?, 'valid')", (bytes([i]) * 32,)))
    w.flush()
    assert conn.execute("SELECT COUNT(*) FROM contents").fetchone()[0] == 50
    w.close()


def test_scanner_filters_and_handles_unicode(tmp_path):
    (tmp_path / "Árvíztűrő tükörfúrógép").mkdir()
    (tmp_path / "Árvíztűrő tükörfúrógép" / "kávé 500g.JPG").write_bytes(b"\xff\xd8\xff" + b"0" * 10)
    (tmp_path / "notes.txt").write_text("x")
    (tmp_path / "_REA_Quarantine").mkdir()
    (tmp_path / "_REA_Quarantine" / "a.jpg").write_bytes(b"x")
    (tmp_path / "b.webp").write_bytes(b"x")
    found = sorted(f.rel_path for f in iter_images(tmp_path))
    assert found == ["b.webp", "Árvíztűrő tükörfúrógép/kávé 500g.JPG"]
    assert sorted(f.rel_path for f in iter_images(tmp_path, include_subfolders=False)) == ["b.webp"]


def test_sniff():
    assert sniff_format(b"\x89PNG\r\n\x1a\n....") == "PNG"
    assert sniff_format(b"RIFF\x00\x00\x00\x00WEBPVP8 ") == "WEBP"
    assert sniff_format(b"RIFF\x00\x00\x00\x00AVI ") is None


def test_knn_matches_brute_force():
    rng = np.random.default_rng(0)
    x = rng.normal(size=(300, 32)).astype(np.float32)
    x /= np.linalg.norm(x, axis=1, keepdims=True)
    sims, idx = knn_all(x, 5, block=64)
    s = x @ x.T
    np.fill_diagonal(s, -np.inf)
    want = np.argsort(-s, axis=1)[:, :5]
    assert (idx == want).all()
    assert np.allclose(sims, np.take_along_axis(s, want, axis=1), atol=1e-5)


def test_classic_embedder_normalized_and_deterministic():
    e = ClassicEmbedder()
    img = np.zeros((200, 120, 3), np.uint8)
    img[40:160, 30:90] = (200, 30, 30)
    v1, v2 = e.embed([img]), e.embed([img.copy()])
    assert v1.shape == (1, e.dim)
    assert abs(np.linalg.norm(v1) - 1) < 1e-5
    assert np.allclose(v1, v2)
    assert pad_square(img).shape == (200, 200, 3)


def test_synthetic_labels_are_consistent(tmp_path):
    """Every labelled file exists and no file is labelled twice (guards the ground truth)."""
    import csv
    from rea_spo.devtools.synth import generate
    labels = generate(tmp_path / "s", n_families=3, singletons=40, seed=21)
    rows = list(csv.DictReader(open(labels, encoding="utf-8")))
    paths = [r["rel_path"] for r in rows]
    assert len(paths) == len(set(paths))
    assert all((tmp_path / "s" / p).exists() for p in paths)
