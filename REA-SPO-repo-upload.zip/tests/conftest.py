import os
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))


@pytest.fixture(autouse=True)
def isolated_home(tmp_path, monkeypatch):
    """Every test gets its own app-data folder; the real user folder is never touched."""
    home = tmp_path / "apphome"
    monkeypatch.setenv("REA_SPO_HOME", str(home))
    monkeypatch.setenv("REA_SPO_MODELS", str(tmp_path / "no-models"))
    return home


@pytest.fixture(scope="session")
def synth_dataset(tmp_path_factory):
    from rea_spo.devtools.synth import generate
    root = tmp_path_factory.mktemp("synth")
    labels = generate(root / "images", n_families=4, singletons=6, seed=5)
    return root / "images", labels


def classic_settings(**extra):
    from rea_spo.app.config import EngineSettings
    s = EngineSettings(embedder="classic", reader_threads=2)
    s.extra.update(extra)
    return s
