"""ONNX Runtime layer: provider detection, session creation and safe CPU fallback.

Every neural model runs through this module so execution providers (CUDA, DirectML,
Windows ML later) can change without touching callers.
"""
from __future__ import annotations

import logging
import os
from pathlib import Path

import numpy as np

log = logging.getLogger("rea_spo.runtime")

try:
    import onnxruntime as ort
except ImportError:  # pragma: no cover - ORT is a hard dependency of the shipped app
    ort = None

_PREFERRED = ["CUDAExecutionProvider", "DmlExecutionProvider", "CPUExecutionProvider"]


def available_providers() -> list[str]:
    return list(ort.get_available_providers()) if ort else []


def choose_providers(use_gpu: bool = True) -> list[str]:
    avail = available_providers()
    if not use_gpu:
        return ["CPUExecutionProvider"]
    return [p for p in _PREFERRED if p in avail] or ["CPUExecutionProvider"]


def describe_hardware(use_gpu: bool = True) -> str:
    provs = choose_providers(use_gpu)
    names = {"CUDAExecutionProvider": "NVIDIA GPU (CUDA)", "DmlExecutionProvider": "GPU (DirectML)",
             "CPUExecutionProvider": f"CPU ({os.cpu_count()} threads)"}
    return names.get(provs[0], provs[0])


def create_session(model_path: Path, use_gpu: bool = True, threads: int = 0,
                   self_test_input: dict | None = None):
    """Create a session on the best provider; fall back to CPU if creation or the
    self-test fails, or if GPU output disagrees with CPU output."""
    if ort is None:
        raise RuntimeError("onnxruntime is not installed")
    opts = ort.SessionOptions()
    opts.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
    if threads:
        opts.intra_op_num_threads = threads
    providers = choose_providers(use_gpu)
    cpu_opts = ort.SessionOptions()
    cpu_opts.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
    if threads:
        cpu_opts.intra_op_num_threads = threads
    if providers[0] == "CPUExecutionProvider":
        return ort.InferenceSession(str(model_path), cpu_opts, providers=["CPUExecutionProvider"])
    try:
        if providers[0] == "DmlExecutionProvider":
            opts.enable_mem_pattern = False          # required by the DirectML provider
            opts.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
        sess = ort.InferenceSession(str(model_path), opts, providers=providers)
        if self_test_input is not None:
            gpu_out = sess.run(None, self_test_input)[0]
            cpu = ort.InferenceSession(str(model_path), cpu_opts, providers=["CPUExecutionProvider"])
            cpu_out = cpu.run(None, self_test_input)[0]
            if not np.allclose(gpu_out, cpu_out, atol=5e-2, rtol=5e-2):
                log.warning("GPU self-test mismatch for %s; using CPU", model_path.name)
                return cpu
        return sess
    except Exception:  # noqa: BLE001
        log.exception("GPU session failed for %s; falling back to CPU", model_path.name)
        return ort.InferenceSession(str(model_path), cpu_opts, providers=["CPUExecutionProvider"])
