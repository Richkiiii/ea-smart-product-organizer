"""Model registry: models/manifest.json lists every bundled model with checksum and licence."""
from __future__ import annotations

import hashlib
import json
import logging
from dataclasses import dataclass, field
from pathlib import Path

from ..app.config import models_dir

log = logging.getLogger("rea_spo.registry")
_VERIFIED: dict[str, bool] = {}


@dataclass
class ModelSpec:
    model_id: str
    file: str
    sha256: str | None = None
    kind: str = "image_embedding"
    dim: int = 0
    input_size: int = 224
    mean: list[float] = field(default_factory=lambda: [0.5, 0.5, 0.5])
    std: list[float] = field(default_factory=lambda: [0.5, 0.5, 0.5])
    licence: str = ""
    candidate_min_sim: float | None = None
    path: Path | None = None


def load_manifest(root: Path | None = None) -> dict[str, ModelSpec]:
    root = root or models_dir()
    mf = root / "manifest.json"
    if not mf.exists():
        return {}
    data = json.loads(mf.read_text(encoding="utf-8"))
    out = {}
    for mid, spec in data.get("models", {}).items():
        known = {k: v for k, v in spec.items() if k in ModelSpec.__dataclass_fields__ and k != "model_id"}
        s = ModelSpec(model_id=mid, **known)
        s.path = root / s.file
        out[mid] = s
    return out


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def find_model(model_id: str, root: Path | None = None, verify: bool = True) -> ModelSpec | None:
    spec = load_manifest(root).get(model_id)
    if spec is None or spec.path is None or not spec.path.exists():
        return None
    if verify and spec.sha256:
        key = str(spec.path)
        if key not in _VERIFIED:
            _VERIFIED[key] = _sha256(spec.path) == spec.sha256.lower()
        if not _VERIFIED[key]:
            log.error("checksum mismatch for model %s - refusing to load", model_id)
            return None
    return spec
