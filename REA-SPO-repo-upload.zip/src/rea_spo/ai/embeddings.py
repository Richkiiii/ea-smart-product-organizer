"""Image embeddings (Stage 4).

* SiglipOnnxEmbedder - the production embedder (SigLIP 2 ViT-B/16 image tower, ONNX).
* ClassicEmbedder    - a deterministic non-neural descriptor (colour + gradient layout).
                       Used when the ONNX model is not installed, and in tests.
Both return float32, L2-normalized vectors, so the rest of the engine is identical.
"""
from __future__ import annotations

import logging
from typing import Protocol

import cv2
import numpy as np

from ..app.config import EngineSettings
from . import registry, runtime

log = logging.getLogger("rea_spo.embeddings")

SIGLIP_ID = "siglip2-base-p16-224-image"


class Embedder(Protocol):
    model_id: str
    dim: int
    default_min_sim: float

    def embed(self, crops: list[np.ndarray]) -> np.ndarray: ...


def pad_square(rgb: np.ndarray, value: int = 255) -> np.ndarray:
    """Pad to a square on white so the product's shape is not distorted by resizing."""
    h, w = rgb.shape[:2]
    if h == w:
        return rgb
    s = max(h, w)
    out = np.full((s, s, 3), value, np.uint8)
    y, x = (s - h) // 2, (s - w) // 2
    out[y:y + h, x:x + w] = rgb
    return out


def l2n(v: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(v, axis=-1, keepdims=True)
    return (v / np.maximum(n, 1e-12)).astype(np.float32)


class SiglipOnnxEmbedder:
    def __init__(self, spec: registry.ModelSpec, use_gpu: bool = True):
        self.spec = spec
        self.model_id = spec.model_id
        self.dim = spec.dim
        self.default_min_sim = spec.candidate_min_sim or 0.70
        size = spec.input_size
        dummy = {self._input_name_from_path(): np.zeros((1, 3, size, size), np.float32)}
        self.session = runtime.create_session(spec.path, use_gpu=use_gpu, self_test_input=dummy)
        self.input_name = self.session.get_inputs()[0].name
        self.mean = np.array(spec.mean, np.float32).reshape(1, 1, 3)
        self.std = np.array(spec.std, np.float32).reshape(1, 1, 3)

    def _input_name_from_path(self) -> str:
        import onnxruntime as ort
        s = ort.InferenceSession(str(self.spec.path), providers=["CPUExecutionProvider"])
        return s.get_inputs()[0].name

    def _prep(self, rgb: np.ndarray) -> np.ndarray:
        size = self.spec.input_size
        img = cv2.resize(pad_square(rgb), (size, size), interpolation=cv2.INTER_CUBIC).astype(np.float32) / 255.0
        img = (img - self.mean) / self.std
        return img.transpose(2, 0, 1)

    def embed(self, crops: list[np.ndarray]) -> np.ndarray:
        batch = np.stack([self._prep(c) for c in crops]).astype(np.float32)
        outs = self.session.run(None, {self.input_name: batch})
        emb = next(o for o in outs if o.ndim == 2)
        return l2n(emb)


class ClassicEmbedder:
    """Colour histogram + HOG layout + tiny grayscale thumbnail on the padded product crop.
    Not a substitute for SigLIP 2 on real photos; it is the dependable fallback and test double."""

    model_id = "classic-v1"
    default_min_sim = 0.60
    SIZE = 128

    def __init__(self):
        self.hog = cv2.HOGDescriptor((self.SIZE, self.SIZE), (32, 32), (32, 32), (16, 16), 9)
        self.dim = 144 + int(self.hog.getDescriptorSize()) + 144

    def _one(self, rgb: np.ndarray) -> np.ndarray:
        sq = cv2.resize(pad_square(rgb), (self.SIZE, self.SIZE), interpolation=cv2.INTER_AREA)
        lab = cv2.cvtColor(sq, cv2.COLOR_RGB2LAB)
        nonwhite = (np.abs(lab[..., 1].astype(int) - 128) + np.abs(lab[..., 2].astype(int) - 128)
                    + (255 - lab[..., 0].astype(int))) > 12
        px = lab.reshape(-1, 3)[nonwhite.reshape(-1)] if nonwhite.any() else lab.reshape(-1, 3)
        hist, _ = np.histogramdd(px.astype(np.float32), bins=(4, 6, 6), range=((0, 256), (0, 256), (0, 256)))
        color = np.sqrt(hist.flatten() / max(1, len(px)))
        gray = cv2.cvtColor(sq, cv2.COLOR_RGB2GRAY)
        hog = self.hog.compute(gray).flatten()
        tiny = cv2.resize(gray, (12, 12), interpolation=cv2.INTER_AREA).astype(np.float32).flatten()
        tiny -= tiny.mean()
        parts = [l2n(color) * 0.55, l2n(hog) * 0.65, l2n(tiny) * 0.5]
        return np.concatenate(parts)

    def embed(self, crops: list[np.ndarray]) -> np.ndarray:
        return l2n(np.stack([self._one(c) for c in crops]))


def get_embedder(settings: EngineSettings) -> Embedder:
    want = settings.embedder
    if want not in ("auto", "siglip2", "classic"):
        # any model id from models/manifest.json, e.g. a DINOv2 export used for benchmarking
        spec = registry.find_model(want)
        if spec is None:
            raise RuntimeError(f"model {want} is not installed in the models folder")
        return SiglipOnnxEmbedder(spec, use_gpu=settings.use_gpu)
    if want in ("auto", "siglip2"):
        spec = registry.find_model(SIGLIP_ID)
        if spec is not None:
            try:
                return SiglipOnnxEmbedder(spec, use_gpu=settings.use_gpu)
            except Exception:  # noqa: BLE001
                log.exception("could not load SigLIP 2; falling back to the classic embedder")
        if want == "siglip2":
            raise RuntimeError(f"model {SIGLIP_ID} is not installed in the models folder")
        log.warning("SigLIP 2 model not installed - using the classic embedder")
    return ClassicEmbedder()
