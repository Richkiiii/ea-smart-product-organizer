"""Job control (pause / resume / cancel) and throttled progress reporting."""
from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Callable


class Cancelled(Exception):
    pass


class JobControl:
    def __init__(self):
        self._run = threading.Event()
        self._run.set()
        self._cancel = threading.Event()

    def pause(self) -> None:
        self._run.clear()

    def resume(self) -> None:
        self._run.set()

    def cancel(self) -> None:
        self._cancel.set()
        self._run.set()

    @property
    def paused(self) -> bool:
        return not self._run.is_set()

    @property
    def cancelled(self) -> bool:
        return self._cancel.is_set()

    def checkpoint(self) -> None:
        """Called between work items: blocks while paused, raises if cancelled."""
        self._run.wait()
        if self._cancel.is_set():
            raise Cancelled()


@dataclass
class Progress:
    stage: str
    done: int = 0
    total: int = 0
    message: str = ""
    started: float = field(default_factory=time.monotonic)
    counters: dict = field(default_factory=dict)

    @property
    def rate(self) -> float:
        dt = time.monotonic() - self.started
        return self.done / dt if dt > 0 else 0.0

    @property
    def eta_seconds(self) -> float | None:
        r = self.rate
        return (self.total - self.done) / r if r > 0 and self.total else None


class ProgressReporter:
    """Calls the callback at most `hz` times per second (the UI must never be flooded)."""

    def __init__(self, cb: Callable[[Progress], None] | None, hz: float = 10.0):
        self.cb = cb
        self.min_dt = 1.0 / hz
        self._last = 0.0

    def __call__(self, p: Progress, force: bool = False) -> None:
        if not self.cb:
            return
        now = time.monotonic()
        if force or now - self._last >= self.min_dt:
            self._last = now
            self.cb(p)
