-- REA Smart Product Organizer - project database, schema version 1
-- Matches the Phase 1 blueprint, plus match_candidates (Stage 6 output).

CREATE TABLE project_info (
  id INTEGER PRIMARY KEY CHECK (id = 1), name TEXT NOT NULL,
  settings_json TEXT NOT NULL, model_versions_json TEXT NOT NULL DEFAULT '{}',
  quality_preset TEXT NOT NULL DEFAULT 'ecommerce', created_at TEXT NOT NULL
);

CREATE TABLE source_folders (
  id INTEGER PRIMARY KEY, path TEXT NOT NULL, volume_serial TEXT, volume_label TEXT,
  drive_type TEXT, include_subfolders INTEGER NOT NULL DEFAULT 1, exclude_globs TEXT,
  added_at TEXT NOT NULL, last_scanned_at TEXT, is_online INTEGER NOT NULL DEFAULT 1,
  UNIQUE (volume_serial, path)
);

CREATE TABLE contents (
  id INTEGER PRIMARY KEY, sha256 BLOB NOT NULL UNIQUE,
  width INTEGER, height INTEGER, format TEXT, color_mode TEXT, has_alpha INTEGER,
  jpeg_quality INTEGER, status TEXT NOT NULL, error TEXT,
  analysed_stage INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE images (
  id INTEGER PRIMARY KEY,
  source_folder_id INTEGER NOT NULL REFERENCES source_folders(id),
  rel_path TEXT NOT NULL, file_name TEXT NOT NULL, ext TEXT NOT NULL,
  size_bytes INTEGER NOT NULL, mtime_ns INTEGER NOT NULL,
  content_id INTEGER REFERENCES contents(id),
  state TEXT NOT NULL DEFAULT 'present',
  first_seen_job INTEGER, last_seen_job INTEGER,
  UNIQUE (source_folder_id, rel_path)
);

CREATE TABLE image_fingerprints (
  content_id INTEGER PRIMARY KEY REFERENCES contents(id),
  phash_full INTEGER, dhash_full INTEGER, phash_crop INTEGER, dhash_crop INTEGER,
  crop_x INTEGER, crop_y INTEGER, crop_w INTEGER, crop_h INTEGER,
  mask_coverage REAL, mask_touches_border INTEGER, segmentation_uncertain INTEGER,
  silhouette_aspect REAL, hu_moments BLOB, dominant_colors_json TEXT, hue_hist BLOB,
  category TEXT, category_conf REAL, keypoints_cached INTEGER NOT NULL DEFAULT 0,
  model_version TEXT NOT NULL
);

CREATE TABLE embeddings (
  content_id INTEGER NOT NULL REFERENCES contents(id), model_id TEXT NOT NULL,
  dim INTEGER NOT NULL, vector BLOB NOT NULL, matrix_row INTEGER,
  PRIMARY KEY (content_id, model_id)
);

CREATE TABLE ocr_results (
  content_id INTEGER NOT NULL REFERENCES contents(id), model_id TEXT NOT NULL,
  full_text TEXT, normalized_text TEXT, mean_conf REAL, boxes_json TEXT, created_at TEXT,
  PRIMARY KEY (content_id, model_id)
);

CREATE TABLE product_attributes (
  id INTEGER PRIMARY KEY, content_id INTEGER NOT NULL REFERENCES contents(id),
  kind TEXT NOT NULL, value_norm TEXT NOT NULL, unit TEXT, raw_text TEXT, confidence REAL NOT NULL
);

CREATE TABLE quality_scores (
  content_id INTEGER NOT NULL REFERENCES contents(id), preset TEXT NOT NULL,
  raw_json TEXT NOT NULL, normalized_json TEXT NOT NULL, total REAL NOT NULL,
  effective_resolution INTEGER, gates_failed TEXT, model_version TEXT NOT NULL,
  PRIMARY KEY (content_id, preset)
);

CREATE TABLE match_candidates (
  content_a INTEGER NOT NULL REFERENCES contents(id),
  content_b INTEGER NOT NULL REFERENCES contents(id),
  source TEXT NOT NULL,              -- hash | embedding | hash+embedding
  embed_sim REAL, phash_dist INTEGER, rank_ab INTEGER,
  model_id TEXT NOT NULL,
  CHECK (content_a < content_b), PRIMARY KEY (content_a, content_b, model_id)
);

CREATE TABLE match_pairs (
  id INTEGER PRIMARY KEY,
  content_a INTEGER NOT NULL REFERENCES contents(id),
  content_b INTEGER NOT NULL REFERENCES contents(id),
  source TEXT NOT NULL,
  embed_sim REAL, phash_dist INTEGER, geo_inliers INTEGER, geo_ratio REAL, geo_coverage REAL,
  color_dist REAL, shape_diff REAL, ocr_sim REAL, vetoes TEXT,
  confidence REAL, decision TEXT NOT NULL, engine_version TEXT NOT NULL, job_id INTEGER,
  CHECK (content_a < content_b), UNIQUE (content_a, content_b, engine_version)
);

CREATE TABLE processing_history (
  id INTEGER PRIMARY KEY, action TEXT NOT NULL, summary TEXT NOT NULL,
  undo_payload_json TEXT, created_at TEXT NOT NULL,
  undone_at TEXT, undo_of INTEGER REFERENCES processing_history(id)
);

CREATE TABLE match_decisions (
  id INTEGER PRIMARY KEY,
  content_a INTEGER NOT NULL REFERENCES contents(id),
  content_b INTEGER NOT NULL REFERENCES contents(id),
  label TEXT NOT NULL, created_at TEXT NOT NULL,
  history_id INTEGER REFERENCES processing_history(id),
  CHECK (content_a < content_b), UNIQUE (content_a, content_b)
);

CREATE TABLE product_groups (
  id INTEGER PRIMARY KEY, group_no INTEGER NOT NULL UNIQUE, product_name TEXT,
  status TEXT NOT NULL, confidence REAL, best_image_id INTEGER REFERENCES images(id),
  best_reason TEXT, best_overridden INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL
);

CREATE TABLE group_members (
  group_id INTEGER NOT NULL REFERENCES product_groups(id) ON DELETE CASCADE,
  image_id INTEGER NOT NULL REFERENCES images(id),
  role TEXT NOT NULL DEFAULT 'member', added_by TEXT NOT NULL,
  PRIMARY KEY (group_id, image_id)
);

CREATE TABLE processing_jobs (
  id INTEGER PRIMARY KEY, type TEXT NOT NULL, status TEXT NOT NULL,
  params_json TEXT, current_stage INTEGER, done INTEGER, total INTEGER,
  checkpoint_json TEXT, started_at TEXT, finished_at TEXT, error TEXT
);

CREATE TABLE file_operations (
  id INTEGER PRIMARY KEY, history_id INTEGER NOT NULL REFERENCES processing_history(id),
  op TEXT NOT NULL, src_path TEXT NOT NULL, dst_path TEXT, sha256 BLOB, size_bytes INTEGER,
  status TEXT NOT NULL, created_at TEXT NOT NULL, completed_at TEXT, error TEXT
);

CREATE TABLE quarantine_records (
  id INTEGER PRIMARY KEY, image_id INTEGER NOT NULL REFERENCES images(id),
  file_operation_id INTEGER NOT NULL REFERENCES file_operations(id),
  original_path TEXT NOT NULL, quarantine_path TEXT NOT NULL, sha256 BLOB NOT NULL,
  quarantined_at TEXT NOT NULL, restored_at TEXT, purged_at TEXT
);

CREATE TABLE image_errors (
  id INTEGER PRIMARY KEY, job_id INTEGER, path TEXT NOT NULL, stage INTEGER,
  error TEXT NOT NULL, created_at TEXT NOT NULL
);

CREATE INDEX ix_images_content     ON images(content_id);
CREATE INDEX ix_images_state       ON images(state);
CREATE INDEX ix_contents_stage     ON contents(analysed_stage);
CREATE INDEX ix_fp_phash_crop      ON image_fingerprints(phash_crop);
CREATE INDEX ix_fp_category        ON image_fingerprints(category);
CREATE INDEX ix_attr_content_kind  ON product_attributes(content_id, kind);
CREATE INDEX ix_cand_b             ON match_candidates(content_b);
CREATE INDEX ix_pairs_a            ON match_pairs(content_a);
CREATE INDEX ix_pairs_b            ON match_pairs(content_b);
CREATE INDEX ix_pairs_review       ON match_pairs(decision, confidence);
CREATE INDEX ix_members_image      ON group_members(image_id);
CREATE INDEX ix_groups_status      ON product_groups(status);
CREATE INDEX ix_fileops_status     ON file_operations(status);
CREATE INDEX ix_quarantine_open    ON quarantine_records(restored_at, purged_at);
