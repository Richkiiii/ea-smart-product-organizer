"""SQLite access: migrations, per-thread connections and a single batched writer thread.

SQLite allows one writer at a time. All pipeline results are funnelled through
`DbWriter`, which commits in transactions of up to `batch` operations. Readers open
their own connections (WAL mode lets them read while the writer writes).
"""
from __future__ import annotations

import logging
import queue
import sqlite3
import threading
from datetime import datetime, timezone
from importlib import resources
from pathlib import Path
from typing import Callable

log = logging.getLogger("rea_spo.db")

SCHEMA_VERSION = 1


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _migrations() -> list[tuple[int, str]]:
    out = []
    pkg = resources.files("rea_spo.storage") / "migrations"
    for entry in pkg.iterdir():
        name = entry.name
        if name.endswith(".sql") and name[:4].isdigit():
            out.append((int(name[:4]), entry.read_text(encoding="utf-8")))
    return sorted(out)


def connect(path: Path | str, readonly: bool = False) -> sqlite3.Connection:
    if readonly:
        uri = Path(path).resolve().as_uri() + "?mode=ro"
        conn = sqlite3.connect(uri, uri=True, timeout=30, check_same_thread=False)
    else:
        conn = sqlite3.connect(str(path), timeout=30, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA busy_timeout=30000")
    if not readonly:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
    return conn


def migrate(conn: sqlite3.Connection) -> int:
    current = conn.execute("PRAGMA user_version").fetchone()[0]
    for version, sql in _migrations():
        if version > current:
            log.info("applying migration %04d", version)
            conn.executescript("BEGIN;" + sql + f";PRAGMA user_version={version};COMMIT;")
            current = version
    return current


class DbWriter:
    """Single writer thread. Submit callables taking a connection; they run in order."""

    _STOP = object()

    def __init__(self, path: Path | str, batch: int = 500):
        self.path = Path(path)
        self.batch = batch
        self._q: queue.Queue = queue.Queue(maxsize=10_000)
        self._error: BaseException | None = None
        self._thread = threading.Thread(target=self._run, name="db-writer", daemon=True)
        self._thread.start()

    def submit(self, fn: Callable[[sqlite3.Connection], None]) -> None:
        if self._error:
            raise RuntimeError("database writer failed") from self._error
        self._q.put(fn)

    def flush(self) -> None:
        """Block until everything submitted so far is committed."""
        done = threading.Event()
        self._q.put(("flush", done))
        done.wait()
        if self._error:
            raise RuntimeError("database writer failed") from self._error

    def close(self) -> None:
        self._q.put(self._STOP)
        self._thread.join()
        if self._error:
            raise RuntimeError("database writer failed") from self._error

    def _run(self) -> None:
        conn = connect(self.path)
        pending = 0
        try:
            while True:
                item = self._q.get()
                if item is self._STOP:
                    conn.commit()
                    return
                if isinstance(item, tuple) and item[0] == "flush":
                    conn.commit()
                    pending = 0
                    item[1].set()
                    continue
                try:
                    item(conn)
                except Exception as exc:  # keep the writer alive; record the failure
                    log.exception("db write failed")
                    self._error = exc
                pending += 1
                if pending >= self.batch or self._q.empty():
                    conn.commit()
                    pending = 0
        finally:
            conn.close()
