"""Stage 1 - read-only file discovery.

Nothing in this module writes to a source folder. Files are only listed (os.scandir)
and later opened with mode 'rb'.
"""
from __future__ import annotations

import fnmatch
import logging
import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator

from ..app.config import APP_FOLDER_NAMES, SUPPORTED_EXTENSIONS

log = logging.getLogger("rea_spo.scanner")

# leading bytes -> format
_MAGIC = [
    (b"\xff\xd8\xff", "JPEG"),
    (b"\x89PNG\r\n\x1a\n", "PNG"),
    (b"RIFF", "WEBP"),  # confirmed by bytes 8..12 == WEBP
    (b"BM", "BMP"),
    (b"II*\x00", "TIFF"),
    (b"MM\x00*", "TIFF"),
]


def sniff_format(head: bytes) -> str | None:
    for magic, fmt in _MAGIC:
        if head.startswith(magic):
            if fmt == "WEBP" and head[8:12] != b"WEBP":
                return None
            return fmt
    return None


def long_path(p: str | Path) -> str:
    """Windows long-path form so paths over 260 characters work."""
    s = str(p)
    if sys.platform == "win32" and not s.startswith("\\\\?\\"):
        s = os.path.abspath(s)
        if s.startswith("\\\\"):
            return "\\\\?\\UNC\\" + s[2:]
        return "\\\\?\\" + s
    return s


@dataclass(frozen=True)
class FoundFile:
    rel_path: str      # always '/'-separated, relative to the source root
    size: int
    mtime_ns: int


def iter_images(root: str | Path, include_subfolders: bool = True,
                exclude_globs: list[str] | None = None, errors: list | None = None) -> Iterator[FoundFile]:
    """Iterative walk (no recursion limit). Errors are collected, never raised."""
    root = Path(root)
    excl = exclude_globs or []
    stack = [""]
    while stack:
        rel_dir = stack.pop()
        full_dir = root / rel_dir if rel_dir else root
        try:
            with os.scandir(long_path(full_dir)) as it:
                entries = sorted(it, key=lambda e: e.name)
        except OSError as exc:
            if errors is not None:
                errors.append((str(full_dir), f"cannot list folder: {exc}"))
            continue
        for e in entries:
            rel = f"{rel_dir}/{e.name}" if rel_dir else e.name
            try:
                if e.is_dir(follow_symlinks=False):
                    if e.name in APP_FOLDER_NAMES or e.name.startswith("."):
                        continue
                    if include_subfolders and not any(fnmatch.fnmatch(rel, g) for g in excl):
                        stack.append(rel)
                    continue
                if not e.is_file(follow_symlinks=False):
                    continue
                if os.path.splitext(e.name)[1].lower() not in SUPPORTED_EXTENSIONS:
                    continue
                if any(fnmatch.fnmatch(rel, g) for g in excl):
                    continue
                st = e.stat(follow_symlinks=False)
                yield FoundFile(rel, st.st_size, st.st_mtime_ns)
            except OSError as exc:
                if errors is not None:
                    errors.append((str(root / rel), f"cannot stat: {exc}"))


# --------------------------------------------------------------------------- drive info

def volume_info(path: Path) -> tuple[str | None, str | None, str]:
    """(volume serial, label, drive type) - drive type is ssd | hdd | removable | network | unknown."""
    if sys.platform == "win32":
        return _volume_info_windows(path)
    return None, None, _drive_type_linux(path)


def _drive_type_linux(path: Path) -> str:
    try:
        st = os.stat(path)
        major, minor = os.major(st.st_dev), os.minor(st.st_dev)
        base = Path(f"/sys/dev/block/{major}:{minor}")
        for cand in (base / "queue" / "rotational", base / ".." / "queue" / "rotational"):
            if cand.exists():
                return "hdd" if cand.read_text().strip() == "1" else "ssd"
    except OSError:
        pass
    return "unknown"


def _volume_info_windows(path: Path) -> tuple[str | None, str | None, str]:  # pragma: no cover - Windows only
    import ctypes
    from ctypes import wintypes

    k32 = ctypes.windll.kernel32
    drive = os.path.splitdrive(str(path.resolve()))[0] + "\\"
    serial = wintypes.DWORD()
    label = ctypes.create_unicode_buffer(261)
    fs = ctypes.create_unicode_buffer(261)
    ok = k32.GetVolumeInformationW(drive, label, 261, ctypes.byref(serial), None, None, fs, 261)
    dtype_code = k32.GetDriveTypeW(drive)
    kind = {2: "removable", 3: "fixed", 4: "network", 6: "ssd"}.get(dtype_code, "unknown")
    if kind == "fixed":
        kind = _seek_penalty(drive)
    return (f"{serial.value:08X}" if ok else None, label.value if ok else None, kind)


def _seek_penalty(drive: str) -> str:  # pragma: no cover - Windows only
    """IOCTL_STORAGE_QUERY_PROPERTY / StorageDeviceSeekPenaltyProperty: no seek penalty = SSD."""
    import ctypes
    from ctypes import wintypes

    k32 = ctypes.windll.kernel32
    handle = k32.CreateFileW(f"\\\\.\\{drive[:2]}", 0, 3, None, 3, 0, None)
    if handle in (-1, 0xFFFFFFFF):
        return "unknown"
    try:
        query = (ctypes.c_uint32 * 3)(7, 0, 0)          # PropertyId=7, PropertyStandardQuery
        out = (ctypes.c_uint32 * 2)()                   # Version, Size, then BOOLEAN
        out_buf = ctypes.create_string_buffer(12)
        returned = wintypes.DWORD()
        ok = k32.DeviceIoControl(handle, 0x2D1400, query, ctypes.sizeof(query), out_buf, 12,
                                 ctypes.byref(returned), None)
        del out
        if not ok:
            return "unknown"
        incurs_penalty = out_buf.raw[8]
        return "hdd" if incurs_penalty else "ssd"
    finally:
        k32.CloseHandle(handle)


def reader_threads_for(drive_type: str, cpu_count: int | None = None) -> int:
    cpus = cpu_count or os.cpu_count() or 4
    if drive_type == "hdd":
        return 2
    if drive_type in ("removable", "network", "unknown"):
        return max(2, min(4, cpus))
    return max(2, min(12, cpus + 2))
