"""REA Smart Product Organizer - engine package."""

__version__ = "0.3.0.dev0"
ENGINE_VERSION = "engine-0.3"
