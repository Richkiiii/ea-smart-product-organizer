"""Stage 2 - validation and decoding (read-only).

A file is read exactly once into memory; the same bytes feed the SHA-256 hash,
the decoder and the JPEG-quality estimate.
"""
from __future__ import annotations

import hashlib
import io
import warnings
from dataclasses import dataclass, field

import cv2
import numpy as np
from PIL import Image, ImageCms, ImageFile, ImageOps

from ..files.scanner import long_path, sniff_format

Image.MAX_IMAGE_PIXELS = 400_000_000  # allow very large product shots, still guard against bombs

# libjpeg standard luminance quantization table (quality 50), natural order
_STD_LUMA = np.array([
    16, 11, 10, 16, 24, 40, 51, 61, 12, 12, 14, 19, 26, 58, 60, 55,
    14, 13, 16, 24, 40, 57, 69, 56, 14, 17, 22, 29, 51, 87, 80, 62,
    18, 22, 37, 56, 68, 109, 103, 77, 24, 35, 55, 64, 81, 104, 113, 92,
    49, 64, 78, 87, 103, 121, 120, 101, 72, 92, 95, 98, 112, 100, 103, 99], dtype=np.float64)

_SRGB = ImageCms.createProfile("sRGB")


@dataclass
class DecodedImage:
    sha256: bytes
    size_bytes: int
    status: str                      # valid | truncated | corrupt | unsupported | too_small
    rgb: np.ndarray | None = None    # HxWx3 uint8, sRGB, EXIF-oriented, alpha flattened on white
    width: int = 0
    height: int = 0
    format: str | None = None
    color_mode: str | None = None
    has_alpha: bool = False
    jpeg_quality: int | None = None
    error: str | None = None
    notes: list[str] = field(default_factory=list)


def estimate_jpeg_quality(img: Image.Image) -> int | None:
    """Estimate the libjpeg quality factor from the luminance quantization table."""
    q = getattr(img, "quantization", None)
    if not q:
        return None
    table = np.array(q.get(0, list(q.values())[0]), dtype=np.float64)
    if table.size != 64:
        return None
    scale = float(np.mean(table / _STD_LUMA) * 100.0)
    if scale <= 0:
        return 100
    quality = (200.0 - scale) / 2.0 if scale <= 100 else 5000.0 / scale
    return int(round(min(100.0, max(1.0, quality))))


def read_bytes(path: str) -> bytes:
    with open(long_path(path), "rb") as f:      # read-only
        return f.read()


def decode_bytes(data: bytes, min_side: int = 64) -> DecodedImage:
    sha = hashlib.sha256(data).digest()
    out = DecodedImage(sha256=sha, size_bytes=len(data), status="valid")
    fmt = sniff_format(data[:16])
    if fmt is None:
        out.status, out.error = "unsupported", "unrecognized file signature"
        return out
    out.format = fmt
    img = None
    try:
        img = Image.open(io.BytesIO(data))
        img.load()
    except OSError as exc:
        # retry tolerating truncation so a partially readable image can still be reviewed
        msg = str(exc)
        try:
            ImageFile.LOAD_TRUNCATED_IMAGES = True
            img = Image.open(io.BytesIO(data))
            img.load()
            out.status, out.error = "truncated", msg
        except Exception as exc2:  # noqa: BLE001
            img = None
            out.error = f"{msg}; {exc2}"
        finally:
            ImageFile.LOAD_TRUNCATED_IMAGES = False
    except Exception as exc:  # noqa: BLE001
        out.error = str(exc)
        img = None

    if img is None:
        arr = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
        if arr is None:
            out.status = "corrupt"
            return out
        out.rgb = cv2.cvtColor(arr, cv2.COLOR_BGR2RGB)
        out.notes.append("decoded by OpenCV fallback")
        out.color_mode = "RGB"
    else:
        out.jpeg_quality = estimate_jpeg_quality(img) if fmt == "JPEG" else None
        out.color_mode = img.mode
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            img = ImageOps.exif_transpose(img)
        icc = img.info.get("icc_profile")
        if img.mode in ("I;16", "I", "F"):
            arr16 = np.asarray(img, dtype=np.float64)
            arr16 = (255 * (arr16 - arr16.min()) / max(1e-9, np.ptp(arr16))).astype(np.uint8)
            img = Image.fromarray(arr16, "L")
        has_alpha = img.mode in ("RGBA", "LA", "PA") or (img.mode == "P" and "transparency" in img.info)
        out.has_alpha = bool(has_alpha)
        if has_alpha:
            rgba = img.convert("RGBA")
            bg = Image.new("RGBA", rgba.size, (255, 255, 255, 255))
            img = Image.alpha_composite(bg, rgba).convert("RGB")
        elif img.mode == "CMYK" or img.mode != "RGB":
            img = img.convert("RGB")
        if icc:
            try:
                src = ImageCms.ImageCmsProfile(io.BytesIO(icc))
                if "srgb" not in (ImageCms.getProfileDescription(src) or "").lower():
                    img = ImageCms.profileToProfile(img, src, _SRGB, outputMode="RGB")
                    out.notes.append("converted ICC profile to sRGB")
            except Exception:  # noqa: BLE001 - a bad profile must not reject the image
                out.notes.append("ignored unreadable ICC profile")
        out.rgb = np.asarray(img, dtype=np.uint8).copy()

    out.height, out.width = out.rgb.shape[:2]
    if min(out.width, out.height) < min_side:
        out.status = "too_small"
    return out


def decode_file(path: str, min_side: int = 64) -> DecodedImage:
    return decode_bytes(read_bytes(path), min_side=min_side)
