"""Product / background separation (Stage 3).

Phase 2 ships the classic path used as the fallback in the blueprint:
  * uniform background  -> colour distance from the border colour (fast, reliable)
  * textured background -> GrabCut initialised with an inset rectangle
A salient-object ONNX model can replace `product_mask` later without changing callers.
"""
from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np

SEG_SIZE = 320


@dataclass
class MaskResult:
    mask: np.ndarray          # uint8 0/255 at the size of the image passed in
    box: tuple[int, int, int, int]   # x, y, w, h
    coverage: float
    touches_border: bool
    uncertain: bool
    method: str


def _largest_components(mask: np.ndarray, min_frac: float = 0.02) -> np.ndarray:
    n, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
    if n <= 1:
        return mask
    area = mask.shape[0] * mask.shape[1]
    keep = np.zeros(n, bool)
    biggest = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    keep[biggest] = True
    for i in range(1, n):
        if stats[i, cv2.CC_STAT_AREA] >= min_frac * area:
            keep[i] = True
    return np.where(keep[labels], 255, 0).astype(np.uint8)


def _fill_holes(mask: np.ndarray) -> np.ndarray:
    h, w = mask.shape
    flood = np.zeros((h + 2, w + 2), np.uint8)
    flood[1:-1, 1:-1] = mask
    ff = np.zeros((h + 4, w + 4), np.uint8)
    cv2.floodFill(flood, ff, (0, 0), 255)          # padding guarantees (0,0) is background
    holes = cv2.bitwise_not(flood)[1:-1, 1:-1]
    return mask | holes


def product_mask(rgb: np.ndarray) -> MaskResult:
    H, W = rgb.shape[:2]
    scale = SEG_SIZE / max(H, W)
    small = cv2.resize(rgb, (max(1, round(W * scale)), max(1, round(H * scale))), interpolation=cv2.INTER_AREA) \
        if scale < 1 else rgb.copy()
    h, w = small.shape[:2]
    lab = cv2.cvtColor(small, cv2.COLOR_RGB2LAB).astype(np.float32)
    b = max(2, int(0.04 * min(h, w)))
    border = np.concatenate([lab[:b].reshape(-1, 3), lab[-b:].reshape(-1, 3),
                             lab[:, :b].reshape(-1, 3), lab[:, -b:].reshape(-1, 3)])
    # Background model: up to 6 border colour clusters (handles shelves, stripes, gradients).
    k = 6
    crit = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 15, 1.0)
    cv2.setRNGSeed(1)
    sample = border[:: max(1, len(border) // 3000)]
    _, lbl, centers = cv2.kmeans(sample, k, None, crit, 2, cv2.KMEANS_PP_CENTERS)
    lbl = lbl.flatten()
    shares = np.bincount(lbl, minlength=k) / len(lbl)
    bgs = [centers[i] for i in range(k) if shares[i] >= 0.02]
    devs = [float(np.median(np.linalg.norm(sample[lbl == i] - centers[i], axis=1)))
            for i in range(k) if shares[i] >= 0.02]
    border_dev = max(devs) if devs else 99.0
    explained = float(np.mean(np.min(np.stack([np.linalg.norm(sample - c, axis=1) for c in bgs]), axis=0) < 20))

    method = "border-colour"
    if border_dev < 10 and explained > 0.9:
        dist = np.min(np.stack([np.linalg.norm(lab - c, axis=2) for c in bgs]), axis=0)
        thr = max(18.0, 3.5 * border_dev)
        mask = (dist > thr).astype(np.uint8) * 255
    else:
        method = "grabcut"
        gc = np.zeros((h, w), np.uint8)
        inset = (max(1, int(0.05 * w)), max(1, int(0.05 * h)))
        rect = (inset[0], inset[1], w - 2 * inset[0], h - 2 * inset[1])
        bgd, fgd = np.zeros((1, 65), np.float64), np.zeros((1, 65), np.float64)
        try:
            cv2.grabCut(cv2.cvtColor(small, cv2.COLOR_RGB2BGR), gc, rect, bgd, fgd, 3, cv2.GC_INIT_WITH_RECT)
            mask = np.where((gc == cv2.GC_FGD) | (gc == cv2.GC_PR_FGD), 255, 0).astype(np.uint8)
        except cv2.error:
            mask = np.full((h, w), 255, np.uint8)

    k = max(3, (min(h, w) // 60) | 1)
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=2)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    mask = _largest_components(mask)
    mask = _fill_holes(mask)

    coverage = float((mask > 0).mean())
    uncertain = coverage < 0.03 or coverage > 0.97 or (method == "grabcut" and coverage > 0.9)
    if uncertain:
        mask = np.full((h, w), 255, np.uint8)
        box = (0, 0, w, h)
    else:
        ys, xs = np.nonzero(mask)
        box = (int(xs.min()), int(ys.min()), int(xs.max() - xs.min() + 1), int(ys.max() - ys.min() + 1))

    edge = lambda a: float((a > 0).mean())  # noqa: E731
    touches = (not uncertain) and max(edge(mask[0]), edge(mask[-1]), edge(mask[:, 0]), edge(mask[:, -1])) > 0.05

    if (h, w) != (H, W):
        sx, sy = W / w, H / h
        mask = cv2.resize(mask, (W, H), interpolation=cv2.INTER_NEAREST)
        box = (int(box[0] * sx), int(box[1] * sy), max(1, int(round(box[2] * sx))), max(1, int(round(box[3] * sy))))
    return MaskResult(mask, box, coverage if not uncertain else 1.0, touches, uncertain, method)
