"""Stage 3 - normalization: working copy, thumbnail, product mask and crop."""
from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np

from .segmentation import MaskResult, product_mask


@dataclass
class Normalized:
    work: np.ndarray            # RGB, long side <= working_size
    crop: np.ndarray            # RGB product crop from `work` (padded 3%)
    crop_mask: np.ndarray       # mask aligned with `crop`
    clean: np.ndarray           # crop with background replaced by white (embedding input)
    seg: MaskResult             # mask/box in `work` coordinates
    scale: float                # work / original
    thumb_webp: bytes


def resize_long(rgb: np.ndarray, long_side: int) -> tuple[np.ndarray, float]:
    h, w = rgb.shape[:2]
    s = long_side / max(h, w)
    if s >= 1:
        return rgb, 1.0
    return cv2.resize(rgb, (max(1, round(w * s)), max(1, round(h * s))), interpolation=cv2.INTER_AREA), s


def normalize(rgb: np.ndarray, working_size: int = 1024, thumb_size: int = 256) -> Normalized:
    work, scale = resize_long(rgb, working_size)
    seg = product_mask(work)
    x, y, w, h = seg.box
    H, W = work.shape[:2]
    pad = int(0.03 * max(w, h))
    x0, y0 = max(0, x - pad), max(0, y - pad)
    x1, y1 = min(W, x + w + pad), min(H, y + h + pad)
    crop = work[y0:y1, x0:x1].copy()
    crop_mask = seg.mask[y0:y1, x0:x1].copy()
    if seg.uncertain:
        clean = crop
    else:
        soft = cv2.GaussianBlur(crop_mask.astype(np.float32) / 255.0, (0, 0), 1.5)[..., None]
        clean = (crop.astype(np.float32) * soft + 255.0 * (1 - soft)).astype(np.uint8)
    thumb, _ = resize_long(work, thumb_size)
    ok, buf = cv2.imencode(".webp", cv2.cvtColor(thumb, cv2.COLOR_RGB2BGR), [cv2.IMWRITE_WEBP_QUALITY, 80])
    return Normalized(work, crop, crop_mask, clean, seg, scale, buf.tobytes() if ok else b"")
