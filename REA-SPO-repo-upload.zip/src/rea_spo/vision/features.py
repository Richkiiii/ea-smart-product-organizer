"""Cheap per-image descriptors: colour and silhouette (Stage 4)."""
from __future__ import annotations

import json

import cv2
import numpy as np


def hue_histogram(rgb: np.ndarray, mask: np.ndarray | None = None, bins: int = 18) -> np.ndarray:
    """Hue histogram weighted by saturation, plus 2 extra bins for dark and light neutrals."""
    hsv = cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV).reshape(-1, 3).astype(np.float32)
    if mask is not None:
        hsv = hsv[mask.reshape(-1) > 0]
    if len(hsv) == 0:
        return np.zeros(bins + 2, np.float32)
    h, s, v = hsv[:, 0], hsv[:, 1] / 255.0, hsv[:, 2] / 255.0
    hist = np.bincount(np.minimum((h / 180.0 * bins).astype(int), bins - 1), weights=s, minlength=bins)
    neutral = 1.0 - s
    dark = float(np.sum(neutral * (v < 0.35)))
    light = float(np.sum(neutral * (v >= 0.35)))
    out = np.concatenate([hist, [dark, light]]).astype(np.float32)
    return out / max(1e-9, out.sum())


def dominant_colors(rgb: np.ndarray, mask: np.ndarray | None = None, k: int = 4, sample: int = 4000) -> list[dict]:
    px = rgb.reshape(-1, 3)
    if mask is not None:
        px = px[mask.reshape(-1) > 0]
    if len(px) == 0:
        return []
    rng = np.random.default_rng(0)
    if len(px) > sample:
        px = px[rng.choice(len(px), sample, replace=False)]
    lab = cv2.cvtColor(px.reshape(-1, 1, 3), cv2.COLOR_RGB2LAB).reshape(-1, 3).astype(np.float32)
    k = min(k, len(lab))
    crit = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 20, 1.0)
    cv2.setRNGSeed(0)
    _, labels, centers = cv2.kmeans(lab, k, None, crit, 2, cv2.KMEANS_PP_CENTERS)
    counts = np.bincount(labels.flatten(), minlength=k)
    order = np.argsort(-counts)
    out = []
    for i in order:
        c = centers[i].clip(0, 255).astype(np.uint8).reshape(1, 1, 3)
        r, g, b = cv2.cvtColor(c, cv2.COLOR_LAB2RGB).reshape(3).tolist()
        out.append({"rgb": [r, g, b], "share": round(float(counts[i] / counts.sum()), 4)})
    return out


def silhouette(mask: np.ndarray, box: tuple[int, int, int, int]) -> tuple[float, bytes]:
    """Rotation-independent pack proportions: long/short side of the minimum-area rectangle
    around the largest outline (a tilted photo must not look like a different pack size)."""
    x, y, w, h = box
    sub = mask[y:y + h, x:x + w]
    contours, _ = cv2.findContours(sub, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if contours:
        (_, _), (rw, rh), _ = cv2.minAreaRect(max(contours, key=cv2.contourArea))
        aspect = max(rw, rh) / max(1.0, min(rw, rh))
    else:
        aspect = max(w, h) / max(1, min(w, h))
    m = cv2.moments(sub, binaryImage=True)
    hu = cv2.HuMoments(m).flatten()
    hu = -np.sign(hu) * np.log10(np.abs(hu) + 1e-30)
    return float(aspect), hu.astype(np.float32).tobytes()


def colors_json(colors: list[dict]) -> str:
    return json.dumps(colors, separators=(",", ":"))
