"""Perceptual hashes and a multi-index hash table for fast near-duplicate lookup."""
from __future__ import annotations

from collections import defaultdict

import cv2
import numpy as np

_MASK64 = (1 << 64) - 1
_PHASH = cv2.img_hash.PHash_create()


def _to_signed(v: int) -> int:
    """Store 64-bit hashes in SQLite's signed INTEGER."""
    return v - (1 << 64) if v >= (1 << 63) else v


def _to_unsigned(v: int) -> int:
    return v & _MASK64


def phash(rgb: np.ndarray) -> int:
    bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
    h = _PHASH.compute(bgr)[0]
    return _to_signed(int.from_bytes(bytes(h.tolist()), "big"))


def dhash(rgb: np.ndarray) -> int:
    g = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    s = cv2.resize(g, (9, 8), interpolation=cv2.INTER_AREA).astype(np.int16)
    bits = (s[:, 1:] > s[:, :-1]).flatten()
    v = 0
    for b in bits:
        v = (v << 1) | int(b)
    return _to_signed(v)


def hamming(a: int, b: int) -> int:
    return (_to_unsigned(a) ^ _to_unsigned(b)).bit_count()


class HashIndex:
    """Multi-index hashing: the 64-bit hash is split into 8 bytes. Two hashes within
    Hamming distance <= 7 share at least one identical byte (pigeonhole), so only items
    sharing a byte at the same position are compared."""

    CHUNKS = 8

    def __init__(self):
        self._tables = [defaultdict(list) for _ in range(self.CHUNKS)]
        self._items: list[tuple[int, int]] = []   # (id, unsigned hash)

    def add(self, item_id: int, h: int) -> None:
        u = _to_unsigned(h)
        idx = len(self._items)
        self._items.append((item_id, u))
        for c in range(self.CHUNKS):
            self._tables[c][(u >> (8 * c)) & 0xFF].append(idx)

    def __len__(self) -> int:
        return len(self._items)

    def pairs_within(self, max_dist: int) -> list[tuple[int, int, int]]:
        if max_dist >= self.CHUNKS:
            raise ValueError("multi-index search supports max_dist < 8")
        seen = set()
        out = []
        for c in range(self.CHUNKS):
            for bucket in self._tables[c].values():
                if len(bucket) < 2:
                    continue
                for i in range(len(bucket)):
                    ia = bucket[i]
                    ida, ha = self._items[ia]
                    for j in range(i + 1, len(bucket)):
                        ib = bucket[j]
                        key = (ia, ib) if ia < ib else (ib, ia)
                        if key in seen:
                            continue
                        seen.add(key)
                        idb, hb = self._items[ib]
                        d = (ha ^ hb).bit_count()
                        if d <= max_dist and ida != idb:
                            out.append((min(ida, idb), max(ida, idb), d))
        return out
