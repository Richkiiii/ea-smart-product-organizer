"""RootSIFT local features (Stage 4) and VLAD aggregation (Stage 6 candidate source).

Local features are cached per content (cache/kp/xx/<sha>.npz, uint8 descriptors) because
Stage 7 geometric verification re-uses them. VLAD turns each image's descriptors into one
global vector that is very good at finding *the same printed label* across backgrounds,
scales and moderate angles - complementary to semantic embeddings.
"""
from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np

LF_SIZE = 512
MAX_FEATURES = 400
_SIFT = None


def _sift():
    global _SIFT
    if _SIFT is None:
        _SIFT = cv2.SIFT_create(nfeatures=MAX_FEATURES, contrastThreshold=0.03)
    return _SIFT


def extract(rgb: np.ndarray, mask: np.ndarray | None = None) -> tuple[np.ndarray, np.ndarray]:
    """Returns (keypoints float16 [n,4]: x, y, size, angle in LF_SIZE scale; descriptors uint8 [n,128])."""
    h, w = rgb.shape[:2]
    s = LF_SIZE / max(h, w)
    if s != 1:
        rgb = cv2.resize(rgb, (max(1, round(w * s)), max(1, round(h * s))),
                         interpolation=cv2.INTER_AREA if s < 1 else cv2.INTER_CUBIC)
        if mask is not None:
            mask = cv2.resize(mask, (rgb.shape[1], rgb.shape[0]), interpolation=cv2.INTER_NEAREST)
    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    kps, desc = _sift().detectAndCompute(gray, mask)
    if desc is None or len(kps) == 0:
        return np.zeros((0, 4), np.float16), np.zeros((0, 128), np.uint8)
    desc = desc / np.maximum(desc.sum(axis=1, keepdims=True), 1e-7)       # RootSIFT
    desc = np.sqrt(desc)
    d8 = np.clip(desc * 512.0, 0, 255).astype(np.uint8)
    kp = np.array([[k.pt[0], k.pt[1], k.size, k.angle] for k in kps], np.float16)
    return kp, d8


def to_float(d8: np.ndarray) -> np.ndarray:
    d = d8.astype(np.float32) / 512.0
    return d / np.maximum(np.linalg.norm(d, axis=1, keepdims=True), 1e-7)


def save(path: Path, kp: np.ndarray, d8: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez(path, kp=kp, d=d8)


def load(path: Path) -> tuple[np.ndarray, np.ndarray] | None:
    try:
        with np.load(path) as z:
            return z["kp"], z["d"]
    except (OSError, KeyError, ValueError):
        return None


# ------------------------------------------------------------------ VLAD

def train_codebook(desc_sample: np.ndarray, k: int = 64, seed: int = 0) -> np.ndarray:
    crit = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 1e-3)
    cv2.setRNGSeed(seed)
    k = min(k, max(2, len(desc_sample) // 20))
    _, _, centers = cv2.kmeans(desc_sample.astype(np.float32), k, None, crit, 2, cv2.KMEANS_PP_CENTERS)
    return centers.astype(np.float32)


def vlad(desc: np.ndarray, centers: np.ndarray) -> np.ndarray:
    k, d = centers.shape
    v = np.zeros((k, d), np.float32)
    if len(desc):
        dists = ((desc[:, None, :] - centers[None]) ** 2).sum(-1) if len(desc) * k < 2_000_000 else None
        if dists is None:
            assign = np.array([np.argmin(((centers - x) ** 2).sum(1)) for x in desc])
        else:
            assign = dists.argmin(1)
        for c in range(k):
            sel = desc[assign == c]
            if len(sel):
                v[c] = (sel - centers[c]).sum(0)
        v /= np.maximum(np.linalg.norm(v, axis=1, keepdims=True), 1e-7)   # intra-normalization
    v = v.flatten()
    v = np.sign(v) * np.sqrt(np.abs(v))                                    # power normalization
    return v / max(1e-7, float(np.linalg.norm(v)))


def pca_fit(x: np.ndarray, dim: int = 256) -> tuple[np.ndarray, np.ndarray]:
    mean = x.mean(0)
    xc = x - mean
    dim = min(dim, xc.shape[0] - 1, xc.shape[1])
    _, s, vt = np.linalg.svd(xc, full_matrices=False)
    comps = vt[:dim] / np.maximum(s[:dim, None], 1e-6) * np.sqrt(len(x))   # whitening
    return mean.astype(np.float32), comps.astype(np.float32)


def pca_apply(x: np.ndarray, mean: np.ndarray, comps: np.ndarray) -> np.ndarray:
    y = (x - mean) @ comps.T
    return (y / np.maximum(np.linalg.norm(y, axis=1, keepdims=True), 1e-7)).astype(np.float32)
