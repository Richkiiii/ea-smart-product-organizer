"""Product attributes from OCR text: quantity, pack count, percentage, variant and brand.

All values are normalized so that equal products compare equal:
  "0,5 L" == "500ml" == "50 cl"  -> quantity 500 ml
  "1kg"   == "1000 g"            -> quantity 1000 g
  "6 x 330 ml"                   -> pack_count 6 + quantity 330 ml
Vetoes are only raised from readings with confidence >= min_conf on BOTH images.
"""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass

# unit -> (base unit, factor)
UNITS = {
    "ml": ("ml", 1), "cl": ("ml", 10), "dl": ("ml", 100), "l": ("ml", 1000), "ltr": ("ml", 1000),
    "liter": ("ml", 1000), "litre": ("ml", 1000), "g": ("g", 1), "gr": ("g", 1), "kg": ("g", 1000),
    "mg": ("g", 0.001), "oz": ("g", 28.3495), "floz": ("ml", 29.5735), "db": ("pcs", 1), "pcs": ("pcs", 1),
}
_NUM = r"(\d{1,4}(?:[.,]\d{1,3})?)"
_UNIT = r"(fl\.?\s?oz|ml|cl|dl|ltr|liter|litre|l|kg|mg|gr|g|oz|db|pcs)"
QTY_RE = re.compile(rf"(?<![\w.,]){_NUM}\s?{_UNIT}(?![a-z])")
PACK_RE = re.compile(rf"(?<!\w)(\d{{1,3}})\s?[x×*]\s?{_NUM}\s?{_UNIT}(?![a-z])")
PERCENT_RE = re.compile(rf"(?<![\w.,]){_NUM}\s?%")

# variant words: canonical -> spellings (English + Hungarian). Extendable from Settings.
VARIANTS = {
    "zero": ["zero", "0 sugar", "no sugar"], "light": ["light", "lite"], "diet": ["diet"],
    "sugar_free": ["sugar free", "sugarfree", "cukormentes"], "classic": ["classic", "klasszikus"],
    "original": ["original", "eredeti"], "cherry": ["cherry", "meggy", "cseresznye"],
    "lemon": ["lemon", "citrom"], "orange": ["orange", "narancs"], "mint": ["mint", "menta"],
    "vanilla": ["vanilla", "vanilia"], "strawberry": ["strawberry", "eper"],
    "chocolate": ["chocolate", "csokolade", "kakao"], "bio": ["bio", "organic"],
    "lactose_free": ["lactose free", "laktozmentes"], "decaf": ["decaf", "koffeinmentes"],
    "sparkling": ["sparkling", "szensavas"], "still": ["still", "szensavmentes"],
    "apple": ["apple", "alma"], "peach": ["peach", "barack", "oszibarack"], "banana": ["banana", "banan"],
    "coconut": ["coconut", "kokusz"], "caramel": ["caramel", "karamell"], "spicy": ["spicy", "csipos"],
    "salted": ["salted", "sos"], "paprika": ["paprika"], "cheese": ["cheese", "sajt", "sajtos"],
}
# variants that may legitimately co-occur on one pack and never conflict with each other
COMPATIBLE = {frozenset({"zero", "sugar_free"}), frozenset({"classic", "original"}),
              frozenset({"zero", "diet"}), frozenset({"diet", "light"})}


@dataclass(frozen=True)
class Attribute:
    kind: str           # quantity | pack_count | percent | variant | brand
    value: str          # normalized value, e.g. "500 ml", "6", "3.5", "zero", "coca-cola"
    raw: str
    confidence: float


def normalize_text(text: str) -> str:
    t = unicodedata.normalize("NFKD", text)
    t = "".join(c for c in t if not unicodedata.combining(c)).lower()
    t = t.replace("ℓ", "l").replace("×", "x")
    return re.sub(r"\s+", " ", t).strip()


def _num(s: str) -> float:
    return float(s.replace(",", "."))


def _fmt(v: float, unit: str) -> str:
    v = round(v, 2)
    return f"{int(v) if v == int(v) else v} {unit}"


def norm_quantity(num: str, unit: str) -> tuple[str, float, str] | None:
    u = re.sub(r"[\s.]", "", unit.lower())
    if u not in UNITS:
        return None
    base, f = UNITS[u]
    v = _num(num) * f
    if v <= 0:
        return None
    return _fmt(v, base), v, base


def extract(text: str, confidence: float = 1.0, brands: list[str] | None = None) -> list[Attribute]:
    t = normalize_text(text)
    out: list[Attribute] = []
    used = []
    for m in PACK_RE.finditer(t):
        q = norm_quantity(m.group(2), m.group(3))
        if q:
            out.append(Attribute("pack_count", str(int(m.group(1))), m.group(0), confidence))
            out.append(Attribute("quantity", q[0], m.group(0), confidence))
            used.append(m.span())
    for m in QTY_RE.finditer(t):
        if any(a <= m.start() < b for a, b in used):
            continue
        q = norm_quantity(m.group(1), m.group(2))
        if q and _plausible(q[1], q[2]):
            out.append(Attribute("quantity", q[0], m.group(0), confidence))
    for m in PERCENT_RE.finditer(t):
        out.append(Attribute("percent", _fmt(_num(m.group(1)), "%").replace(" %", ""), m.group(0), confidence))
    padded = f" {re.sub(r'[^a-z0-9% ]', ' ', t)} "
    for canon, words in VARIANTS.items():
        if any(f" {w} " in padded for w in words):
            out.append(Attribute("variant", canon, canon, confidence))
    for b in brands or []:
        nb = normalize_text(b)
        if nb and f" {nb} " in padded:
            out.append(Attribute("brand", nb, b, confidence))
    return _dedupe(out)


def _plausible(v: float, unit: str) -> bool:
    """Reject OCR readings no retail pack has (protects against '15L' read from '1.5L' on a can etc.
    only at the extremes; category-specific ranges are applied by the caller when known)."""
    return {"ml": 5 <= v <= 30_000, "g": 1 <= v <= 30_000, "pcs": 1 <= v <= 500}.get(unit, True)


def _dedupe(attrs: list[Attribute]) -> list[Attribute]:
    best: dict[tuple, Attribute] = {}
    for a in attrs:
        k = (a.kind, a.value)
        if k not in best or a.confidence > best[k].confidence:
            best[k] = a
    return list(best.values())


def _values(attrs: list[Attribute], kind: str, min_conf: float) -> set[str]:
    return {a.value for a in attrs if a.kind == kind and a.confidence >= min_conf}


def vetoes(a: list[Attribute], b: list[Attribute], min_conf: float = 0.6) -> list[str]:
    """Conflicts that make two images different products, whatever they look like."""
    out = []
    for kind in ("quantity", "pack_count", "percent", "brand"):
        va, vb = _values(a, kind, min_conf), _values(b, kind, min_conf)
        # A pack may print several quantities (e.g. 1.5 L and 6 x 250 ml servings): only a
        # complete disagreement is a conflict.
        if va and vb and not (va & vb):
            out.append(f"{kind}:{'/'.join(sorted(va))}!={'/'.join(sorted(vb))}")
    va, vb = _values(a, "variant", min_conf), _values(b, "variant", min_conf)
    only_a, only_b = va - vb, vb - va
    if only_a and only_b:
        conflict = [(x, y) for x in only_a for y in only_b if frozenset({x, y}) not in COMPATIBLE]
        if conflict:
            out.append(f"variant:{'/'.join(sorted(only_a))}!={'/'.join(sorted(only_b))}")
    return out


def has_quantity(attrs: list[Attribute], min_conf: float = 0.6) -> bool:
    return bool(_values(attrs, "quantity", min_conf))


_VARIANT_WORDS = {w for ws in VARIANTS.values() for w in ws if " " not in w}
_UNIT_WORDS = set(UNITS) | {"fl", "x"}


def name_tokens(text: str) -> list[str]:
    """Words that identify the product line (brand, product name) once sizes, percentages and
    variant words are removed - those are compared separately by the vetoes."""
    t = normalize_text(text)
    t = PACK_RE.sub(" ", t)
    t = QTY_RE.sub(" ", t)
    t = PERCENT_RE.sub(" ", t)
    toks = re.findall(r"[a-z0-9]+", t)
    return [w for w in toks if w not in _VARIANT_WORDS and w not in _UNIT_WORDS and len(w) >= 2]
