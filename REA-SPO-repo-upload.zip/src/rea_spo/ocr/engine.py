"""OCR engines. Production: PP-OCRv5 via RapidOCR on ONNX Runtime (no PaddlePaddle).

The engine only sees the product crop (~960 px long side). It returns lines with
confidences; normalization and attribute extraction happen in `attributes`.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Protocol

import cv2
import numpy as np

log = logging.getLogger("rea_spo.ocr")

OCR_SIZE = 960


@dataclass
class OcrLine:
    text: str
    confidence: float
    box: list            # 4 points [[x,y],...] in crop coordinates


class OcrEngine(Protocol):
    model_id: str

    def read(self, rgb: np.ndarray) -> list[OcrLine]: ...


class RapidOcrEngine:
    model_id = "ppocrv5-rapidocr"

    def __init__(self, det_model: str | None = None, rec_model: str | None = None, keys: str | None = None,
                 use_gpu: bool = True):
        from rapidocr_onnxruntime import RapidOCR  # optional dependency, bundled in the Windows build
        kwargs = {}
        if det_model:
            kwargs["det_model_path"] = det_model
        if rec_model:
            kwargs["rec_model_path"] = rec_model
        if keys:
            kwargs["rec_keys_path"] = keys
        if use_gpu:
            kwargs["det_use_dml"] = kwargs["rec_use_dml"] = True   # ignored where DirectML is unavailable
        try:
            self._ocr = RapidOCR(**kwargs)
        except TypeError:          # older RapidOCR without DirectML switches
            kwargs.pop("det_use_dml", None)
            kwargs.pop("rec_use_dml", None)
            self._ocr = RapidOCR(**kwargs)

    def read(self, rgb: np.ndarray) -> list[OcrLine]:
        h, w = rgb.shape[:2]
        s = OCR_SIZE / max(h, w)
        img = cv2.resize(rgb, (round(w * s), round(h * s)), interpolation=cv2.INTER_AREA if s < 1 else cv2.INTER_CUBIC)
        result, _ = self._ocr(cv2.cvtColor(img, cv2.COLOR_RGB2BGR))
        out = []
        for box, text, conf in result or []:
            out.append(OcrLine(str(text), float(conf), [[float(x) / s, float(y) / s] for x, y in box]))
        return out


def get_engine(use_gpu: bool = True) -> OcrEngine | None:
    try:
        from ..ai.registry import find_model
        det, rec = find_model("ppocrv5-det"), find_model("ppocrv5-rec-latin")
        keys = rec.path.with_suffix(".txt") if rec and rec.path else None
        return RapidOcrEngine(str(det.path) if det else None, str(rec.path) if rec else None,
                              str(keys) if keys and keys.exists() else None, use_gpu)
    except ImportError:
        log.warning("RapidOCR is not installed - OCR (and size/variant vetoes) disabled")
        return None
