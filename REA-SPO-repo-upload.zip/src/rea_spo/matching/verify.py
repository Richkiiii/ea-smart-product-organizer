"""Stage 7 - layer scores for one candidate pair (geometry, colour, shape, text, attributes)."""
from __future__ import annotations

import math
import sqlite3
from collections import OrderedDict
from dataclasses import dataclass, field
from pathlib import Path

import cv2
import numpy as np

from ..ocr import attributes as attr
from ..vision import local_features as lf
from .candidates import kp_path

GEO_MIN_INLIERS = 15
GEO_MIN_COVERAGE = 0.25


@dataclass
class ImageInfo:
    content_id: int
    sha: bytes
    width: int
    height: int
    aspect: float
    hue_hist: np.ndarray
    seg_uncertain: bool
    text: str = ""
    text_conf: float = 0.0
    attrs: list = field(default_factory=list)


@dataclass
class PairFeatures:
    a: int
    b: int
    embed_sim: float = 0.0
    phash_dist: int | None = None
    geo_inliers: int = 0
    geo_ratio: float = 0.0
    geo_coverage: float = 0.0
    color_dist: float = 1.0
    shape_diff: float = 0.0
    ocr_sim: float = 0.0
    both_text: bool = False
    seg_uncertain: bool = False
    res_ratio: float = 1.0
    vetoes: list = field(default_factory=list)
    qty_a: bool = False
    qty_b: bool = False

    @property
    def geo_pass(self) -> bool:
        return self.geo_inliers >= GEO_MIN_INLIERS and self.geo_coverage >= GEO_MIN_COVERAGE


def load_infos(conn: sqlite3.Connection, ids: set[int] | None = None) -> dict[int, ImageInfo]:
    rows = conn.execute(
        "SELECT c.id, c.sha256, c.width, c.height, f.silhouette_aspect, f.hue_hist, f.segmentation_uncertain "
        "FROM contents c JOIN image_fingerprints f ON f.content_id=c.id").fetchall()
    out = {}
    for r in rows:
        if ids is not None and r[0] not in ids:
            continue
        out[r[0]] = ImageInfo(r[0], bytes(r[1]), r[2] or 0, r[3] or 0, r[4] or 1.0,
                              np.frombuffer(r[5], np.float32) if r[5] else np.zeros(20, np.float32), bool(r[6]))
    for cid, text, conf in conn.execute("SELECT content_id, normalized_text, mean_conf FROM ocr_results"):
        if cid in out:
            out[cid].text, out[cid].text_conf = text or "", conf or 0.0
    for cid, kind, value, raw, conf in conn.execute(
            "SELECT content_id, kind, value_norm, raw_text, confidence FROM product_attributes"):
        if cid in out:
            out[cid].attrs.append(attr.Attribute(kind, value, raw or value, conf))
    return out


class KeypointCache:
    def __init__(self, cache_dir: Path, capacity: int = 4000):
        self.dir = cache_dir
        self.cap = capacity
        self._d: OrderedDict = OrderedDict()

    def get(self, sha: bytes):
        if sha in self._d:
            self._d.move_to_end(sha)
            return self._d[sha]
        got = lf.load(kp_path(self.dir, sha))
        val = None if got is None else (got[0].astype(np.float32), lf.to_float(got[1]))
        self._d[sha] = val
        if len(self._d) > self.cap:
            self._d.popitem(last=False)
        return val


_BF = cv2.BFMatcher(cv2.NORM_L2)


def geometric(ka: np.ndarray, da: np.ndarray, kb: np.ndarray, db: np.ndarray) -> tuple[int, float, float]:
    """(inliers, inlier ratio, coverage). Coverage = matched area / keypoint area, min of both sides."""
    if len(da) < 8 or len(db) < 8:
        return 0, 0.0, 0.0
    matches = _BF.knnMatch(da, db, k=2)
    good = [m for m, n in (p for p in matches if len(p) == 2) if m.distance < 0.8 * n.distance]
    if len(good) < 8:
        return len(good) // 2, 0.0, 0.0
    pa = np.float32([ka[m.queryIdx, :2] for m in good])
    pb = np.float32([kb[m.trainIdx, :2] for m in good])
    H, mask = cv2.findHomography(pa, pb, cv2.USAC_MAGSAC, 6.0, maxIters=2000, confidence=0.999)
    if H is None or mask is None:
        return 0, 0.0, 0.0
    inl = mask.ravel().astype(bool)
    n = int(inl.sum())
    det = float(np.linalg.det(H[:2, :2]))
    if n < 4 or not (0.05 < abs(det) < 20):        # degenerate or implausible transform
        return 0, 0.0, 0.0

    def area(pts):
        return float(cv2.contourArea(cv2.convexHull(pts))) if len(pts) >= 3 else 0.0

    cov = min(area(pa[inl]) / max(1.0, area(ka[:, :2].astype(np.float32))),
              area(pb[inl]) / max(1.0, area(kb[:, :2].astype(np.float32))))
    return n, n / max(1, min(len(da), len(db))), float(min(1.0, cov))


def text_similarity(a: str, b: str) -> float:
    """Similarity of the product-name words only (sizes/variants are handled by vetoes)."""
    ta, tb = attr.name_tokens(a), attr.name_tokens(b)
    if not ta or not tb:
        return 0.0
    a, b = " ".join(ta), " ".join(tb)
    try:
        from rapidfuzz import fuzz
        return fuzz.token_set_ratio(a, b) / 100.0
    except ImportError:
        import difflib
        ta, tb = sorted(set(a.split())), sorted(set(b.split()))
        return difflib.SequenceMatcher(None, " ".join(ta), " ".join(tb)).ratio()


def pair_features(ia: ImageInfo, ib: ImageInfo, kpc: KeypointCache, embed_sim: float | None,
                  phash_dist: int | None, min_conf: float = 0.6) -> PairFeatures:
    pf = PairFeatures(ia.content_id, ib.content_id, embed_sim or 0.0, phash_dist)
    ga, gb = kpc.get(ia.sha), kpc.get(ib.sha)
    if ga is not None and gb is not None:
        pf.geo_inliers, pf.geo_ratio, pf.geo_coverage = geometric(ga[0], ga[1], gb[0], gb[1])
    pf.color_dist = float(cv2.compareHist(ia.hue_hist, ib.hue_hist, cv2.HISTCMP_BHATTACHARYYA)) \
        if ia.hue_hist.size == ib.hue_hist.size and ia.hue_hist.size else 1.0
    pf.shape_diff = abs(math.log(max(1e-3, ia.aspect) / max(1e-3, ib.aspect)))
    pf.both_text = bool(attr.name_tokens(ia.text) and attr.name_tokens(ib.text))
    pf.ocr_sim = text_similarity(ia.text, ib.text)
    pf.seg_uncertain = ia.seg_uncertain or ib.seg_uncertain
    ra, rb = ia.width * ia.height, ib.width * ib.height
    pf.res_ratio = min(ra, rb) / max(1, max(ra, rb))
    pf.vetoes = attr.vetoes(ia.attrs, ib.attrs, min_conf)
    pf.qty_a, pf.qty_b = attr.has_quantity(ia.attrs, min_conf), attr.has_quantity(ib.attrs, min_conf)
    return pf
