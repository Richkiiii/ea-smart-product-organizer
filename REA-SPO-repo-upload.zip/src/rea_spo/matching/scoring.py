"""Calibrated pair confidence and the Same / Review / Different decision (Stage 7).

  p = isotonic( sigmoid(w . x + b) )      confidence = 100 * p

The weights are *fitted* on labelled pairs (`fit`) and stored as JSON, so the shipped app
needs no machine-learning library at runtime. Decision rules (vetoes, identity evidence,
size family, proportions) are applied on top of p exactly as in the blueprint.
"""
from __future__ import annotations

import json
import math
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

from .verify import PairFeatures

# Expected direction of each feature. Fitting drops a feature whose weight comes out with the
# wrong sign (a collinearity artefact), so more similarity can never lower the confidence.
SIGNS = {"embed_sim": 1, "phash_close": 1, "geo_inliers_log": 1, "geo_ratio": 1, "geo_coverage": 1,
         "color_dist": -1, "shape_diff": -1, "ocr_sim": 1, "both_text": 0, "seg_uncertain": -1, "res_ratio": 1}

FEATURES = ["embed_sim", "phash_close", "geo_inliers_log", "geo_ratio", "geo_coverage", "color_dist",
            "shape_diff", "ocr_sim", "both_text", "seg_uncertain", "res_ratio"]


def vectorize(pf: PairFeatures) -> np.ndarray:
    phash_close = 0.0 if pf.phash_dist is None else max(0.0, (8 - pf.phash_dist) / 8)
    return np.array([pf.embed_sim, phash_close, math.log1p(pf.geo_inliers), pf.geo_ratio, pf.geo_coverage,
                     pf.color_dist, min(pf.shape_diff, 1.0), pf.ocr_sim, float(pf.both_text),
                     float(pf.seg_uncertain), pf.res_ratio], np.float64)


@dataclass
class MatcherModel:
    coef: list
    intercept: float
    mean: list
    scale: list
    iso_x: list = field(default_factory=list)
    iso_y: list = field(default_factory=list)
    t_same: float = 0.97
    t_diff: float = 0.10
    features: list = field(default_factory=lambda: list(FEATURES))
    trained_on: str = ""
    metrics: dict = field(default_factory=dict)

    def prob(self, x: np.ndarray) -> np.ndarray:
        x = np.atleast_2d(x)
        z = ((x - np.array(self.mean)) / np.array(self.scale)) @ np.array(self.coef) + self.intercept
        p = 1 / (1 + np.exp(-z))
        if self.iso_x:
            p = np.interp(p, self.iso_x, self.iso_y)
        return p

    def save(self, path: Path) -> None:
        Path(path).write_text(json.dumps(self.__dict__, indent=2))

    @classmethod
    def load(cls, path: Path) -> "MatcherModel":
        return cls(**json.loads(Path(path).read_text()))


# Conservative hand-set prior used until a model has been fitted on labelled data.
DEFAULT = MatcherModel(
    coef=[1.2, 0.8, 1.5, 0.6, 1.2, -1.0, -0.8, 0.8, 0.0, -0.6, 0.2], intercept=-2.0,
    mean=[0.8, 0.1, 2.5, 0.1, 0.3, 0.3, 0.1, 0.3, 0.3, 0.05, 0.5],
    scale=[0.1, 0.3, 1.2, 0.1, 0.25, 0.15, 0.1, 0.4, 0.45, 0.2, 0.3],
    t_same=0.98, t_diff=0.10, trained_on="prior (not fitted)")


NO_IDENTITY_REVIEW_MIN = 0.5


@dataclass
class Decision:
    decision: str           # same | review | different
    confidence: float       # 0..100
    reasons: list


def decide(pf: PairFeatures, model: MatcherModel, size_family: bool = False) -> Decision:
    p = float(model.prob(vectorize(pf))[0])
    reasons = []
    if pf.vetoes:
        return Decision("different", round(min(p, 0.02) * 100, 1), [f"veto {v}" for v in pf.vetoes])
    cap = 1.0
    identity = pf.geo_pass or (pf.both_text and pf.ocr_sim >= 0.85) or (pf.phash_dist is not None and pf.phash_dist <= 4)
    if not identity:
        # Without geometry or text evidence the score cannot tell a product from a look-alike
        # (measured in Phase 3): only clearly similar pairs are worth a human look.
        if p < NO_IDENTITY_REVIEW_MIN:
            return Decision("different", round(p * 100, 1), ["no identity evidence (geometry/text)"])
        cap = min(cap, model.t_same - 1e-3)
        reasons.append("no identity evidence (geometry/text)")
    if size_family and not (pf.qty_a and pf.qty_b):
        cap = min(cap, model.t_same - 1e-3)
        reasons.append("size unreadable while other sizes exist")
    if pf.shape_diff > 0.08 and not (pf.qty_a and pf.qty_b):
        cap = min(cap, model.t_same - 1e-3)
        reasons.append(f"pack proportions differ {pf.shape_diff:.0%}")
    if pf.seg_uncertain:
        cap = min(cap, model.t_same - 1e-3)
        reasons.append("product outline uncertain")
    p = min(p, cap)
    if p >= model.t_same:
        d = "same"
    elif p <= model.t_diff:
        d = "different"
    else:
        d = "review"
    return Decision(d, round(p * 100, 1), reasons)


# ------------------------------------------------------------------ fitting (developer / CI)

def fit(X: np.ndarray, y: np.ndarray, groups: np.ndarray, target_precision: float = 0.995,
        max_recall_loss: float = 0.01, seed: int = 0, trained_on: str = "") -> MatcherModel:
    """Logistic regression + isotonic calibration; thresholds chosen on a held-out split by
    product family (`groups`) so they are never tuned on the pairs used to fit the weights."""
    from sklearn.isotonic import IsotonicRegression
    from sklearn.linear_model import LogisticRegression

    rng = np.random.default_rng(seed)
    fams = np.unique(groups)
    rng.shuffle(fams)
    cal_f = set(fams[: int(len(fams) * 0.6)])
    tr = np.array([g in cal_f for g in groups])
    mean, scale = X[tr].mean(0), X[tr].std(0) + 1e-6
    active = np.ones(X.shape[1], bool)
    Z = (X[tr] - mean) / scale
    for _ in range(X.shape[1]):
        lr = LogisticRegression(C=1.0, class_weight="balanced", max_iter=2000)
        lr.fit(Z[:, active], y[tr])
        coef = np.zeros(X.shape[1])
        coef[active] = lr.coef_[0]
        wrong = [i for i, f in enumerate(FEATURES) if active[i] and SIGNS[f] and np.sign(coef[i]) == -SIGNS[f]]
        if not wrong:
            break
        active[max(wrong, key=lambda i: abs(coef[i]))] = False
    model = MatcherModel(coef=coef.tolist(), intercept=float(lr.intercept_[0]),
                         mean=mean.tolist(), scale=scale.tolist(), trained_on=trained_on)
    raw_tr = model.prob(X[tr])
    iso = IsotonicRegression(out_of_bounds="clip", y_min=0, y_max=1).fit(raw_tr, y[tr])
    xs = np.linspace(0, 1, 101)
    model.iso_x, model.iso_y = xs.tolist(), iso.predict(xs).tolist()
    # thresholds on the calibration families
    p = model.prob(X[tr])
    yt = y[tr]
    t_same = 0.999
    for t in np.linspace(0.5, 0.999, 500):
        sel = p >= t
        if sel.sum() >= 5 and yt[sel].mean() >= target_precision:
            t_same = float(t)
            break
    t_diff = 0.0
    pos = max(1, int(yt.sum()))
    for t in np.linspace(0.5, 0.0, 501):
        if (yt[p <= t].sum() / pos) <= max_recall_loss:
            t_diff = float(t)
            break
    model.t_same, model.t_diff = t_same, min(t_diff, t_same - 0.01)
    model.metrics = {"train_pairs": int(tr.sum()), "test_pairs": int((~tr).sum()),
                     "test_families": int(len(fams) - len(cal_f))}
    model._test_mask = ~tr  # transient, for evaluation in the same process
    return model
