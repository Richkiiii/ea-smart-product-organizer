"""Nearest-neighbour search over L2-normalized embeddings (cosine = inner product).

Uses FAISS when installed (Windows build): exact search up to 50k vectors, HNSW above.
Falls back to blockwise exact NumPy search, which is fine up to roughly 30k vectors.
"""
from __future__ import annotations

import logging

import numpy as np

log = logging.getLogger("rea_spo.index")

try:  # optional dependency
    import faiss  # type: ignore
except ImportError:  # pragma: no cover - depends on environment
    faiss = None

EXACT_LIMIT = 50_000


def backend_name(n: int) -> str:
    if faiss is None:
        return "numpy-exact"
    return "faiss-flat" if n <= EXACT_LIMIT else "faiss-hnsw"


def knn_all(x: np.ndarray, k: int, block: int = 2048) -> tuple[np.ndarray, np.ndarray]:
    """For every row return its k most similar *other* rows: (sims[n,k], idx[n,k]).
    Missing neighbours (n <= k) are padded with sim=-inf, idx=-1."""
    x = np.ascontiguousarray(x, dtype=np.float32)
    n = len(x)
    kk = min(k, max(0, n - 1))
    sims = np.full((n, k), -np.inf, np.float32)
    idx = np.full((n, k), -1, np.int64)
    if kk == 0:
        return sims, idx
    if faiss is not None:
        d = x.shape[1]
        if n <= EXACT_LIMIT:
            index = faiss.IndexFlatIP(d)
        else:  # pragma: no cover - large runs only
            index = faiss.IndexHNSWFlat(d, 32, faiss.METRIC_INNER_PRODUCT)
            index.hnsw.efConstruction = 200
            index.hnsw.efSearch = max(128, 4 * k)
        index.add(x)
        s, i = index.search(x, kk + 1)
        for r in range(n):
            keep = i[r] != r
            si, ii = s[r][keep][:kk], i[r][keep][:kk]
            sims[r, :len(si)], idx[r, :len(ii)] = si, ii
        return sims, idx
    for start in range(0, n, block):
        stop = min(n, start + block)
        s = x[start:stop] @ x.T
        s[np.arange(stop - start), np.arange(start, stop)] = -np.inf
        part = np.argpartition(-s, kk - 1, axis=1)[:, :kk]
        ps = np.take_along_axis(s, part, axis=1)
        order = np.argsort(-ps, axis=1)
        idx[start:stop, :kk] = np.take_along_axis(part, order, axis=1)
        sims[start:stop, :kk] = np.take_along_axis(ps, order, axis=1)
    return sims, idx
