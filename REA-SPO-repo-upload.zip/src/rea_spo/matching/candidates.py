"""Stage 6 - candidate matching. Designed for recall: its job is never to miss a true pair.

Sources:
  * hash       - pHash Hamming distance <= threshold on the full image or the product crop
  * embedding  - top-k nearest neighbours above a low cosine threshold
Exact duplicates are not pairs: identical bytes share one `contents` row.
"""
from __future__ import annotations

import logging
import sqlite3
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from ..app.config import EngineSettings
from ..vision import local_features as lf
from ..vision.hashing import HashIndex
from .index import backend_name, knn_all

log = logging.getLogger("rea_spo.candidates")


@dataclass
class Candidate:
    a: int
    b: int
    sources: set
    embed_sim: float | None = None
    phash_dist: int | None = None
    rank: int | None = None


def load_embeddings(conn: sqlite3.Connection, model_id: str) -> tuple[np.ndarray, np.ndarray]:
    rows = conn.execute(
        "SELECT e.content_id, e.dim, e.vector FROM embeddings e JOIN contents c ON c.id=e.content_id "
        "WHERE e.model_id=? AND c.status IN ('valid','truncated') ORDER BY e.content_id", (model_id,)
    ).fetchall()
    if not rows:
        return np.zeros(0, np.int64), np.zeros((0, 0), np.float32)
    ids = np.array([r[0] for r in rows], np.int64)
    mat = np.stack([np.frombuffer(r[2], np.float16).astype(np.float32) for r in rows])
    mat /= np.maximum(np.linalg.norm(mat, axis=1, keepdims=True), 1e-12)
    return ids, mat


def kp_path(cache_dir: Path, sha: bytes) -> Path:
    hx = sha.hex()
    return cache_dir / "kp" / hx[:2] / f"{hx}.npz"


def vlad_matrix(conn: sqlite3.Connection, cache_dir: Path, k: int = 64, pca_dim: int = 256,
                per_image_sample: int = 120, seed: int = 0) -> tuple[np.ndarray, np.ndarray]:
    """Project-specific codebook -> VLAD per image -> PCA-whitened, L2-normalized matrix."""
    rows = conn.execute(
        "SELECT c.id, c.sha256 FROM contents c JOIN image_fingerprints f ON f.content_id=c.id "
        "WHERE c.status IN ('valid','truncated') AND f.keypoints_cached>0 ORDER BY c.id").fetchall()
    ids, descs = [], []
    for cid, sha in rows:
        got = lf.load(kp_path(cache_dir, bytes(sha)))
        if got is None or len(got[1]) == 0:
            continue
        ids.append(cid)
        descs.append(lf.to_float(got[1]))
    if len(ids) < 2:
        return np.zeros(0, np.int64), np.zeros((0, 0), np.float32)
    rng = np.random.default_rng(seed)
    sample = np.concatenate([d[rng.choice(len(d), min(len(d), per_image_sample), replace=False)] for d in descs])
    if len(sample) > 150_000:
        sample = sample[rng.choice(len(sample), 150_000, replace=False)]
    centers = lf.train_codebook(sample, k=k, seed=seed)
    v = np.stack([lf.vlad(d, centers) for d in descs])
    if len(v) > pca_dim * 2:
        mean, comps = lf.pca_fit(v, pca_dim)
        v = lf.pca_apply(v, mean, comps)
    return np.array(ids, np.int64), v.astype(np.float32)


def generate(conn: sqlite3.Connection, model_id: str, settings: EngineSettings,
             min_sim: float | None = None, cache_dir: Path | None = None) -> list[Candidate]:
    cands: dict[tuple[int, int], Candidate] = {}

    def get(a: int, b: int) -> Candidate:
        key = (a, b) if a < b else (b, a)
        c = cands.get(key)
        if c is None:
            c = cands[key] = Candidate(key[0], key[1], set())
        return c

    # --- near-identical by perceptual hash (full image and product crop)
    for col in ("phash_full", "phash_crop"):
        hidx = HashIndex()
        for cid, h in conn.execute(
            f"SELECT f.content_id, f.{col} FROM image_fingerprints f JOIN contents c ON c.id=f.content_id "
            f"WHERE c.status IN ('valid','truncated') AND f.{col} IS NOT NULL"
        ):
            hidx.add(cid, h)
        for a, b, d in hidx.pairs_within(settings.phash_max_dist):
            c = get(a, b)
            c.sources.add("hash")
            c.phash_dist = d if c.phash_dist is None else min(c.phash_dist, d)

    # --- visual neighbours
    ids, mat = load_embeddings(conn, model_id)
    thr = min_sim if min_sim is not None else (settings.candidate_min_sim or 0.70)
    if len(ids) > 1:
        log.info("candidate search over %d embeddings with %s", len(ids), backend_name(len(ids)))
        _add_knn(get, ids, mat, settings.candidate_top_k, thr, "embedding")
        # fill in similarity for hash-only pairs
        pos = {int(cid): i for i, cid in enumerate(ids)}
        for c in cands.values():
            if c.embed_sim is None and c.a in pos and c.b in pos:
                c.embed_sim = float(mat[pos[c.a]] @ mat[pos[c.b]])
    # --- local-feature (VLAD) neighbours: same printed label
    if cache_dir is not None and settings.extra.get("vlad", True):
        vids, vmat = vlad_matrix(conn, cache_dir)
        if len(vids) > 1:
            _add_knn(get, vids, vmat, settings.extra.get("vlad_top_k", settings.candidate_top_k),
                     settings.extra.get("vlad_min_sim", 0.0), "vlad")
    # --- optional 2-hop expansion: neighbours of a strong neighbour (raises recall, costs volume)
    expand = int(settings.extra.get("expand_rank", 0))
    if expand:
        strong: dict[int, set] = {}
        for c in list(cands.values()):
            if (c.rank is not None and c.rank <= expand) or c.phash_dist is not None:
                strong.setdefault(c.a, set()).add(c.b)
                strong.setdefault(c.b, set()).add(c.a)
        for nb in strong.values():
            nb = sorted(nb)
            for i in range(len(nb)):
                for j in range(i + 1, len(nb)):
                    if (nb[i], nb[j]) not in cands:
                        get(nb[i], nb[j]).sources.add("expansion")
    return sorted(cands.values(), key=lambda c: (c.a, c.b))


def _add_knn(get, ids: np.ndarray, mat: np.ndarray, k: int, thr: float, source: str) -> None:
    sims, nbr = knn_all(mat, k)
    for r in range(len(ids)):
        for rank in range(nbr.shape[1]):
            j = nbr[r, rank]
            if j < 0 or sims[r, rank] < thr:
                break
            c = get(int(ids[r]), int(ids[j]))
            c.sources.add(source)
            if source == "embedding":
                s = float(sims[r, rank])
                c.embed_sim = s if c.embed_sim is None else max(c.embed_sim, s)
            c.rank = rank + 1 if c.rank is None else min(c.rank, rank + 1)


def store(conn: sqlite3.Connection, cands: list[Candidate], model_id: str) -> None:
    conn.execute("DELETE FROM match_candidates WHERE model_id=?", (model_id,))
    conn.executemany(
        "INSERT INTO match_candidates(content_a, content_b, source, embed_sim, phash_dist, rank_ab, model_id)"
        " VALUES (?,?,?,?,?,?,?)",
        [(c.a, c.b, "+".join(sorted(c.sources)), c.embed_sim, c.phash_dist, c.rank, model_id) for c in cands],
    )
    conn.commit()
