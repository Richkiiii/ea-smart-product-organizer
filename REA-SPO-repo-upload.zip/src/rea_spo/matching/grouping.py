"""Stage 8 - constrained grouping.

Edges marked Same are merged strongest-first, but two clusters merge only if
  * no Different/veto edge or user cannot-link exists between any of their members, and
  * at least `min_agreement` of the pairs tested between them are Same.
User must-links are applied first. This prevents chains (A~B, B~C) from joining
products that were directly judged different.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass


@dataclass
class Group:
    members: list[int]
    confidence: float          # weakest Same edge used inside the group
    needs_review: bool


def build_groups(nodes: list[int], same: list[tuple[int, int, float]], different: list[tuple[int, int]],
                 review: list[tuple[int, int]], must: list[tuple[int, int]] = (),
                 cannot: list[tuple[int, int]] = (), min_agreement: float = 0.8) -> list[Group]:
    parent = {n: n for n in nodes}
    members = {n: {n} for n in nodes}
    weakest = {n: 100.0 for n in nodes}
    blocked = defaultdict(set)
    for a, b in list(different) + list(cannot):
        blocked[a].add(b)
        blocked[b].add(a)
    verdict = {}
    for a, b, _ in same:
        verdict[(min(a, b), max(a, b))] = 1
    for a, b in different:
        verdict[(min(a, b), max(a, b))] = 0

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def can_merge(ra, rb) -> bool:
        ma, mb = members[ra], members[rb]
        small, big = (ma, mb) if len(ma) <= len(mb) else (mb, ma)
        tested = agree = 0
        for x in small:
            if blocked[x] & big:
                return False
            for y in big:
                v = verdict.get((min(x, y), max(x, y)))
                if v is not None:
                    tested += 1
                    agree += v
        return tested == 0 or agree / tested >= min_agreement

    def union(ra, rb, conf):
        if len(members[ra]) < len(members[rb]):
            ra, rb = rb, ra
        parent[rb] = ra
        members[ra] |= members.pop(rb)
        weakest[ra] = min(weakest[ra], weakest.pop(rb), conf)

    for a, b in must:
        ra, rb = find(a), find(b)
        if ra != rb and not (blocked[a] & members[rb]):
            union(ra, rb, 100.0)
    for a, b, conf in sorted(same, key=lambda e: -e[2]):
        ra, rb = find(a), find(b)
        if ra != rb and can_merge(ra, rb):
            union(ra, rb, conf)

    root_of = {n: find(n) for n in nodes}
    flagged = set()
    for a, b in review:
        flagged.add(root_of[a])
        flagged.add(root_of[b])
    for a, b, _ in same:                     # a Same edge that could not be applied = conflict
        if root_of[a] != root_of[b]:
            flagged.add(root_of[a])
            flagged.add(root_of[b])
    out = []
    for r, m in members.items():
        out.append(Group(sorted(m), weakest[r] if len(m) > 1 else 100.0, r in flagged))
    return sorted(out, key=lambda g: (-len(g.members), g.members[0]))
