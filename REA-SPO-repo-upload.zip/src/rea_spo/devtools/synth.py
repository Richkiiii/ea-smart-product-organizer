"""Synthetic labelled product-photo dataset for development and regression testing.

It deliberately contains the hard cases from the blueprint:
  * size families    - same design, different size text and pack proportions
  * flavour families - same design, different flavour colour and name
  * look-alike packs - every product of a family shares the brand pattern
  * re-encoded copies, background changes, angles, upscaled copies, exact duplicates
Real product photos replace this as the primary test set once available; this set stays
as a fast regression check. All names are fictional.
"""
from __future__ import annotations

import csv
import io
import math
import random
import shutil
from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

BRANDS = ["FRESKO", "AQUAVITA", "NORDMILK", "CRUNCHO", "SUNVALE", "BELLADORO", "KAVAMAX", "GREENLEAF",
          "POLARIS", "TERRA", "VITALO", "MORENA", "DELIZIA", "ALPINA", "ORIGO", "LUMEN", "RUBIN", "ZEFIR"]
PACKS = {
    "bottle": (["330 ml", "500 ml", "1.5 L"], [2.55, 2.85, 3.25]),
    "can": (["250 ml", "330 ml", "500 ml"], [1.75, 1.95, 2.35]),
    "box": (["250 g", "500 g", "1 kg"], [1.25, 1.45, 1.65]),
    "jar": (["200 g", "400 g", "750 g"], [1.05, 1.25, 1.45]),
    "pouch": (["75 g", "150 g", "300 g"], [1.20, 1.35, 1.50]),
}
FLAVOURS = [("CLASSIC", (200, 30, 40)), ("ZERO", (25, 25, 25)), ("CHERRY", (120, 10, 45)),
            ("LEMON", (235, 205, 40)), ("LIGHT", (190, 195, 200)), ("ORANGE", (240, 130, 20)),
            ("MINT", (60, 180, 120)), ("BIO", (90, 140, 50)), ("VANILLA", (240, 225, 180))]
FONT = cv2.FONT_HERSHEY_DUPLEX


@dataclass
class ProductSpec:
    product_id: str
    family_id: str
    brand: str
    pack: str
    size: str
    size_index: int
    flavour: str
    flavour_rgb: tuple
    base_rgb: tuple
    accent_rgb: tuple
    pattern_seed: int


def _text(img, txt, cx, cy, width, color, thick=2):
    scale = 1.0
    (tw, th), _ = cv2.getTextSize(txt, FONT, scale, thick)
    scale = max(0.3, min(4.0, width / max(1, tw)))
    (tw, th), _ = cv2.getTextSize(txt, FONT, scale, thick)
    cv2.putText(img, txt, (int(cx - tw / 2), int(cy + th / 2)), FONT, scale, color, thick, cv2.LINE_AA)


def render_pack(spec: ProductSpec, height: int = 900) -> np.ndarray:
    """RGBA pack shot on a transparent background."""
    aspect = PACKS[spec.pack][1][spec.size_index]
    W = int(height / aspect)
    H = height
    img = np.zeros((H, W, 4), np.uint8)
    base = (*spec.base_rgb, 255)
    rng = random.Random(spec.pattern_seed)
    body_top = 0
    if spec.pack == "bottle":
        neck_w, neck_h = int(W * 0.34), int(H * 0.17)
        cv2.rectangle(img, (W // 2 - neck_w // 2, int(H * 0.04)), (W // 2 + neck_w // 2, neck_h + 20), base, -1)
        cv2.rectangle(img, (W // 2 - neck_w // 2 - 4, 0), (W // 2 + neck_w // 2 + 4, int(H * 0.05)),
                      (*spec.accent_rgb, 255), -1)
        body_top = neck_h
        cv2.ellipse(img, (W // 2, body_top + 30), (W // 2 - 2, 40), 0, 180, 360, base, -1)
        cv2.rectangle(img, (2, body_top + 30), (W - 3, H - 25), base, -1)
        cv2.ellipse(img, (W // 2, H - 25), (W // 2 - 2, 22), 0, 0, 180, base, -1)
    elif spec.pack == "can":
        cv2.rectangle(img, (0, 22), (W - 1, H - 22), base, -1)
        cv2.ellipse(img, (W // 2, 22), (W // 2 - 1, 20), 0, 0, 360, (190, 190, 195, 255), -1)
        cv2.ellipse(img, (W // 2, H - 22), (W // 2 - 1, 20), 0, 0, 180, base, -1)
        body_top = 30
    elif spec.pack == "jar":
        lid = int(H * 0.14)
        cv2.rectangle(img, (int(W * 0.06), 0), (int(W * 0.94), lid), (*spec.accent_rgb, 255), -1)
        cv2.rectangle(img, (0, lid), (W - 1, H - 1), base, -1)
        body_top = lid
    elif spec.pack == "pouch":
        pts = np.array([[int(W * 0.08), 0], [int(W * 0.92), 0], [W - 1, H - 1], [0, H - 1]], np.int32)
        cv2.fillPoly(img, [pts], base)
        cv2.rectangle(img, (int(W * 0.08), 0), (int(W * 0.92), int(H * 0.05)), (*spec.accent_rgb, 255), -1)
        body_top = int(H * 0.06)
    else:  # box
        cv2.rectangle(img, (0, 0), (W - 1, H - 1), base, -1)

    body = img[..., 3] > 0
    # brand pattern, shared by every product of the family
    pat = np.zeros_like(img)
    for _ in range(14):
        kind = rng.choice(["circle", "stripe", "dot"])
        col = (*[min(255, c + rng.randint(-60, 60)) for c in spec.accent_rgb], 255)
        if kind == "circle":
            cv2.circle(pat, (rng.randint(0, W), rng.randint(body_top, H)), rng.randint(W // 12, W // 4), col, rng.choice([3, 6, -1]))
        elif kind == "stripe":
            y = rng.randint(body_top, H)
            cv2.line(pat, (0, y), (W, y + rng.randint(-H // 6, H // 6)), col, rng.randint(4, 14))
        else:
            cv2.circle(pat, (rng.randint(0, W), rng.randint(body_top, H)), rng.randint(4, 12), col, -1)
    m = (pat[..., 3] > 0) & body
    img[m] = pat[m]

    # flavour label band
    y0, y1 = int(body_top + (H - body_top) * 0.38), int(body_top + (H - body_top) * 0.78)
    band = np.zeros_like(img)
    cv2.rectangle(band, (0, y0), (W, y1), (*spec.flavour_rgb, 255), -1)
    mb = (band[..., 3] > 0) & body
    img[mb] = band[mb]
    light = sum(spec.flavour_rgb) > 450
    ink = (20, 20, 20, 255) if light else (250, 250, 250, 255)
    _text(img, spec.brand, W / 2, body_top + (H - body_top) * 0.24, W * 0.84, (255, 255, 255, 255), 3)
    _text(img, spec.flavour, W / 2, y0 + (y1 - y0) * 0.33, W * 0.7, ink, 2)
    _text(img, spec.size, W / 2, y0 + (y1 - y0) * 0.72, W * 0.5, ink, 2)
    img[..., 3] = np.where(body, 255, 0).astype(np.uint8)
    return img


def _background(h, w, rng: random.Random) -> np.ndarray:
    kind = rng.choice(["white", "white", "grey", "solid", "gradient", "noise", "shelf"])
    if kind == "white":
        return np.full((h, w, 3), 255, np.uint8)
    if kind == "grey":
        v = rng.randint(200, 245)
        return np.full((h, w, 3), v, np.uint8)
    if kind == "solid":
        return np.full((h, w, 3), [rng.randint(60, 230) for _ in range(3)], np.uint8)
    if kind == "gradient":
        a = np.array([rng.randint(80, 255) for _ in range(3)], np.float32)
        b = np.array([rng.randint(80, 255) for _ in range(3)], np.float32)
        t = np.linspace(0, 1, h, dtype=np.float32)[:, None, None]
        return np.broadcast_to(a * (1 - t) + b * t, (h, w, 3)).astype(np.uint8).copy()
    if kind == "noise":
        base = np.full((h, w, 3), [rng.randint(120, 220) for _ in range(3)], np.float32)
        nz = cv2.GaussianBlur(np.random.default_rng(rng.randint(0, 9999)).normal(0, 40, (h, w, 1)).astype(np.float32), (0, 0), 3)
        return np.clip(base + nz.reshape(h, w, 1), 0, 255).astype(np.uint8)
    img = np.full((h, w, 3), [rng.randint(150, 220)] * 3, np.uint8)
    for y in range(0, h, max(20, h // 6)):
        cv2.rectangle(img, (0, y), (w, y + max(6, h // 40)), [rng.randint(60, 140)] * 3, -1)
    return img


def photograph(pack: np.ndarray, rng: random.Random, variant: str = "normal") -> np.ndarray:
    """Place the RGBA pack on a background with camera-like variation. Returns RGB."""
    ph, pw = pack.shape[:2]
    out_h = rng.randint(700, 1400)
    out_w = int(out_h * rng.uniform(0.75, 1.3))
    fill = rng.uniform(0.55, 0.85) if variant != "small" else rng.uniform(0.3, 0.45)
    s = min(out_h * fill / ph, out_w * 0.9 / pw)
    p = cv2.resize(pack, (max(8, int(pw * s)), max(8, int(ph * s))), interpolation=cv2.INTER_AREA)
    if variant in ("angle", "normal"):
        ang = rng.uniform(-12, 12) if variant == "angle" else rng.uniform(-3, 3)
        h2, w2 = p.shape[:2]
        diag = int(math.hypot(h2, w2)) + 4
        canvas = np.zeros((diag, diag, 4), np.uint8)
        canvas[(diag - h2) // 2:(diag - h2) // 2 + h2, (diag - w2) // 2:(diag - w2) // 2 + w2] = p
        M = cv2.getRotationMatrix2D((diag / 2, diag / 2), ang, 1.0)
        if variant == "angle":
            src = np.float32([[0, 0], [diag, 0], [diag, diag], [0, diag]])
            j = diag * 0.06
            dst = src + np.float32([[rng.uniform(-j, j), rng.uniform(-j, j)] for _ in range(4)])
            P = cv2.getPerspectiveTransform(src, dst)
            canvas = cv2.warpPerspective(canvas, P, (diag, diag))
        p = cv2.warpAffine(canvas, M, (diag, diag))
        ys, xs = np.nonzero(p[..., 3])
        p = p[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
    h2, w2 = p.shape[:2]
    if h2 > out_h or w2 > out_w:
        r = min(out_h / h2, out_w / w2) * 0.95
        p = cv2.resize(p, (int(w2 * r), int(h2 * r)), interpolation=cv2.INTER_AREA)
        h2, w2 = p.shape[:2]
    bg = _background(out_h, out_w, rng)
    y = rng.randint(0, out_h - h2)
    x = rng.randint(0, out_w - w2)
    a = p[..., 3:4].astype(np.float32) / 255.0
    roi = bg[y:y + h2, x:x + w2].astype(np.float32)
    bg[y:y + h2, x:x + w2] = (p[..., :3] * a + roi * (1 - a)).astype(np.uint8)
    img = bg.astype(np.float32)
    img = img * rng.uniform(0.8, 1.15) + rng.uniform(-15, 15)                  # exposure
    if rng.random() < 0.25:
        img = cv2.GaussianBlur(img, (0, 0), rng.uniform(0.6, 1.8))           # slight blur
    if rng.random() < 0.3:
        img += np.random.default_rng(rng.randint(0, 9999)).normal(0, rng.uniform(2, 8), img.shape)  # noise
    return np.clip(img, 0, 255).astype(np.uint8)


def _save(rgb: np.ndarray, path: Path, rng: random.Random, upscale: bool = False) -> Path:
    img = Image.fromarray(rgb)
    if upscale:
        small = img.resize((max(64, img.width // 3), max(64, img.height // 3)), Image.BILINEAR)
        img = small.resize((small.width * 3, small.height * 3), Image.BICUBIC)
    elif rng.random() < 0.4:
        f = rng.uniform(0.4, 1.6)
        img = img.resize((max(96, int(img.width * f)), max(96, int(img.height * f))), Image.LANCZOS)
    fmt = rng.choices(["jpg", "png", "webp"], [0.65, 0.15, 0.2])[0]
    path = _unique(path.with_suffix("." + fmt))
    path.parent.mkdir(parents=True, exist_ok=True)
    if fmt == "jpg":
        img.save(path, "JPEG", quality=rng.randint(35, 95))
    elif fmt == "png":
        img.save(path, "PNG")
    else:
        img.save(path, "WEBP", quality=rng.randint(50, 95))
    return path


def _unique(path: Path) -> Path:
    """Never overwrite: random camera-style names can collide."""
    if not path.exists():
        return path
    i = 2
    while path.with_name(f"{path.stem}_{i}{path.suffix}").exists():
        i += 1
    return path.with_name(f"{path.stem}_{i}{path.suffix}")


def _filename(rng: random.Random, spec: ProductSpec, n: int) -> str:
    style = rng.randint(0, 4)
    if style == 0:
        return f"IMG_{rng.randint(1000, 9999)}_{n}"
    if style == 1:
        return f"product_{rng.randint(1, 99999)}"
    if style == 2:
        return f"{spec.brand.title()}-{spec.flavour.title()}-{n}"
    if style == 3:
        return f"DSC{rng.randint(10000, 99999)}"
    return f"scan {rng.randint(1, 999)} ({n})"


def make_products(n_families: int, rng: random.Random, singletons: int = 0):
    products: list[ProductSpec] = []
    fam_specs = []
    for f in range(n_families + singletons):
        brand = rng.choice(BRANDS) + ("" if f < len(BRANDS) else f" {f}")
        pack = rng.choice(list(PACKS))
        base = tuple(rng.randint(30, 220) for _ in range(3))
        accent = tuple(rng.randint(30, 230) for _ in range(3))
        sizes = PACKS[pack][0]
        if f < n_families:
            size_idx = rng.sample(range(3), rng.choice([2, 3]))
            flv = rng.sample(FLAVOURS, rng.choice([1, 2, 3]))
            if len(size_idx) * len(flv) < 2:
                flv = rng.sample(FLAVOURS, 2)
        else:
            size_idx, flv = [rng.randrange(3)], [rng.choice(FLAVOURS)]
        fam = f"F{f:03d}"
        seed = rng.randint(0, 10 ** 6)
        for si in size_idx:
            for fname, frgb in flv:
                pid = f"{fam}-{fname}-{sizes[si].replace(' ', '')}"
                products.append(ProductSpec(pid, fam, brand, pack, sizes[si], si, fname, frgb, base, accent, seed))
        fam_specs.append(fam)
    return products


def generate(out_dir: str | Path, n_families: int = 20, photos_per_product: tuple[int, int] = (2, 5),
             singletons: int = 60, duplicate_rate: float = 0.08, seed: int = 7, nested: bool = True) -> Path:
    """Write images plus labels.csv into out_dir. Returns the labels path."""
    rng = random.Random(seed)
    out = Path(out_dir)
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)
    rows = []
    products = make_products(n_families, rng, singletons)
    n = 0
    for spec in products:
        pack = render_pack(spec, height=rng.choice([700, 900, 1100]))
        is_single = int(spec.family_id[1:]) >= n_families
        count = 1 if is_single else rng.randint(*photos_per_product)
        for k in range(count):
            n += 1
            variant = "normal"
            r = rng.random()
            if r < 0.3:
                variant = "angle"
            elif r < 0.4:
                variant = "small"
            rgb = photograph(pack, rng, variant)
            sub = f"batch_{rng.randint(1, 6)}/" if nested else ""
            upscale = (not is_single) and rng.random() < 0.08
            path = _save(rgb, out / (sub + _filename(rng, spec, n)), rng, upscale=upscale)
            rows.append(dict(rel_path=path.relative_to(out).as_posix(), product_id=spec.product_id,
                             family_id=spec.family_id, brand=spec.brand, flavour=spec.flavour, size=spec.size,
                             kind="singleton" if is_single else ("upscaled" if upscale else variant)))
            if rng.random() < 0.15 and not is_single:     # re-encoded copy of the same photo
                n += 1
                buf = io.BytesIO()
                Image.open(path).convert("RGB").save(buf, "JPEG", quality=rng.randint(30, 70))
                cpath = _unique(out / (sub + f"copy_{n}.jpg"))
                cpath.write_bytes(buf.getvalue())
                rows.append(dict(rows[-1], rel_path=cpath.relative_to(out).as_posix(), kind="reencoded"))
    # exact duplicates: byte-identical copies under other names
    originals = [r for r in rows if r["kind"] != "singleton"]
    for r in rng.sample(originals, int(len(originals) * duplicate_rate)):
        src = out / r["rel_path"]
        dst = out / "duplicates" / f"dup_{rng.randint(10 ** 5, 10 ** 6)}{src.suffix}"
        dst.parent.mkdir(exist_ok=True)
        dst = _unique(dst)
        shutil.copyfile(src, dst)
        rows.append(dict(r, rel_path=dst.relative_to(out).as_posix(), kind="exact_duplicate"))
    labels = out / "labels.csv"
    with open(labels, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    return labels
