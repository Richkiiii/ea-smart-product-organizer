"""Evaluation harness: measures Stage 6 candidate recall against ground-truth labels.

labels.csv columns: rel_path, product_id[, family_id, kind, ...]
rel_path is relative to the project's (single) source folder, or absolute.
"""
from __future__ import annotations

import csv
import itertools
import json
from collections import defaultdict
from pathlib import Path

import numpy as np

from ..core.project import Project
from ..matching.candidates import load_embeddings
from ..matching.index import knn_all


def _content_labels(project: Project, labels_csv: Path) -> tuple[dict[int, dict], list[str]]:
    conn = project.connect(readonly=True)
    by_rel = {}
    for r in conn.execute(
        "SELECT s.path, i.rel_path, i.content_id FROM images i JOIN source_folders s ON s.id=i.source_folder_id "
        "JOIN contents c ON c.id=i.content_id WHERE i.state='present' AND c.status IN ('valid','truncated')"
    ):
        by_rel[r["rel_path"]] = r["content_id"]
        by_rel[str(Path(r["path"]) / r["rel_path"])] = r["content_id"]
    conn.close()
    labels: dict[int, dict] = {}
    unmatched = []
    with open(labels_csv, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            cid = by_rel.get(row["rel_path"])
            if cid is None:
                unmatched.append(row["rel_path"])
                continue
            prev = labels.get(cid)
            if prev and prev["product_id"] != row["product_id"]:
                raise ValueError(f"identical file labelled as two products: {row['rel_path']}")
            labels[cid] = row
    return labels, unmatched


def true_pairs(labels: dict[int, dict]) -> set[tuple[int, int]]:
    groups = defaultdict(list)
    for cid, row in labels.items():
        groups[row["product_id"]].append(cid)
    out = set()
    for ids in groups.values():
        for a, b in itertools.combinations(sorted(ids), 2):
            out.add((a, b))
    return out


def evaluate_candidates(project: Project, labels_csv: str | Path, model_id: str) -> dict:
    labels, unmatched = _content_labels(project, Path(labels_csv))
    gt = true_pairs(labels)
    conn = project.connect(readonly=True)
    cands = {(r[0], r[1]): r for r in conn.execute(
        "SELECT content_a, content_b, source, embed_sim, phash_dist, rank_ab FROM match_candidates WHERE model_id=?",
        (model_id,))}
    n_images = conn.execute("SELECT COUNT(*) FROM images WHERE state='present'").fetchone()[0]
    n_contents = len(labels)
    conn.close()
    found = gt & set(cands)
    missed = sorted(gt - set(cands))
    same_family_diff_product = sum(
        1 for (a, b) in cands if a in labels and b in labels
        and labels[a].get("family_id") == labels[b].get("family_id")
        and labels[a]["product_id"] != labels[b]["product_id"])
    by_kind = defaultdict(lambda: [0, 0])
    for a, b in gt:
        kinds = tuple(sorted((labels[a].get("kind", "?"), labels[b].get("kind", "?"))))
        key = "+".join(kinds)
        by_kind[key][1] += 1
        if (a, b) in found:
            by_kind[key][0] += 1
    res = {
        "model_id": model_id,
        "images": n_images,
        "unique_contents_labelled": n_contents,
        "labels_unmatched": len(unmatched),
        "true_pairs": len(gt),
        "candidate_pairs": len(cands),
        "candidate_recall": round(len(found) / len(gt), 4) if gt else None,
        "candidates_per_image": round(len(cands) / max(1, n_contents), 2),
        "candidate_precision": round(len(found) / max(1, len(cands)), 4),
        "hard_negatives_in_candidates": same_family_diff_product,
        "recall_by_kind": {k: f"{v[0]}/{v[1]}" for k, v in sorted(by_kind.items())},
        "missed_examples": [
            {"a": labels[a]["rel_path"], "b": labels[b]["rel_path"], "product": labels[a]["product_id"]}
            for a, b in missed[:15]],
    }
    return res


def _knn_pairs(ids, sims, nbr, k, t) -> set:
    pairs = set()
    for r in range(len(ids)):
        for c in range(k):
            j = nbr[r, c]
            if j < 0 or sims[r, c] < t:
                break
            a, b = int(ids[r]), int(ids[j])
            pairs.add((min(a, b), max(a, b)))
    return pairs


def sweep(project: Project, labels_csv: str | Path, model_id: str,
          ks=(10, 20, 30, 60), thresholds=(0.0, 0.5, 0.6, 0.7, 0.8)) -> list[dict]:
    """Recall vs. candidate volume per source (embedding, vlad, union) to choose k and thresholds."""
    from ..matching.candidates import vlad_matrix
    labels, _ = _content_labels(project, Path(labels_csv))
    gt = true_pairs(labels)
    conn = project.connect(readonly=True)
    sources = {"embedding": load_embeddings(conn, model_id), "vlad": vlad_matrix(conn, project.cache_dir)}
    conn.close()
    knn = {}
    for name, (ids, mat) in sources.items():
        keep = np.array([int(i) in labels for i in ids], bool)
        ids, mat = ids[keep], mat[keep]
        if len(ids) > 1:
            knn[name] = (ids, *knn_all(mat, max(ks)))
    out = []
    n = max(1, len(labels))
    for k in ks:
        for t in thresholds:
            per = {name: _knn_pairs(ids, sims, nbr, k, t) for name, (ids, sims, nbr) in knn.items()}
            per["union"] = set().union(*per.values()) if per else set()
            for name, pairs in per.items():
                out.append({"source": name, "k": k, "min_sim": t,
                            "recall": round(len(gt & pairs) / max(1, len(gt)), 4),
                            "pairs_per_image": round(len(pairs) / n, 2)})
    return out


def write_report(result: dict, path: str | Path) -> None:
    Path(path).write_text(json.dumps(result, indent=2), encoding="utf-8")
