"""Phase 3 development tools: simulated OCR, matcher training and decision/group evaluation.

The simulated ("oracle") OCR writes the text printed on each synthetic pack into the database,
with realistic misses, so the veto and size-family logic can be measured before the real
OCR models are available. It is clearly a development aid and never used by the app.
"""
from __future__ import annotations

import random
from collections import defaultdict
from pathlib import Path

import numpy as np

from ..core import verification
from ..core.project import Project
from ..matching.scoring import decide, fit, vectorize
from ..ocr import attributes as attr
from .evaluate import _content_labels


def simulate_ocr(project: Project, labels_csv: Path, miss_rate: float = 0.15, size_miss_rate: float = 0.15,
                 seed: int = 0) -> dict:
    labels, _ = _content_labels(project, Path(labels_csv))
    rng = random.Random(seed)
    conn = project.connect()
    conn.execute("DELETE FROM ocr_results")
    conn.execute("DELETE FROM product_attributes")
    stats = defaultdict(int)
    for cid, row in labels.items():
        if row.get("kind") == "small" or rng.random() < miss_rate:
            stats["no_text"] += 1
            continue
        parts = [row["brand"], row["flavour"]]
        if rng.random() >= size_miss_rate:
            parts.append(row["size"])
        else:
            stats["size_unreadable"] += 1
        text = attr.normalize_text(" ".join(parts))
        conf = round(rng.uniform(0.7, 0.98), 2)
        conn.execute("INSERT INTO ocr_results(content_id, model_id, full_text, normalized_text, mean_conf) "
                     "VALUES (?, 'simulated', ?, ?, ?)", (cid, text, text, conf))
        for a in attr.extract(text, conf):
            conn.execute("INSERT INTO product_attributes(content_id, kind, value_norm, raw_text, confidence)"
                         " VALUES (?,?,?,?,?)", (cid, a.kind, a.value, a.raw, a.confidence))
        stats["with_text"] += 1
    conn.commit()
    conn.close()
    return dict(stats)


def train(project: Project, labels_csv: Path, out: Path | None = None, threads: int = 4) -> dict:
    labels, _ = _content_labels(project, Path(labels_csv))
    all_feats = [f for f in verification.compute_features(project, threads) if f.a in labels and f.b in labels]
    # Vetoed pairs never reach the score, so they must not shape it.
    feats = [f for f in all_feats if not f.vetoes]
    X = np.stack([vectorize(f) for f in feats])
    y = np.array([labels[f.a]["product_id"] == labels[f.b]["product_id"] for f in feats], int)
    g = np.array([labels[f.a].get("family_id", labels[f.a]["product_id"]) for f in feats])
    model = fit(X, y, g, trained_on=f"{Path(labels_csv).parent.name} ({len(feats)} pairs)")
    test = model.__dict__.pop("_test_mask")
    res = evaluate_decisions(project, labels_csv, model=model, feats=feats, mask=test)
    res["vetoed_pairs_excluded"] = len(all_feats) - len(feats)
    model.metrics.update({"heldout": res})
    path = out or project.cache_dir / "matcher.json"
    model.save(path)
    return {"model": str(path), "t_same": model.t_same, "t_diff": model.t_diff, "heldout": res,
            "weights": dict(zip(model.features, [round(c, 3) for c in model.coef]))}


def evaluate_decisions(project: Project, labels_csv: Path, model=None, feats=None, mask=None) -> dict:
    labels, _ = _content_labels(project, Path(labels_csv))
    model = model or verification.load_model(project)
    if feats is None:
        feats = [f for f in verification.compute_features(project) if f.a in labels and f.b in labels]
    infos_attrs = defaultdict(list)
    conn = project.connect(readonly=True)
    for cid, kind, value, raw, conf in conn.execute(
            "SELECT content_id, kind, value_norm, raw_text, confidence FROM product_attributes"):
        infos_attrs[cid].append(attr.Attribute(kind, value, raw or value, conf))
    conn.close()
    fam = verification.size_families(feats, infos_attrs)
    idx = range(len(feats)) if mask is None else np.nonzero(mask)[0]
    n_same = tp = fp = sib_fp = rev_pos = rev = pos = 0
    for i in idx:
        f = feats[i]
        la, lb = labels[f.a], labels[f.b]
        truth = la["product_id"] == lb["product_id"]
        d = decide(f, model, size_family=(f.a in fam or f.b in fam)).decision
        pos += truth
        if d == "same":
            n_same += 1
            tp += truth
            if not truth:
                fp += 1
                sib_fp += la.get("family_id") == lb.get("family_id")
        elif d == "review":
            rev += 1
            rev_pos += truth
    n = len(idx)
    return {"pairs": n, "true_pairs": pos,
            "auto_same_precision": round(tp / n_same, 4) if n_same else None,
            "auto_recall": round(tp / pos, 4) if pos else None,
            "recall_auto_plus_review": round((tp + rev_pos) / pos, 4) if pos else None,
            "false_merges": fp, "size_or_flavour_false_merges": sib_fp,
            "review_share_of_pairs": round(rev / max(1, n), 4)}


def evaluate_groups(project: Project, labels_csv: Path) -> dict:
    """BCubed precision/recall of the stored product groups (per image)."""
    labels, _ = _content_labels(project, Path(labels_csv))
    conn = project.connect(readonly=True)
    rows = conn.execute("SELECT g.id, i.content_id, g.status FROM product_groups g JOIN group_members gm "
                        "ON gm.group_id=g.id JOIN images i ON i.id=gm.image_id WHERE gm.role='member'").fetchall()
    conn.close()
    group_of, members, status = {}, defaultdict(list), {}
    for gid, cid, st in rows:
        if cid in labels:
            group_of[cid] = gid
            members[gid].append(cid)
            status[gid] = st
    prod = defaultdict(list)
    for cid in group_of:
        prod[labels[cid]["product_id"]].append(cid)
    P = R = 0.0
    impure = 0
    for cid, gid in group_of.items():
        p = labels[cid]["product_id"]
        same_g = members[gid]
        P += sum(labels[x]["product_id"] == p for x in same_g) / len(same_g)
        R += sum(group_of[x] == gid for x in prod[p]) / len(prod[p])
    for gid, m in members.items():
        if len({labels[x]["product_id"] for x in m}) > 1:
            impure += 1
    n = max(1, len(group_of))
    conn = project.connect(readonly=True)
    import json as _json
    qty = {r[0] for r in conn.execute("SELECT content_id FROM product_attributes WHERE kind='quantity'")}
    review_imgs = set()
    for a, b, reasons in conn.execute("SELECT content_a, content_b, vetoes FROM match_pairs WHERE decision='review'"):
        rs = " ".join(_json.loads(reasons or "[]"))
        if "size unreadable" in rs and (a in qty) != (b in qty):
            review_imgs.add(b if a in qty else a)       # only the image without a readable size needs a decision
        else:
            review_imgs.update((a, b))
    conn.close()
    return {"images_needing_a_decision": len(review_imgs & set(group_of)),
            "share_of_images_needing_a_decision": round(len(review_imgs & set(group_of)) / n, 4),
            "bcubed_precision": round(P / n, 4), "bcubed_recall": round(R / n, 4),
            "groups": len(members), "products": len(prod), "impure_groups": impure,
            "groups_needing_review": sum(1 for s in status.values() if s == "needs_review")}
