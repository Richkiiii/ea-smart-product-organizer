"""Application paths and settings.

All app data lives under one per-user folder:
  Windows : %LOCALAPPDATA%/REA/SmartProductOrganizer
  others  : ~/.local/share/rea-spo  (development / CI)
It can be overridden with the REA_SPO_HOME environment variable (used by tests).
"""
from __future__ import annotations

import json
import os
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path

SUPPORTED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff"}

APP_FOLDER_NAMES = {"_REA_Quarantine", "_REA_Output", "$RECYCLE.BIN", "System Volume Information"}


def app_home() -> Path:
    env = os.environ.get("REA_SPO_HOME")
    if env:
        p = Path(env)
    elif sys.platform == "win32":
        base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
        p = Path(base) / "REA" / "SmartProductOrganizer"
    else:
        p = Path.home() / ".local" / "share" / "rea-spo"
    p.mkdir(parents=True, exist_ok=True)
    return p


def models_dir() -> Path:
    """Model folder: next to the frozen EXE, else repo-root/models, else app home."""
    env = os.environ.get("REA_SPO_MODELS")
    if env:
        return Path(env)
    if getattr(sys, "frozen", False):
        beside = Path(sys.executable).parent / "models"
        bundled = Path(getattr(sys, "_MEIPASS", beside.parent)) / "models"
        return beside if beside.exists() else bundled
    repo = Path(__file__).resolve().parents[3] / "models"
    if repo.exists():
        return repo
    return app_home() / "models"


@dataclass
class EngineSettings:
    """Tunable engine settings. Defaults are Phase 2 starting points; Phase 3 calibrates them."""

    working_size: int = 1024          # long side of the normalized working copy
    thumb_size: int = 256             # thumbnail long side
    min_side: int = 64                # smaller images are rejected as too_small
    embed_batch: int = 32
    reader_threads: int = 0           # 0 = auto from drive type
    candidate_top_k: int = 30
    candidate_min_sim: float | None = None   # None = the embedder's calibrated default
    phash_max_dist: int = 6           # near-identical hash threshold
    embedder: str = "auto"            # auto | siglip2 | classic
    use_gpu: bool = True
    low_impact: bool = False
    extra: dict = field(default_factory=dict)

    def to_json(self) -> str:
        return json.dumps(asdict(self), sort_keys=True)

    @classmethod
    def from_json(cls, text: str | None) -> "EngineSettings":
        if not text:
            return cls()
        data = json.loads(text)
        known = {k: v for k, v in data.items() if k in cls.__dataclass_fields__}
        return cls(**known)
