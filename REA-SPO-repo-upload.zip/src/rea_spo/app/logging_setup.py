"""Rotating file logging (10 x 10 MB) plus optional console output."""
from __future__ import annotations

import logging
import logging.handlers

from .config import app_home

_CONFIGURED = False


def setup_logging(verbose: bool = False, console: bool = True) -> logging.Logger:
    global _CONFIGURED
    log = logging.getLogger("rea_spo")
    if _CONFIGURED:
        return log
    log.setLevel(logging.DEBUG)
    logs = app_home() / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    fh = logging.handlers.RotatingFileHandler(
        logs / "rea_spo.log", maxBytes=10 * 1024 * 1024, backupCount=10, encoding="utf-8"
    )
    fh.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(threadName)s %(name)s: %(message)s"))
    fh.setLevel(logging.DEBUG)
    log.addHandler(fh)
    if console:
        ch = logging.StreamHandler()
        ch.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
        ch.setLevel(logging.DEBUG if verbose else logging.WARNING)
        log.addHandler(ch)
    _CONFIGURED = True
    return log
