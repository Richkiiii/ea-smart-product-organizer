"""Entry point. With arguments: CLI. Without: the desktop UI (Phase 5), or CLI help until then."""
import sys


def run() -> int:
    if len(sys.argv) > 1:
        from .cli import main
        return main()
    try:
        from .ui.main_window import launch  # Phase 5
    except ImportError:
        from .cli import build_parser
        build_parser().print_help()
        return 0
    return launch()


if __name__ == "__main__":
    sys.exit(run())
