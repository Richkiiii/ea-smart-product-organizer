"""Pipeline orchestrator for Phase 2: Stages 1-4 and 6.

  Stage 1  discovery           (read-only walk, change detection)
  Stage 2  validation          (read bytes once, SHA-256, decode)
  Stage 3  normalization       (working copy, thumbnail, product mask + crop)
  Stage 4  feature extraction  (hashes, colour, silhouette, embedding)
  Stage 6  candidate matching  (hash + embedding neighbours)

Results are cached by content hash: renamed, moved or duplicated files are analysed
once, and a rescan of unchanged files does no image work. The job can be paused,
resumed and cancelled; a cancelled or crashed job resumes where it stopped because
completion is recorded per content (`contents.analysed_stage`).
"""
from __future__ import annotations

import json
import logging
import os
import threading
import time
from concurrent.futures import FIRST_COMPLETED, Future, ThreadPoolExecutor, wait
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

import numpy as np

from .. import ENGINE_VERSION
from ..ai.embeddings import Embedder, get_embedder
from ..app.config import EngineSettings
from ..files.scanner import iter_images, reader_threads_for
from ..matching import candidates as cand
from ..storage.db import DbWriter, utcnow
from ..vision import features, hashing, local_features
from ..vision.decode import decode_bytes, read_bytes
from ..vision.normalize import normalize
from ..workers.control import Cancelled, JobControl, Progress, ProgressReporter
from .project import Project

log = logging.getLogger("rea_spo.pipeline")

STAGE_DONE = 4
FP_VERSION = "fp-2"


@dataclass
class WorkItem:
    image_key: tuple[int, str]       # (source_folder_id, rel_path)
    path: str
    size: int
    mtime_ns: int


@dataclass
class Analysed:
    item: WorkItem
    sha: bytes | None = None
    status: str = "valid"
    skipped: bool = False            # content already analysed: link only
    error: str | None = None
    meta: dict = field(default_factory=dict)
    fp: dict = field(default_factory=dict)
    crop: np.ndarray | None = None
    thumb: bytes = b""


@dataclass
class RunSummary:
    job_id: int
    status: str
    discovered: int = 0
    unchanged: int = 0
    processed: int = 0
    linked_duplicates: int = 0
    invalid: int = 0
    errors: int = 0
    missing: int = 0
    candidates: int = 0
    seconds: float = 0.0
    model_id: str = ""
    images_per_second: float = 0.0
    timings: dict = field(default_factory=dict)

    def as_dict(self) -> dict:
        return self.__dict__.copy()


class Pipeline:
    def __init__(self, project: Project, settings: EngineSettings | None = None,
                 embedder: Embedder | None = None,
                 progress: Callable[[Progress], None] | None = None,
                 control: JobControl | None = None):
        self.project = project
        self.settings = settings or project.settings()
        self.embedder = embedder or get_embedder(self.settings)
        self.report = ProgressReporter(progress)
        self.control = control or JobControl()
        self._claim_lock = threading.Lock()
        self._claimed: set[bytes] = set()
        self._timings: dict[str, float] = {}
        self._tlock = threading.Lock()

    # ------------------------------------------------------------------ helpers
    @property
    def min_sim(self) -> float:
        s = self.settings.candidate_min_sim
        return self.embedder.default_min_sim if s is None else s

    def _t(self, key: str, dt: float) -> None:
        with self._tlock:
            self._timings[key] = self._timings.get(key, 0.0) + dt

    def _kp_path(self, sha: bytes) -> Path:
        hx = sha.hex()
        return self.project.cache_dir / "kp" / hx[:2] / f"{hx}.npz"

    def _thumb_path(self, sha: bytes) -> Path:
        hx = sha.hex()
        p = self.project.cache_dir / "thumbs" / hx[:2]
        p.mkdir(parents=True, exist_ok=True)
        return p / f"{hx}.webp"

    # ------------------------------------------------------------------ stage 1
    def discover(self, conn, job_id: int, summary: RunSummary) -> list[WorkItem]:
        """Compare the folders on disk with the database. Returns files needing work."""
        p = Progress("Discovering files")
        complete = {
            bytes(r[0]) for r in conn.execute(
                "SELECT c.sha256 FROM contents c JOIN embeddings e ON e.content_id=c.id AND e.model_id=? "
                "WHERE c.analysed_stage>=?", (self.embedder.model_id, STAGE_DONE))
        }
        self._complete_shas = complete
        todo: list[WorkItem] = []
        for src in conn.execute("SELECT * FROM source_folders WHERE is_online=1").fetchall():
            root = Path(src["path"])
            if not root.is_dir():
                log.warning("source offline: %s", root)
                conn.execute("UPDATE source_folders SET is_online=0 WHERE id=?", (src["id"],))
                continue
            known = {
                r["rel_path"]: r for r in conn.execute(
                    "SELECT i.rel_path, i.size_bytes, i.mtime_ns, i.content_id, c.sha256, c.analysed_stage "
                    "FROM images i LEFT JOIN contents c ON c.id=i.content_id WHERE i.source_folder_id=?",
                    (src["id"],))
            }
            seen = set()
            errs: list = []
            excl = json.loads(src["exclude_globs"]) if src["exclude_globs"] else None
            for f in iter_images(root, bool(src["include_subfolders"]), excl, errs):
                seen.add(f.rel_path)
                summary.discovered += 1
                p.done = summary.discovered
                self.report(p)
                k = known.get(f.rel_path)
                if (k is not None and k["size_bytes"] == f.size and k["mtime_ns"] == f.mtime_ns
                        and k["sha256"] is not None and bytes(k["sha256"]) in complete):
                    summary.unchanged += 1
                    conn.execute("UPDATE images SET last_seen_job=?, state='present' "
                                 "WHERE source_folder_id=? AND rel_path=?", (job_id, src["id"], f.rel_path))
                    continue
                todo.append(WorkItem((src["id"], f.rel_path), str(root / f.rel_path), f.size, f.mtime_ns))
            for path, msg in errs:
                summary.errors += 1
                conn.execute("INSERT INTO image_errors(job_id, path, stage, error, created_at) VALUES (?,?,?,?,?)",
                             (job_id, path, 1, msg, utcnow()))
            gone = [r for r in known if r not in seen]
            summary.missing += len(gone)
            conn.executemany("UPDATE images SET state='missing' WHERE source_folder_id=? AND rel_path=? "
                             "AND state='present'", [(src["id"], g) for g in gone])
            conn.execute("UPDATE source_folders SET last_scanned_at=? WHERE id=?", (utcnow(), src["id"]))
        conn.commit()
        self.report(p, force=True)
        return todo

    # ------------------------------------------------------------------ stages 2-4 (worker thread)
    def analyse_file(self, item: WorkItem) -> Analysed:
        res = Analysed(item)
        t0 = time.perf_counter()
        try:
            data = read_bytes(item.path)
        except OSError as exc:
            res.status, res.error = "unreadable", str(exc)
            return res
        self._t("read", time.perf_counter() - t0)
        import hashlib
        sha = hashlib.sha256(data).digest()
        res.sha = sha
        with self._claim_lock:
            if sha in self._complete_shas or sha in self._claimed:
                res.skipped = True
                return res
            self._claimed.add(sha)

        t1 = time.perf_counter()
        dec = decode_bytes(data, self.settings.min_side)
        self._t("decode", time.perf_counter() - t1)
        res.status, res.error = dec.status, dec.error
        res.meta = dict(width=dec.width, height=dec.height, format=dec.format, color_mode=dec.color_mode,
                        has_alpha=int(dec.has_alpha), jpeg_quality=dec.jpeg_quality)
        if dec.status not in ("valid", "truncated") or dec.rgb is None:
            return res

        t2 = time.perf_counter()
        norm = normalize(dec.rgb, self.settings.working_size, self.settings.thumb_size)
        self._t("normalize", time.perf_counter() - t2)

        t3 = time.perf_counter()
        seg = norm.seg
        aspect, hu = features.silhouette(seg.mask, seg.box)
        inv = 1.0 / norm.scale
        x, y, w, h = seg.box
        res.fp = dict(
            phash_full=hashing.phash(norm.work), dhash_full=hashing.dhash(norm.work),
            phash_crop=hashing.phash(norm.clean), dhash_crop=hashing.dhash(norm.clean),
            crop_x=int(x * inv), crop_y=int(y * inv), crop_w=int(w * inv), crop_h=int(h * inv),
            mask_coverage=seg.coverage, mask_touches_border=int(seg.touches_border),
            segmentation_uncertain=int(seg.uncertain), silhouette_aspect=aspect, hu_moments=hu,
            dominant_colors_json=features.colors_json(features.dominant_colors(norm.crop, norm.crop_mask)),
            hue_hist=features.hue_histogram(norm.crop, norm.crop_mask).tobytes(),
        )
        self._t("features", time.perf_counter() - t3)
        t4 = time.perf_counter()
        kp, d8 = local_features.extract(norm.clean, None if seg.uncertain else norm.crop_mask)
        local_features.save(self._kp_path(sha), kp, d8)
        res.fp["keypoints_cached"] = int(len(kp))
        self._t("local_features", time.perf_counter() - t4)
        res.crop = norm.clean
        res.thumb = norm.thumb_webp
        return res

    # ------------------------------------------------------------------ DB writes (writer thread)
    @staticmethod
    def _write_image(conn, job_id: int, item: WorkItem, sha: bytes | None) -> None:
        sfid, rel = item.image_key
        name = rel.rsplit("/", 1)[-1]
        ext = os.path.splitext(name)[1].lower()
        conn.execute(
            "INSERT INTO images(source_folder_id, rel_path, file_name, ext, size_bytes, mtime_ns, content_id, "
            "state, first_seen_job, last_seen_job) VALUES (?,?,?,?,?,?,(SELECT id FROM contents WHERE sha256=?),"
            "'present',?,?) ON CONFLICT(source_folder_id, rel_path) DO UPDATE SET size_bytes=excluded.size_bytes,"
            " mtime_ns=excluded.mtime_ns, content_id=excluded.content_id, state='present',"
            " last_seen_job=excluded.last_seen_job",
            (sfid, rel, name, ext, item.size, item.mtime_ns, sha, job_id, job_id),
        )

    def _write_result(self, job_id: int, res: Analysed, emb: np.ndarray | None) -> Callable:
        model_id = self.embedder.model_id

        def fn(conn):
            if res.sha is not None:
                conn.execute("INSERT OR IGNORE INTO contents(sha256, status) VALUES (?, 'pending')", (res.sha,))
            if res.sha is not None and not res.skipped:
                stage = STAGE_DONE if emb is not None else 2
                m = res.meta
                conn.execute(
                    "UPDATE contents SET width=?, height=?, format=?, color_mode=?, has_alpha=?, jpeg_quality=?,"
                    " status=?, error=?, analysed_stage=? WHERE sha256=?",
                    (m.get("width"), m.get("height"), m.get("format"), m.get("color_mode"), m.get("has_alpha"),
                     m.get("jpeg_quality"), res.status, res.error, stage, res.sha))
                if res.fp:
                    cols = list(res.fp) + ["model_version"]
                    vals = list(res.fp.values()) + [FP_VERSION]
                    conn.execute(
                        f"INSERT OR REPLACE INTO image_fingerprints(content_id, {', '.join(cols)}) VALUES "
                        f"((SELECT id FROM contents WHERE sha256=?), {', '.join('?' * len(vals))})",
                        [res.sha, *vals])
                if emb is not None:
                    conn.execute(
                        "INSERT OR REPLACE INTO embeddings(content_id, model_id, dim, vector) VALUES "
                        "((SELECT id FROM contents WHERE sha256=?), ?, ?, ?)",
                        (res.sha, model_id, int(emb.shape[0]), emb.astype(np.float16).tobytes()))
            if res.error and res.status not in ("valid",):
                conn.execute("INSERT INTO image_errors(job_id, path, stage, error, created_at) VALUES (?,?,?,?,?)",
                             (job_id, res.item.path, 2, f"{res.status}: {res.error}", utcnow()))
            self._write_image(conn, job_id, res.item, res.sha)
        return fn

    # ------------------------------------------------------------------ main entry
    def run(self, with_candidates: bool = True) -> RunSummary:
        t_start = time.perf_counter()
        conn = self.project.connect()
        job_id = conn.execute(
            "INSERT INTO processing_jobs(type, status, params_json, current_stage, done, total, started_at)"
            " VALUES ('analyse','running',?,1,0,0,?)",
            (json.dumps({"settings": json.loads(self.settings.to_json()), "model": self.embedder.model_id}),
             utcnow())).lastrowid
        conn.commit()
        summary = RunSummary(job_id=job_id, status="running", model_id=self.embedder.model_id)
        writer = DbWriter(self.project.db_path)
        status = "done"
        try:
            todo = self.discover(conn, job_id, summary)
            conn.execute("UPDATE processing_jobs SET current_stage=2, total=? WHERE id=?", (len(todo), job_id))
            conn.commit()
            self._process(todo, job_id, writer, summary)
            writer.flush()
            if with_candidates:
                self.control.checkpoint()
                conn.execute("UPDATE processing_jobs SET current_stage=6 WHERE id=?", (job_id,))
                conn.commit()
                p = Progress("Finding candidate pairs", total=1)
                self.report(p, force=True)
                t = time.perf_counter()
                cs = cand.generate(conn, self.embedder.model_id, self.settings,
                                   min_sim=self.min_sim, cache_dir=self.project.cache_dir)
                cand.store(conn, cs, self.embedder.model_id)
                self._t("candidates", time.perf_counter() - t)
                summary.candidates = len(cs)
                p.done = 1
                self.report(p, force=True)
        except Cancelled:
            status = "paused"
            log.info("job %d paused/cancelled; it resumes from where it stopped", job_id)
        except Exception as exc:
            status = "failed"
            log.exception("job %d failed", job_id)
            conn.execute("UPDATE processing_jobs SET error=? WHERE id=?", (repr(exc), job_id))
            raise
        finally:
            try:
                writer.close()
            finally:
                summary.seconds = round(time.perf_counter() - t_start, 2)
                summary.status = status
                summary.timings = {k: round(v, 2) for k, v in self._timings.items()}
                if summary.processed and summary.seconds:
                    summary.images_per_second = round(summary.processed / summary.seconds, 2)
                conn.execute(
                    "UPDATE processing_jobs SET status=?, done=?, finished_at=?, checkpoint_json=? WHERE id=?",
                    (status, summary.processed + summary.linked_duplicates, utcnow(),
                     json.dumps(summary.as_dict()), job_id))
                conn.commit()
                conn.close()
        return summary

    def _process(self, todo: list[WorkItem], job_id: int, writer: DbWriter, summary: RunSummary) -> None:
        if not todo:
            return
        conn = self.project.connect(readonly=True)
        drive = conn.execute("SELECT drive_type FROM source_folders LIMIT 1").fetchone()
        conn.close()
        threads = self.settings.reader_threads or reader_threads_for(drive[0] if drive else "unknown")
        if self.settings.low_impact:
            threads = max(1, threads // 2)
        p = Progress("Analysing images", total=len(todo))
        batch: list[Analysed] = []
        bs = self.settings.embed_batch

        def flush_batch():
            if not batch:
                return
            t = time.perf_counter()
            embs = self.embedder.embed([b.crop for b in batch])
            self._t("embed", time.perf_counter() - t)
            for r, e in zip(batch, embs):
                Path(self._thumb_path(r.sha)).write_bytes(r.thumb)
                writer.submit(self._write_result(job_id, r, e))
                r.crop = None
            batch.clear()

        it = iter(todo)
        in_flight: set[Future] = set()
        max_in_flight = threads * 4
        with ThreadPoolExecutor(max_workers=threads, thread_name_prefix="reader") as pool:
            try:
                while True:
                    while len(in_flight) < max_in_flight:
                        self.control.checkpoint()
                        nxt = next(it, None)
                        if nxt is None:
                            break
                        in_flight.add(pool.submit(self.analyse_file, nxt))
                    if not in_flight:
                        break
                    done, in_flight = wait(in_flight, return_when=FIRST_COMPLETED)
                    for fut in done:
                        r = fut.result()
                        p.done += 1
                        if r.skipped:
                            summary.linked_duplicates += 1
                            writer.submit(self._write_result(job_id, r, None))
                        elif r.crop is not None:
                            summary.processed += 1
                            batch.append(r)
                            if len(batch) >= bs:
                                flush_batch()
                        else:
                            if r.status == "unreadable":
                                summary.errors += 1
                            else:
                                summary.invalid += 1
                            writer.submit(self._write_result(job_id, r, None))
                        p.counters = {"processed": summary.processed, "duplicates": summary.linked_duplicates,
                                      "invalid": summary.invalid, "errors": summary.errors}
                        self.report(p)
            except Cancelled:
                for f in in_flight:
                    f.cancel()
                # finish what is already decoded so no work is lost
                for f in in_flight:
                    if not f.cancelled():
                        r = f.result()
                        if r.crop is not None:
                            summary.processed += 1
                            batch.append(r)
                flush_batch()
                raise
        flush_batch()
        self.report(p, force=True)
