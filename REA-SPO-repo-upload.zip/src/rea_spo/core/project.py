"""Projects: one folder (database + cache) per project, listed in app.db."""
from __future__ import annotations

import re
import sqlite3
import uuid
from dataclasses import dataclass
from pathlib import Path

from ..app.config import EngineSettings, app_home
from ..storage import db as dbm

_APP_SCHEMA = """
CREATE TABLE IF NOT EXISTS projects (
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, db_path TEXT NOT NULL UNIQUE,
  created_at TEXT NOT NULL, last_opened_at TEXT, status TEXT NOT NULL DEFAULT 'active'
);
"""


def _app_db() -> sqlite3.Connection:
    conn = dbm.connect(app_home() / "app.db")
    conn.executescript(_APP_SCHEMA)
    return conn


def _slug(name: str) -> str:
    s = re.sub(r"[^A-Za-z0-9_-]+", "-", name).strip("-").lower() or "project"
    return f"{s[:40]}-{uuid.uuid4().hex[:6]}"


@dataclass
class Project:
    name: str
    root: Path

    @property
    def db_path(self) -> Path:
        return self.root / "project.db"

    @property
    def cache_dir(self) -> Path:
        p = self.root / "cache"
        p.mkdir(parents=True, exist_ok=True)
        return p

    def connect(self, readonly: bool = False) -> sqlite3.Connection:
        return dbm.connect(self.db_path, readonly=readonly)

    def settings(self) -> EngineSettings:
        with self.connect() as c:
            row = c.execute("SELECT settings_json FROM project_info WHERE id=1").fetchone()
        return EngineSettings.from_json(row[0] if row else None)

    def save_settings(self, s: EngineSettings) -> None:
        c = self.connect()
        c.execute("UPDATE project_info SET settings_json=? WHERE id=1", (s.to_json(),))
        c.commit()
        c.close()

    def add_source(self, path: str | Path) -> int:
        from ..files.scanner import volume_info

        p = Path(path).resolve()
        if not p.is_dir():
            raise FileNotFoundError(f"source folder not found: {p}")
        serial, label, drive_type = volume_info(p)
        c = self.connect()
        cur = c.execute(
            "INSERT OR IGNORE INTO source_folders(path, volume_serial, volume_label, drive_type, added_at)"
            " VALUES (?,?,?,?,?)",
            (str(p), serial, label, drive_type, dbm.utcnow()),
        )
        c.commit()
        row = c.execute("SELECT id FROM source_folders WHERE path=? AND volume_serial IS ?", (str(p), serial)).fetchone()
        c.close()
        return row[0] if row else cur.lastrowid


def create_project(name: str, root: Path | None = None, settings: EngineSettings | None = None) -> Project:
    root = Path(root) if root else app_home() / "projects" / _slug(name)
    root.mkdir(parents=True, exist_ok=True)
    proj = Project(name=name, root=root)
    conn = proj.connect()
    dbm.migrate(conn)
    conn.execute(
        "INSERT OR IGNORE INTO project_info(id, name, settings_json, created_at) VALUES (1,?,?,?)",
        (name, (settings or EngineSettings()).to_json(), dbm.utcnow()),
    )
    conn.commit()
    conn.close()
    app = _app_db()
    app.execute(
        "INSERT OR IGNORE INTO projects(name, db_path, created_at) VALUES (?,?,?)",
        (name, str(proj.db_path), dbm.utcnow()),
    )
    app.commit()
    app.close()
    return proj


def open_project(name_or_path: str | Path) -> Project:
    p = Path(name_or_path)
    if p.suffix == ".db" and p.exists():
        root = p.parent
    elif (p / "project.db").exists():
        root = p
    else:
        app = _app_db()
        row = app.execute(
            "SELECT db_path FROM projects WHERE name=? AND status='active' ORDER BY id DESC", (str(name_or_path),)
        ).fetchone()
        app.close()
        if not row:
            raise FileNotFoundError(f"no project named {name_or_path!r}")
        root = Path(row[0]).parent
    conn = dbm.connect(root / "project.db")
    dbm.migrate(conn)
    name = conn.execute("SELECT name FROM project_info WHERE id=1").fetchone()[0]
    conn.close()
    app = _app_db()
    app.execute("UPDATE projects SET last_opened_at=? WHERE db_path=?", (dbm.utcnow(), str(root / "project.db")))
    app.commit()
    app.close()
    return Project(name=name, root=root)


def list_projects() -> list[dict]:
    app = _app_db()
    rows = [dict(r) for r in app.execute("SELECT * FROM projects WHERE status='active' ORDER BY id")]
    app.close()
    return rows
