"""Stages 7-8 orchestration: verify candidate pairs, decide, and build product groups."""
from __future__ import annotations

import json
import logging
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import numpy as np

from .. import ENGINE_VERSION
from ..app.config import models_dir
from ..matching import grouping
from ..matching.scoring import DEFAULT, Decision, MatcherModel, decide
from ..matching.verify import KeypointCache, PairFeatures, load_infos, pair_features
from ..storage.db import utcnow
from .project import Project

log = logging.getLogger("rea_spo.verification")


def load_model(project: Project) -> MatcherModel:
    for p in (project.cache_dir / "matcher.json", models_dir() / "matcher.json"):
        if p.exists():
            return MatcherModel.load(p)
    log.warning("no fitted matcher model found - using the conservative prior")
    return DEFAULT


def compute_features(project: Project, threads: int = 4) -> list[PairFeatures]:
    conn = project.connect(readonly=True)
    cands = conn.execute("SELECT content_a, content_b, embed_sim, phash_dist FROM match_candidates").fetchall()
    ids = {r[0] for r in cands} | {r[1] for r in cands}
    infos = load_infos(conn, ids)
    conn.close()
    kpc = KeypointCache(project.cache_dir)

    def one(r):
        ia, ib = infos.get(r[0]), infos.get(r[1])
        if ia is None or ib is None:
            return None
        return pair_features(ia, ib, kpc, r[2], r[3])

    # keypoint loading is shared; group by first image so the cache is effective
    cands = sorted(cands, key=lambda r: r[0])
    with ThreadPoolExecutor(max_workers=threads) as pool:
        out = [f for f in pool.map(one, cands, chunksize=64) if f is not None]
    return out


def size_families(feats: list[PairFeatures], infos_attrs: dict[int, list]) -> set[int]:
    """Contents that sit in a look-alike family (geometry-connected) where >= 2 different
    quantities were read. Pairs touching such a family without readable sizes go to review."""
    parent = {}

    def find(x):
        parent.setdefault(x, x)
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for f in feats:
        if f.geo_pass:
            parent[find(f.a)] = find(f.b)
    comps = defaultdict(set)
    for x in list(parent):
        comps[find(x)].add(x)
    flagged = set()
    for members in comps.values():
        qty = {a.value for m in members for a in infos_attrs.get(m, []) if a.kind == "quantity" and a.confidence >= 0.6}
        if len(qty) >= 2:
            flagged |= members
    return flagged


def run(project: Project, model: MatcherModel | None = None, threads: int = 4) -> dict:
    t0 = time.perf_counter()
    model = model or load_model(project)
    feats = compute_features(project, threads)
    conn = project.connect()
    infos = load_infos(conn, {f.a for f in feats} | {f.b for f in feats})
    fam = size_families(feats, {k: v.attrs for k, v in infos.items()})
    decisions: list[tuple[PairFeatures, Decision]] = []
    for f in feats:
        decisions.append((f, decide(f, model, size_family=(f.a in fam or f.b in fam))))
    conn.execute("DELETE FROM match_pairs WHERE engine_version=?", (ENGINE_VERSION,))
    conn.executemany(
        "INSERT INTO match_pairs(content_a, content_b, source, embed_sim, phash_dist, geo_inliers, geo_ratio,"
        " geo_coverage, color_dist, shape_diff, ocr_sim, vetoes, confidence, decision, engine_version)"
        " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        [(f.a, f.b, "candidate", f.embed_sim, f.phash_dist, f.geo_inliers, f.geo_ratio, f.geo_coverage,
          f.color_dist, f.shape_diff, f.ocr_sim, json.dumps(d.reasons), d.confidence, d.decision, ENGINE_VERSION)
         for f, d in decisions])
    conn.commit()
    summary = build_and_store_groups(project, conn)
    counts = defaultdict(int)
    for _, d in decisions:
        counts[d.decision] += 1
    conn.close()
    summary.update({"pairs": len(feats), "decisions": dict(counts), "model": model.trained_on,
                    "t_same": model.t_same, "seconds": round(time.perf_counter() - t0, 2)})
    return summary


def resolve_reviews_by_group(conn, groups, review):
    """Group-level evidence: members of a group share its confirmed size, variant and brand.
    A Review pair between two groups whose confirmed attributes conflict is Different.
    Remaining Review pairs flag both groups for human review."""
    from ..ocr import attributes as attr
    group_of = {c: i for i, g in enumerate(groups) for c in g.members}
    attrs = defaultdict(list)
    for cid, kind, value, raw, conf in conn.execute(
            "SELECT content_id, kind, value_norm, raw_text, confidence FROM product_attributes"):
        if cid in group_of:
            attrs[group_of[cid]].append(attr.Attribute(kind, value, raw or value, conf))
    left, resolved = [], 0
    for a, b in review:
        ga, gb = group_of[a], group_of[b]
        if ga == gb:
            continue
        if attr.vetoes(attrs[ga], attrs[gb]):
            resolved += 1
            lo, hi = min(a, b), max(a, b)
            conn.execute("UPDATE match_pairs SET decision='different', vetoes=json_insert(vetoes, '$[#]', "
                         "'group evidence conflict') WHERE content_a=? AND content_b=? AND engine_version=?",
                         (lo, hi, ENGINE_VERSION))
            continue
        left.append((a, b))
    for a, b in left:
        groups[group_of[a]].needs_review = True
        groups[group_of[b]].needs_review = True
    return left, resolved


def build_and_store_groups(project: Project, conn) -> dict:
    nodes = [r[0] for r in conn.execute("SELECT id FROM contents WHERE status IN ('valid','truncated')")]
    rows = conn.execute("SELECT content_a, content_b, decision, confidence FROM match_pairs WHERE engine_version=?",
                        (ENGINE_VERSION,)).fetchall()
    same = [(a, b, c) for a, b, d, c in rows if d == "same"]
    diff = [(a, b) for a, b, d, _ in rows if d == "different"]
    rev = [(a, b) for a, b, d, _ in rows if d == "review"]
    must = [(a, b) for a, b, l in conn.execute("SELECT content_a, content_b, label FROM match_decisions") if l == "must_link"]
    cannot = [(a, b) for a, b, l in conn.execute("SELECT content_a, content_b, label FROM match_decisions") if l == "cannot_link"]
    groups = grouping.build_groups(nodes, same, diff, [], must, cannot)
    rev, resolved = resolve_reviews_by_group(conn, groups, rev)
    named = {r[0]: r[1] for r in conn.execute(
        "SELECT gm.image_id, g.product_name FROM product_groups g JOIN group_members gm ON gm.group_id=g.id "
        "WHERE g.product_name IS NOT NULL")}
    conn.execute("DELETE FROM group_members")
    conn.execute("DELETE FROM product_groups")
    images_by_content = defaultdict(list)
    for iid, cid in conn.execute("SELECT id, content_id FROM images WHERE state='present' AND content_id IS NOT NULL"):
        images_by_content[cid].append(iid)
    multi = 0
    now = utcnow()
    for no, g in enumerate(groups, 1):
        imgs = [i for c in g.members for i in sorted(images_by_content.get(c, []))]
        if not imgs:
            continue
        name = next((named[i] for i in imgs if i in named), None)   # keep names the user typed
        status = "needs_review" if g.needs_review else "auto"
        gid = conn.execute("INSERT INTO product_groups(group_no, product_name, status, confidence, updated_at)"
                           " VALUES (?,?,?,?,?)", (no, name, status, g.confidence, now)).lastrowid
        first_of_content = set()
        for c in g.members:
            for k, i in enumerate(sorted(images_by_content.get(c, []))):
                conn.execute("INSERT INTO group_members(group_id, image_id, role, added_by) VALUES (?,?,?,?)",
                             (gid, i, "member" if k == 0 else "exact_duplicate", "engine"))
                first_of_content.add(i)
        multi += len(imgs) > 1
    conn.commit()
    return {"groups": len(groups), "groups_with_2plus_images": multi, "reviews_resolved_by_group_evidence": resolved,
            "groups_needing_review": sum(g.needs_review for g in groups)}
