"""Stage 5 - lazy OCR: only images that appear in at least one candidate pair are read.

Unique products never pay the OCR cost. Results are cached per content and model.
"""
from __future__ import annotations

import json
import logging
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from ..ocr import attributes as attr
from ..ocr.engine import OcrEngine
from ..storage.db import utcnow
from ..vision.decode import decode_file
from ..vision.normalize import normalize
from .project import Project

log = logging.getLogger("rea_spo.ocr_stage")


def pending_contents(project: Project, model_id: str, all_images: bool = False) -> list[tuple[int, str]]:
    conn = project.connect(readonly=True)
    where = "" if all_images else (
        "AND c.id IN (SELECT content_a FROM match_candidates UNION SELECT content_b FROM match_candidates)")
    rows = conn.execute(
        "SELECT c.id, (SELECT s.path || '/' || i.rel_path FROM images i JOIN source_folders s "
        "ON s.id=i.source_folder_id WHERE i.content_id=c.id AND i.state='present' LIMIT 1) "
        f"FROM contents c WHERE c.status IN ('valid','truncated') {where} "
        "AND NOT EXISTS (SELECT 1 FROM ocr_results o WHERE o.content_id=c.id AND o.model_id=?)", (model_id,)
    ).fetchall()
    conn.close()
    return [(r[0], r[1]) for r in rows if r[1]]


def run(project: Project, engine: OcrEngine, brands: list[str] | None = None, threads: int = 2,
        all_images: bool = False) -> dict:
    todo = pending_contents(project, engine.model_id, all_images)
    settings = project.settings()

    def one(item):
        cid, path = item
        try:
            dec = decode_file(path, settings.min_side)
            if dec.rgb is None:
                return cid, None, str(dec.error)
            crop = normalize(dec.rgb, settings.working_size).crop
            return cid, engine.read(crop), None
        except Exception as exc:  # noqa: BLE001 - one bad image must not stop OCR
            return cid, None, repr(exc)

    done = errors = 0
    conn = project.connect()
    with ThreadPoolExecutor(max_workers=threads) as pool:
        for cid, lines, err in pool.map(one, todo):
            if lines is None:
                errors += 1
                conn.execute("INSERT INTO image_errors(path, stage, error, created_at) VALUES (?,?,?,?)",
                             (str(cid), 5, err or "ocr failed", utcnow()))
                continue
            text = " ".join(l.text for l in lines)
            mean = sum(l.confidence for l in lines) / len(lines) if lines else 0.0
            conn.execute("INSERT OR REPLACE INTO ocr_results(content_id, model_id, full_text, normalized_text,"
                         " mean_conf, boxes_json, created_at) VALUES (?,?,?,?,?,?,?)",
                         (cid, engine.model_id, text, attr.normalize_text(text), mean,
                          json.dumps([[l.text, round(l.confidence, 3), l.box] for l in lines]), utcnow()))
            conn.execute("DELETE FROM product_attributes WHERE content_id=?", (cid,))
            found = []
            for l in lines:                     # per line, so each value keeps its own confidence
                found += attr.extract(l.text, l.confidence, brands)
            found += attr.extract(text, mean, brands)   # values split across lines
            for a in attr._dedupe(found):
                conn.execute("INSERT INTO product_attributes(content_id, kind, value_norm, raw_text, confidence)"
                             " VALUES (?,?,?,?,?)", (cid, a.kind, a.value, a.raw, a.confidence))
            done += 1
            if done % 200 == 0:
                conn.commit()
    conn.commit()
    conn.close()
    return {"ocr_images": done, "ocr_errors": errors, "skipped_unique_images": "lazy" if not all_images else 0}
