"""Command-line interface (headless engine). The desktop UI uses the same engine.

Examples
  rea-spo project create "Store photos" --source D:/Photos
  rea-spo analyse "Store photos"            # Ctrl+C pauses; run again to resume
  rea-spo status "Store photos"
  rea-spo candidates "Store photos" --csv pairs.csv
  rea-spo eval "Store photos" --labels labels.csv
  rea-spo gen-dataset ./synthetic --families 30
  rea-spo bench ./synthetic
"""
from __future__ import annotations

import argparse
import csv
import json
import signal
import sys
import tempfile
import time
from pathlib import Path

from . import __version__
from .ai import runtime
from .ai.embeddings import get_embedder
from .app.config import EngineSettings
from .app.logging_setup import setup_logging
from .core.pipeline import Pipeline
from .core.project import create_project, list_projects, open_project
from .workers.control import JobControl, Progress


def _progress_printer(p: Progress) -> None:
    eta = f", ~{p.eta_seconds:.0f}s left" if p.eta_seconds else ""
    total = f"/{p.total}" if p.total else ""
    sys.stderr.write(f"\r{p.stage}: {p.done}{total} ({p.rate:.1f}/s{eta})   ")
    sys.stderr.flush()


def _settings_from(args, base: EngineSettings | None = None) -> EngineSettings:
    s = base or EngineSettings()
    if getattr(args, "embedder", None):
        s.embedder = args.embedder
    if getattr(args, "cpu", False):
        s.use_gpu = False
    if getattr(args, "threads", None):
        s.reader_threads = args.threads
    if getattr(args, "low_impact", False):
        s.low_impact = True
    return s


def cmd_project(args) -> int:
    if args.action == "create":
        proj = create_project(args.name, Path(args.root) if args.root else None)
        for src in args.source or []:
            proj.add_source(src)
        print(f"created project {proj.name!r} at {proj.root}")
    elif args.action == "list":
        for p in list_projects():
            print(f"{p['name']}\t{p['db_path']}")
    elif args.action == "add-source":
        proj = open_project(args.name)
        for src in args.source or []:
            print(f"source id {proj.add_source(src)}: {src}")
    return 0


def cmd_analyse(args) -> int:
    proj = open_project(args.project)
    settings = _settings_from(args, proj.settings())
    control = JobControl()

    def on_sigint(signum, frame):  # first Ctrl+C pauses safely
        sys.stderr.write("\nStopping after the current images; run the same command again to resume.\n")
        control.cancel()

    signal.signal(signal.SIGINT, on_sigint)
    pipe = Pipeline(proj, settings, progress=None if args.quiet else _progress_printer, control=control)
    print(f"engine: {pipe.embedder.model_id} on {runtime.describe_hardware(settings.use_gpu)}", file=sys.stderr)
    summary = pipe.run(with_candidates=not args.no_candidates)
    sys.stderr.write("\n")
    print(json.dumps(summary.as_dict(), indent=2))
    return 0 if summary.status == "done" else 2


def cmd_status(args) -> int:
    proj = open_project(args.project)
    c = proj.connect(readonly=True)
    q = lambda sql: c.execute(sql).fetchone()[0]  # noqa: E731
    out = {
        "project": proj.name, "root": str(proj.root),
        "sources": [dict(r) for r in c.execute("SELECT id, path, drive_type, last_scanned_at, is_online FROM source_folders")],
        "images_present": q("SELECT COUNT(*) FROM images WHERE state='present'"),
        "images_missing": q("SELECT COUNT(*) FROM images WHERE state='missing'"),
        "unique_contents": q("SELECT COUNT(*) FROM contents"),
        "exact_duplicate_files": q("SELECT COUNT(*) - COUNT(DISTINCT content_id) FROM images WHERE state='present' AND content_id IS NOT NULL"),
        "by_status": {r[0]: r[1] for r in c.execute("SELECT status, COUNT(*) FROM contents GROUP BY status")},
        "embeddings": {r[0]: r[1] for r in c.execute("SELECT model_id, COUNT(*) FROM embeddings GROUP BY model_id")},
        "candidate_pairs": {r[0]: r[1] for r in c.execute("SELECT model_id, COUNT(*) FROM match_candidates GROUP BY model_id")},
        "last_job": dict(c.execute("SELECT id, status, started_at, finished_at FROM processing_jobs ORDER BY id DESC LIMIT 1").fetchone() or {}),
        "errors": q("SELECT COUNT(*) FROM image_errors"),
    }
    c.close()
    print(json.dumps(out, indent=2, default=str))
    return 0


def cmd_candidates(args) -> int:
    proj = open_project(args.project)
    c = proj.connect(readonly=True)
    rows = c.execute(
        "SELECT m.source, m.embed_sim, m.phash_dist, m.model_id,"
        " (SELECT s.path || '/' || i.rel_path FROM images i JOIN source_folders s ON s.id=i.source_folder_id WHERE i.content_id=m.content_a AND i.state='present' LIMIT 1) AS a,"
        " (SELECT s.path || '/' || i.rel_path FROM images i JOIN source_folders s ON s.id=i.source_folder_id WHERE i.content_id=m.content_b AND i.state='present' LIMIT 1) AS b"
        " FROM match_candidates m ORDER BY m.embed_sim DESC").fetchall()
    c.close()
    out = open(args.csv, "w", newline="", encoding="utf-8") if args.csv else sys.stdout
    w = csv.writer(out)
    w.writerow(["image_a", "image_b", "source", "embed_sim", "phash_dist", "model"])
    for r in rows:
        w.writerow([r["a"], r["b"], r["source"], f"{r['embed_sim']:.4f}" if r["embed_sim"] is not None else "",
                    r["phash_dist"], r["model_id"]])
    if args.csv:
        out.close()
        print(f"wrote {len(rows)} candidate pairs to {args.csv}")
    return 0


def cmd_eval(args) -> int:
    from .devtools.evaluate import evaluate_candidates, sweep
    proj = open_project(args.project)
    model = args.model or get_embedder(proj.settings()).model_id
    res = evaluate_candidates(proj, args.labels, model)
    if args.sweep:
        res["sweep"] = sweep(proj, args.labels, model)
    print(json.dumps(res, indent=2))
    return 0


def cmd_gen(args) -> int:
    from .devtools.synth import generate
    p = generate(args.out, n_families=args.families, singletons=args.singletons, seed=args.seed)
    print(f"dataset written; labels: {p}")
    return 0


def cmd_bench(args) -> int:
    """Analyse a folder in a throwaway project and report speed per stage."""
    with tempfile.TemporaryDirectory() as tmp:
        proj = create_project("bench", Path(tmp) / "bench")
        proj.add_source(args.folder)
        settings = _settings_from(args)
        pipe = Pipeline(proj, settings, progress=None if args.quiet else _progress_printer)
        t = time.perf_counter()
        s = pipe.run()
        sys.stderr.write("\n")
        res = s.as_dict()
        res["hardware"] = runtime.describe_hardware(settings.use_gpu)
        res["wall_seconds"] = round(time.perf_counter() - t, 2)
        if args.labels:
            from .devtools.evaluate import evaluate_candidates
            res["eval"] = evaluate_candidates(proj, args.labels, s.model_id)
        print(json.dumps(res, indent=2))
    return 0


def cmd_verify(args) -> int:
    from .core import ocr_stage, verification
    from .ocr.engine import get_engine
    proj = open_project(args.project)
    if not args.no_ocr:
        eng = get_engine(proj.settings().use_gpu)
        if eng is not None:
            print(json.dumps(ocr_stage.run(proj, eng, brands=proj.settings().extra.get("brands"))), file=sys.stderr)
    print(json.dumps(verification.run(proj, threads=args.threads or 4), indent=2))
    return 0


def cmd_groups(args) -> int:
    proj = open_project(args.project)
    c = proj.connect(readonly=True)
    rows = c.execute(
        "SELECT g.group_no, g.status, g.confidence, g.product_name, s.path || '/' || i.rel_path AS file, gm.role "
        "FROM product_groups g JOIN group_members gm ON gm.group_id=g.id JOIN images i ON i.id=gm.image_id "
        "JOIN source_folders s ON s.id=i.source_folder_id ORDER BY g.group_no, file").fetchall()
    c.close()
    if args.csv:
        with open(args.csv, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["group", "status", "confidence", "product_name", "file", "role"])
            w.writerows([tuple(r) for r in rows])
        print(f"wrote {len(rows)} rows to {args.csv}")
        return 0
    last = None
    for r in rows:
        if args.multi_only and r["status"] == "auto" and sum(1 for x in rows if x["group_no"] == r["group_no"]) < 2:
            continue
        if r["group_no"] != last:
            last = r["group_no"]
            print(f"GROUP {r['group_no']:04d}  [{r['status']}, {r['confidence']:.0f}%]  {r['product_name'] or ''}")
        print(f"   {r['file']}{'  (exact duplicate)' if r['role'] == 'exact_duplicate' else ''}")
    return 0


def cmd_train(args) -> int:
    from .devtools import phase3
    proj = open_project(args.project)
    if args.simulate_ocr:
        print("simulated OCR:", phase3.simulate_ocr(proj, Path(args.labels)), file=sys.stderr)
    res = phase3.train(proj, Path(args.labels), Path(args.out) if args.out else None)
    print(json.dumps(res, indent=2))
    return 0


def cmd_eval_groups(args) -> int:
    from .devtools import phase3
    proj = open_project(args.project)
    out = {"pairs": phase3.evaluate_decisions(proj, Path(args.labels)),
           "groups": phase3.evaluate_groups(proj, Path(args.labels))}
    print(json.dumps(out, indent=2))
    return 0


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="rea-spo", description="REA Smart Product Organizer - engine CLI")
    ap.add_argument("--version", action="version", version=__version__)
    ap.add_argument("-v", "--verbose", action="store_true")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("project", help="create or list projects")
    p.add_argument("action", choices=["create", "list", "add-source"])
    p.add_argument("name", nargs="?")
    p.add_argument("--source", action="append")
    p.add_argument("--root", help="project folder (default: app data)")
    p.set_defaults(fn=cmd_project)

    def engine_opts(sp):
        sp.add_argument("--embedder", help="auto | siglip2 | classic | any model id in models/manifest.json")
        sp.add_argument("--cpu", action="store_true", help="do not use the GPU")
        sp.add_argument("--threads", type=int, help="reader threads (default: by drive type)")
        sp.add_argument("--low-impact", action="store_true")
        sp.add_argument("-q", "--quiet", action="store_true")

    p = sub.add_parser("analyse", help="scan and analyse (resumable)")
    p.add_argument("project")
    p.add_argument("--no-candidates", action="store_true")
    engine_opts(p)
    p.set_defaults(fn=cmd_analyse)

    p = sub.add_parser("status")
    p.add_argument("project")
    p.set_defaults(fn=cmd_status)

    p = sub.add_parser("candidates", help="export candidate pairs")
    p.add_argument("project")
    p.add_argument("--csv")
    p.set_defaults(fn=cmd_candidates)

    p = sub.add_parser("eval", help="measure candidate recall against labels")
    p.add_argument("project")
    p.add_argument("--labels", required=True)
    p.add_argument("--model")
    p.add_argument("--sweep", action="store_true")
    p.set_defaults(fn=cmd_eval)

    p = sub.add_parser("verify", help="Stage 7-8: verify candidate pairs and build groups")
    p.add_argument("project")
    p.add_argument("--threads", type=int)
    p.add_argument("--no-ocr", action="store_true")
    p.set_defaults(fn=cmd_verify)

    p = sub.add_parser("groups", help="list or export product groups")
    p.add_argument("project")
    p.add_argument("--csv")
    p.add_argument("--multi-only", action="store_true")
    p.set_defaults(fn=cmd_groups)

    p = sub.add_parser("train-matcher", help="fit the confidence model on labelled pairs (developer)")
    p.add_argument("project")
    p.add_argument("--labels", required=True)
    p.add_argument("--out")
    p.add_argument("--simulate-ocr", action="store_true", help="synthetic datasets only")
    p.set_defaults(fn=cmd_train)

    p = sub.add_parser("eval-groups", help="pair-decision and group accuracy against labels")
    p.add_argument("project")
    p.add_argument("--labels", required=True)
    p.set_defaults(fn=cmd_eval_groups)

    p = sub.add_parser("gen-dataset", help="write the synthetic labelled dataset")
    p.add_argument("out")
    p.add_argument("--families", type=int, default=20)
    p.add_argument("--singletons", type=int, default=60)
    p.add_argument("--seed", type=int, default=7)
    p.set_defaults(fn=cmd_gen)

    p = sub.add_parser("bench", help="benchmark a folder in a temporary project")
    p.add_argument("folder")
    p.add_argument("--labels")
    engine_opts(p)
    p.set_defaults(fn=cmd_bench)
    return ap


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    setup_logging(verbose=args.verbose)
    return args.fn(args)


if __name__ == "__main__":
    sys.exit(main())
