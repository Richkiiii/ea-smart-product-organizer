"""Read a `rea-spo bench --labels` JSON report and enforce (or report) the Phase 2 gate.

    python tools/eval/check_gate.py report.json --min-recall 0.995 [--warn-only]
"""
import argparse
import json
import sys


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("report")
    ap.add_argument("--min-recall", type=float, default=0.995)
    ap.add_argument("--warn-only", action="store_true")
    a = ap.parse_args()
    raw = open(a.report, encoding="utf-8").read()
    rep = json.loads(raw[raw.index("{"):])
    ev = rep.get("eval", rep)
    recall = ev["candidate_recall"]
    line = (f"model={ev['model_id']} recall={recall:.4f} pairs/image={ev['candidates_per_image']} "
            f"speed={rep.get('images_per_second', '?')} img/s on {rep.get('hardware', '?')}")
    print(line)
    if recall < a.min_recall:
        print(f"GATE NOT MET: candidate recall {recall:.4f} < {a.min_recall}")
        return 0 if a.warn_only else 1
    print("GATE MET")
    return 0


if __name__ == "__main__":
    sys.exit(main())
