"""Export an image-embedding model to ONNX and register it in models/manifest.json.

Developer / CI tool - needs internet and the [export] extras:
    pip install -e .[export]
    python tools/export_models/export_embedder.py --model siglip2            # production default
    python tools/export_models/export_embedder.py --model dinov2-small       # Phase 2 comparison
    python tools/export_models/export_embedder.py --model siglip2 --int8     # CPU-optimized copy

The exported graph takes pixel_values [N,3,S,S] (float32, normalized) and returns
image embeddings [N,D]. Parity with PyTorch is checked before the manifest is written.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

MODELS = {
    "siglip2": dict(model_id="siglip2-base-p16-224-image", hf="google/siglip2-base-patch16-224",
                    size=224, mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5], licence="Apache-2.0", kind="siglip"),
    "dinov2-small": dict(model_id="dinov2-small-image", hf="facebook/dinov2-small",
                         size=224, mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225],
                         licence="Apache-2.0", kind="dinov2"),
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def build_wrapper(cfg):
    import torch
    from transformers import AutoModel

    model = AutoModel.from_pretrained(cfg["hf"]).eval()

    class Wrapper(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.m = model

        def forward(self, pixel_values):
            if cfg["kind"] == "siglip":
                return self.m.get_image_features(pixel_values=pixel_values)
            out = self.m(pixel_values=pixel_values)
            return out.last_hidden_state[:, 0]          # DINOv2 CLS token

    return Wrapper().eval()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", choices=sorted(MODELS), default="siglip2")
    ap.add_argument("--out", default=str(Path(__file__).resolve().parents[2] / "models"))
    ap.add_argument("--int8", action="store_true", help="also write a dynamic-INT8 copy for CPU")
    ap.add_argument("--opset", type=int, default=17)
    args = ap.parse_args()

    import onnxruntime as ort
    import torch

    cfg = MODELS[args.model]
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    onnx_path = out / f"{cfg['model_id']}.onnx"
    wrapper = build_wrapper(cfg)
    dummy = torch.randn(2, 3, cfg["size"], cfg["size"])
    torch.onnx.export(wrapper, (dummy,), str(onnx_path), input_names=["pixel_values"],
                      output_names=["image_embeds"], dynamic_axes={"pixel_values": {0: "n"}, "image_embeds": {0: "n"}},
                      opset_version=args.opset, do_constant_folding=True)

    with torch.no_grad():
        ref = wrapper(dummy).numpy()
    sess = ort.InferenceSession(str(onnx_path), providers=["CPUExecutionProvider"])
    got = sess.run(None, {"pixel_values": dummy.numpy()})[0]
    cos = (ref * got).sum(1) / (np.linalg.norm(ref, axis=1) * np.linalg.norm(got, axis=1))
    print(f"parity: min cosine {cos.min():.6f}")
    if cos.min() < 0.999:
        raise SystemExit("ONNX export does not match PyTorch - aborting")

    entries = {cfg["model_id"]: dict(file=onnx_path.name, sha256=sha256(onnx_path), dim=int(got.shape[1]),
                                     input_size=cfg["size"], mean=cfg["mean"], std=cfg["std"],
                                     licence=cfg["licence"], source=cfg["hf"])}
    if args.int8:
        from onnxruntime.quantization import QuantType, quantize_dynamic
        q_path = out / f"{cfg['model_id']}-int8.onnx"
        quantize_dynamic(str(onnx_path), str(q_path), weight_type=QuantType.QInt8)
        qs = ort.InferenceSession(str(q_path), providers=["CPUExecutionProvider"])
        qg = qs.run(None, {"pixel_values": dummy.numpy()})[0]
        qcos = (ref * qg).sum(1) / (np.linalg.norm(ref, axis=1) * np.linalg.norm(qg, axis=1))
        print(f"int8 parity: min cosine {qcos.min():.4f}")
        entries[cfg["model_id"] + "-int8"] = dict(entries[cfg["model_id"]], file=q_path.name, sha256=sha256(q_path))

    mf = out / "manifest.json"
    data = json.loads(mf.read_text()) if mf.exists() else {"models": {}}
    data.setdefault("models", {}).update(entries)
    mf.write_text(json.dumps(data, indent=2))
    print(f"registered {', '.join(entries)} in {mf}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
