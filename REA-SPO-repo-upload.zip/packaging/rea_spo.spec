# PyInstaller spec - one-folder build (faster start, fewer antivirus false positives than one-file).
# Build: pyinstaller packaging/rea_spo.spec --noconfirm
from pathlib import Path

from PyInstaller.utils.hooks import collect_data_files, collect_dynamic_libs

ROOT = Path(SPECPATH).parent
models = [(str(p), "models") for p in (ROOT / "models").glob("*") if p.suffix in {".onnx", ".json"}]

datas = collect_data_files("rea_spo") + models
binaries = collect_dynamic_libs("onnxruntime")

a = Analysis(
    [str(ROOT / "packaging" / "entry.py")],
    pathex=[str(ROOT / "src")],
    binaries=binaries,
    datas=datas,
    hiddenimports=["rea_spo.cli", "faiss"],
    excludes=["tkinter", "matplotlib", "torch", "transformers", "pytest", "IPython"],
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz, a.scripts, [],
    exclude_binaries=True,
    name="REA-SPO",
    console=True,                       # Phase 5 adds a windowed GUI executable
    icon=str(ROOT / "packaging" / "app.ico") if (ROOT / "packaging" / "app.ico").exists() else None,
    version=str(ROOT / "packaging" / "version_info.txt"),
)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name="REA-SPO")
