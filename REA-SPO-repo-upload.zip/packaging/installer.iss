; Inno Setup script - REA Smart Product Organizer
; Build: iscc packaging\installer.iss  (after PyInstaller has produced dist\REA-SPO)

#define AppName "REA Smart Product Organizer"
#define AppVersion "0.3.0-dev"

[Setup]
AppId={{6F1B6E0C-6E2A-4D7B-9F7E-2C5A9D3B1E47}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher=REA
DefaultDirName={autopf}\REA\Smart Product Organizer
DefaultGroupName=REA
OutputDir=..\dist\installer
OutputBaseFilename=REA-Smart-Product-Organizer-{#AppVersion}-setup
Compression=lzma2/ultra64
SolidCompression=yes
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0.17763
PrivilegesRequiredOverridesAllowed=dialog
WizardStyle=modern
; Project databases live in %LOCALAPPDATA%\REA\SmartProductOrganizer and are kept on uninstall.

[Files]
Source: "..\dist\REA-SPO\*"; DestDir: "{app}"; Flags: recursesubdirs ignoreversion

[Icons]
Name: "{group}\{#AppName}"; Filename: "{app}\REA-SPO.exe"
Name: "{group}\Uninstall {#AppName}"; Filename: "{uninstallexe}"
