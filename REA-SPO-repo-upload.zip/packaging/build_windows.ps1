# Clean Windows build: venv -> (models) -> tests -> PyInstaller -> smoke test -> portable ZIP -> installer.
# Usage:  ./packaging/build_windows.ps1 [-SkipModelExport] [-SkipTests]
param([switch]$SkipModelExport, [switch]$SkipTests)
$ErrorActionPreference = "Stop"
$root = Split-Path $PSScriptRoot -Parent
Set-Location $root

python -m venv .venv-build
. .\.venv-build\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -e ".[fast,dev]"

if (-not $SkipModelExport -and -not (Test-Path "models\siglip2-base-p16-224-image.onnx")) {
    pip install -e ".[export]"
    python tools\export_models\export_embedder.py --model siglip2 --int8
}
if (-not $SkipTests) { python -m pytest -q }

pyinstaller packaging\rea_spo.spec --noconfirm --clean --distpath dist --workpath build

# Smoke test the frozen app on a small synthetic set, using no Python from the build venv.
deactivate
$env:REA_SPO_HOME = Join-Path $env:TEMP "rea-spo-smoke"
& dist\REA-SPO\REA-SPO.exe --version
& dist\REA-SPO\REA-SPO.exe gen-dataset "$env:TEMP\rea-smoke-set" --families 3 --singletons 3
& dist\REA-SPO\REA-SPO.exe bench "$env:TEMP\rea-smoke-set" -q
if ($LASTEXITCODE -ne 0) { throw "frozen app smoke test failed" }

Compress-Archive -Path dist\REA-SPO\* -DestinationPath dist\REA-SPO-portable-0.3.0-dev.zip -Force

$iscc = "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe"
if (-not (Test-Path $iscc)) { choco install innosetup -y --no-progress }
& $iscc packaging\installer.iss
Write-Host "Build complete: dist\REA-SPO-portable-0.3.0-dev.zip and dist\installer\"
