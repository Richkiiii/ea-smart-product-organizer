"""PyInstaller entry point (absolute import so the frozen app resolves the package)."""
import multiprocessing
import sys

from rea_spo.__main__ import run

if __name__ == "__main__":
    multiprocessing.freeze_support()
    sys.exit(run())
